# Numeric block-bound cache ownership fix — October 5

Isolated worktree `tantivy-pruning-finite-oct05`, base
`d78f9a1f24f8028cc1956585ef2b1f54da37ea1b`. Commit `7fcfe0ef488d3b338ff66e29febe01280de1b0f9`. Only two core source/test files change.
No finite transform, scoring expression, codec, loop or index change is included.

Real serialized loaded tails reproduce both public-to-private stale-cache paths.
The baseline run fails both regressions: native public low weight leaves the fixed
high-weight scorer returning0.71428573 instead of71.42857; a changed public norm
reader leaves its owning scorer returning0.032658458 instead of0.88495576.
The baseline source snapshots match the hashes captured before that actual run.

Public evaluation now checks safety first and returns the same complete-block
global and loaded/unloaded-tail results, but neither reads nor clears nor writes
the fixed-scorer numeric cache. Both paths share one private literal loaded
reducer; only the private fixed-scorer path caches its result. The existing
NaN-to-infinity reducer, nonnegative contribution clamp, stored-default branch
and all movement/reset invalidators retain their behavior.

After the fix,13 TermScorer tests,10 block-postings tests and15 BM25/parameter tests
pass; one existing long stress test stays ignored. The two stale-cache regressions
pass for native and classic scoring and require exact public literal results even
while a different private result is cached. A third test observes complete global,
shallow unloaded-tail global, loaded-tail exact, negative boost clamp and Inf/NaN
safety fallback while preserving the cached fixed-owner result. Existing focused
suites cover reset/seek/empty/dense/FOR frequency blocks, native all-norm scalar
matrix, exceptional parameters, serialized bounds and optimized/exhaustive checks.

[receipt.json](receipt.json) records exact commands, environments, result codes,
source/lock/toolchain/test-binary hashes and every raw log/source artifact hash.
`baseline-failing.*` is the expected failing run; `fixed-term-scorer.*`,
`fixed-block-postings.*` and `fixed-bm25.*` are successful focused runs. The copied
runner `run.py` reproduces command capture using an isolated jobs4 target and an
offline locked dependency graph. Test execution duration is harness metadata,
not a search performance measurement.

No production performance claim follows from this safety unit. All own CPU jobs
are idle; root owns full review, release adapters, strict frozen gates and timings.
The finite B transform remains unimplemented pending root review of this commit.
