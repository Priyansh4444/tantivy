from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path('/home/pronsh/Coding/playground/search/tantivy-pruning-finite-oct05')
evidence=Path('/home/pronsh/Coding/playground/search/bench/native-pruning-cache-ownership-oct05')
label=sys.argv[1]
cmd=['cargo','test','--offline','--locked','--lib','--jobs','4','--target-dir',str(root/'target/cache-ownership-oct05'),*sys.argv[2:],'--','--nocapture']
env=os.environ.copy();env['CARGO_PROFILE_TEST_DEBUG']='0'
sources={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'src/query/term_query/term_scorer.rs',root/'src/postings/block_segment_postings.rs',root/'Cargo.lock']}
meta={'label':label,'command':cmd,'cwd':str(root),'env_overrides':{'CARGO_PROFILE_TEST_DEBUG':'0'},'source_sha256':sources}
(evidence/f'{label}.command.json').write_text(json.dumps(meta,indent=2)+'\n')
t=time.monotonic()
with (evidence/f'{label}.stdout').open('wb') as stdout,(evidence/f'{label}.stderr').open('wb') as stderr:
 result=subprocess.run(cmd,cwd=root,env=env,stdout=stdout,stderr=stderr)
meta.update(returncode=result.returncode,wall_seconds=time.monotonic()-t)
(evidence/f'{label}.result.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta))
print((evidence/f'{label}.stdout').read_text()[-4000:])
print((evidence/f'{label}.stderr').read_text()[-2000:])
sys.exit(result.returncode)
