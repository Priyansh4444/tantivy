# Independent block-bound cache ownership review

Read-only review on 2026-10-05 of worker
`search/tantivy-pruning-finite-oct05`, against full base
`d78f9a1f24f8028cc1956585ef2b1f54da37ea1b`. I read the entire source/test diff
initially uncommitted and again after commit
`7fcfe0ef488d3b338ff66e29febe01280de1b0f9`
(`fix(postings): isolate public block-bound cache evaluation`). The worker is
clean; the committed delta changes exactly the two reviewed files. Workflow
investigation guidance applies. No source edits, builds, tests, engines, index
work or timing were run by this reviewer. Only this report was written.

throughput checkpoint: n/a, read-only investigation

## Verdict

**Approved for integration; no blocking source or evidence issue found.**
The public weight/reader-taking API now computes an uncached result and cannot
consume or populate the fixed TermScorer's numeric cache. The extracted loaded
reduction preserves the previous literal computation. Public result semantics,
private stored/global/cache behavior and movement invalidation remain intact.
This is a prerequisite ownership correction; no pruning transform, new index
format, document-score change or performance result is included.

The reproduced sequence uses crate-internal `TermScorer::block_cursor()` access,
then mixes its public cursor API with the owner's private bound path. It proves
a reachable internal ownership hazard. It does **not** establish that the frozen
Wiki20 production routes currently execute that mixing sequence or fail gates.
Root's immutable release verification remains separate.

## Actual ownership and preserved branches

[block_segment_postings.rs:165](../tantivy-pruning-finite-oct05/src/postings/block_segment_postings.rs#L165)
does not reference `block_max_score_cache` in the public method. Its only helper,
`loaded_block_max_score`, takes `&self`, does not read/write that cache and does
not move or decode the cursor. The public API can leave an existing owner cache
intact because its foreign weight/reader neither changes the owner nor installs
a foreign value. No cache generation or weight key is needed for this isolated
change. The private fixed-weight/reader path remains the sole producer/consumer
of numeric values.

| Case | Old public result after clear, and new public result |
|---|---|
| Unsafe normalization or nonfinite weight | `bm25_weight.max_score()`, preserving its existing infinity fallback. |
| Complete block, loaded or unloaded | Global `max_score()`; public callers still have no stored-pair trust. |
| Safe unloaded VInt tail | Global `max_score()`; helper returns None. |
| Safe loaded VInt tail | Exact literal per-posting maximum, NaN mapped to infinity, empty result zero and contribution clamped at zero. |

The new combined early condition short-circuits unsafe normalization before any
loaded reduction. The private method still checks safety before cached values,
rejects untrusted complete blocks before cache/loaded work, consults trusted
stored metadata as before, and caches only its own loaded reduction. A failed
unloaded reduction remains uncached. The DEFAULT eligibility, selected TF
ceiling, nondefault global fallback and scoring formula are untouched.

[loaded_block_max_score:221](../tantivy-pruning-finite-oct05/src/postings/block_segment_postings.rs#L221)
is a direct extraction of the prior reduction: `.copied()` replaces `.cloned()`
for u32 docIDs, with the same enumeration index feeding `freq_decoder.output`.
The unchanged top-level `max_score` iterator converts every NaN to infinity
before `Score::max`; `unwrap_or(0.0).max(0.0)` retains empty/negative contribution
semantics. The helper's callers both check safety first. No alternate
normalization arithmetic or NaN-discarding maximum was introduced.

The iterator uses `doc_decoder.output_array()`, not the padded array.
[compression/mod.rs:344](../tantivy-pruning-finite-oct05/src/postings/compression/mod.rs#L344)
returns `output[..output_len]`, and VInt decoding sets output_len to the actual
num_els at
[:433](../tantivy-pruning-finite-oct05/src/postings/compression/mod.rs#L433).
Thus tail padding/TERMINATED docIDs cannot be scored by this extraction. Dense
and FOR complete lengths remain their original decoder lengths; no frequency
alignment, no-frequency default or decoder state was changed.

## Movement, reset and clone inheritance

I traced the unchanged cursor reset, `seek_block`, `advance` and
`advance_skip_only`: they retain their cache clears when the block changes;
reset also clears loaded state before rebinding/loading. In-block motion can
reuse a maximum over the original whole block conservatively. `load_block`
does not make an untrusted complete block eligible. TermScorer still owns its
same immutable weight and norm reader and passes those to the private method.

Both cursor and scorer continue deriving Clone. A cloned private cache value
starts with the same block, fixed weight and immutable reader as its owner;
subsequent movement clears it independently. Public calls on either clone now
cannot replace it with a foreign value. There is no new reset/rebind surface or
cache field. These are source-level inheritance checks; the new tests do not
claim an explicit clone/mixed-public-reset runtime matrix. Existing reset/seek
tests passed in the retained block-postings log.

## Tests prove both ownership directions

The new weight test primes the private high-weight tail maximum, calls the
public cursor with a lower weight, checks the exact lower public score bits,
then checks exact original private maximum bits. That proves both that the
public calculation ignores the owner cache and that it does not poison it.
The reader test makes the same two assertions with fixed short norms and a
foreign long-norm reader. Both execute native and classic branches in the
successful fixed run.

The third test uses 129 postings: loaded complete block stays global;
shallow-selected unloaded tail stays global; loading its actual one-document
tail produces the exact score. It primes the private cache and checks public
boosts 3, -1, infinity and NaN, followed each time by unchanged private bits,
for native and classic. This covers a public higher weight as well as the
lower-weight poisoning witness. An existing public-low/public-high test also
continues passing. No new test bypasses the actual cursor/owner methods.

The reader witness explicitly covers cache read and cache write directions;
it does not enumerate every possible ordering of two norm readers. The source
implementation has no cache access at all on that route, so this is not a
blocking coverage gap. Unsafe-average and serialized/exhaustive cases remain
covered by the retained BM25 suite. The extracted NaN mapping is source-verified;
I do not claim a newly added direct loaded-NaN runtime witness.

## Retained raw evidence and exact source identity

I read baseline-failing and all three fixed command/result/stdout/stderr files
under `bench/native-pruning-cache-ownership-oct05`. The baseline result exits 101:
two tests fail, with native weight public/private both 0.71428573 versus expected
71.42857, and native reader public/private both 0.032658458 versus expected
0.88495576. Those failures occur in the first native loop iteration; they do not
prove baseline classic iterations executed.

The fixed term-scorer log passes 13 tests with one preexisting ignored long test;
block-postings passes 10; BM25 passes 15. Fixed raw stderr records native/classic
weight results 0.71428573/71.42857 and 8.9252205/892.522, and reader results
0.032658458/0.88495576 and 0.40807664/11.057794 respectively, with each owner
result matching expected. These are the owner's recorded runs, independently
inspected here; this reviewer ran no tests. Cargo/test elapsed times are not
performance evidence.

I independently recomputed current committed source SHA-256 and compared all
three fixed command/result manifests. Every source hash matches actual files;
command/result metadata agrees. I also hashed the baseline postings source
directly from git base; it matches the baseline-failing manifest.

| File/identity | SHA-256 |
|---|---|
| Fixed src/postings/block_segment_postings.rs | `8a57d837b11344bdc2645f9e2f05df2b11b0cfa241a5ba79aeb535f3a977dac3` |
| Fixed src/query/term_query/term_scorer.rs | `680c774ad8a384c321f70a7cdc2eca37ec387808897b5d348bb72a0d6d81a1c3` |
| Unchanged Cargo.lock | `8fd56550ca9d5463b1df932b60ed59bf8b99a43f7c0c22fe75297505759497c5` |
| Baseline postings source, independently verified from git | `7b532a15afb7b8e1747e4c66932e78720fd673fe6e89203966c12b2c9a9e52b3` |
| Baseline witness test source, as recorded by its manifest | `47cb9a59a26ce517ed1b2dd2a58ced57e33f42965fd1717442297d67c52119a2` |

The baseline witness test-source hash differs from the later complete test file;
its recorded identity is preserved, not described as the exact final test bytes.
The successful fixed logs match the exact final committed source bytes. Root
owns integrated release build/artifact identity and remaining release/full gates.
