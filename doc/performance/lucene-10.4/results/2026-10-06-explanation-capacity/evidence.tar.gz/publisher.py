#!/usr/bin/env python3
"""Publish the narrow P022 allocation result and its complete targeted evidence."""
from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

BASE = Path(__file__).resolve().parent
REPO = BASE.parent / 'tantivy-pr2937'
SOURCE = BASE / 'native-explanation-capacity-oct06'
OUT = REPO / 'doc/performance/lucene-10.4/results/2026-10-06-explanation-capacity'
assert not OUT.exists()
receipt = json.loads((SOURCE / 'keep-integration-receipt.json').read_text())
assert receipt['verdict'] == 'kept'
assert subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip() == receipt['integrated_commit']
assert not subprocess.check_output(['git', '-C', str(REPO), 'status', '--porcelain'], text=True).strip()
subprocess.run(['git', '-C', str(REPO), 'diff', '--quiet', receipt['tested_candidate_commit'], 'HEAD', '--', 'src', 'Cargo.toml', 'Cargo.lock', '.cargo'], check=True)
members = {}
for path in sorted(SOURCE.rglob('*')):
    if any(part in ('target', '__pycache__') for part in path.relative_to(SOURCE).parts):
        continue
    assert not path.is_symlink()
    if path.is_file():
        members[str(path.relative_to(BASE))] = path.read_bytes()
for relative, expected in receipt['files_sha256'].items():
    data = (REPO / relative).read_bytes()
    assert hashlib.sha256(data).hexdigest() == expected
    members['integrated-source/' + relative] = data
members['publisher.py'] = Path(__file__).read_bytes()
OUT.mkdir()
inventory = {}
with tarfile.open(OUT / 'evidence.tar.gz', 'w:gz') as tar:
    for name, data in sorted(members.items()):
        assert not name.startswith('/') and '..' not in Path(name).parts
        inventory[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        tar.addfile(info, io.BytesIO(data))
archive_sha = hashlib.sha256((OUT / 'evidence.tar.gz').read_bytes()).hexdigest()
(OUT / 'manifest.json').write_text(json.dumps({'attempt': 'P022', 'verdict': 'kept',
    'tested_commit': receipt['tested_candidate_commit'], 'integrated_commit': receipt['integrated_commit'],
    'metric': 'Caller-thread owned explanation allocation calls and requested-byte totals only',
    'archive_sha256': archive_sha, 'members': inventory}, indent=2) + '\n')
(OUT / 'README.md').write_text('''# Sized BM25 explanation children — October 6, 2026

Known-size IDF child vectors now use their exact length. A crate-private helper
adopts the owned vector, retaining absent details for an empty vector. Single
materialization uses its two ordered leaves; native sums collect the ordered
record iterator. Public APIs, scalar values, rounding, descriptions, provider
calls/errors, explicit-tree cloning, scoring, bounds and index format are unchanged.

Accepted source is `1ac1c323a4e1ef872dfc6a917e962d54f18fb0ea`, identical across
all tracked source/Cargo/config files to tested `cefcd1edec930d3983fcea39d3b266cbf77c0fe9`.
The two-file change follows the separately accepted [deferred-explanation unit](../2026-10-06-explanation/README.md).

## Allocation result

The unchanged standalone probe retains 1,000 outputs per operation and repeats
each operation three times. Setup and retention-vector allocations are outside
the caller-thread counter. Per-output requested bytes and allocation calls:

| Owned explanation | P021 bytes | P022 bytes | Calls, unchanged |
| --- | ---: | ---: | ---: |
| Native/classic single |1600 |1440 |4 |
| Three-term native phrase |2560 |2000 |7 |
| Classic phrase/no explanation |1280 |1280 |3 |

Single explanations use 10% fewer requested bytes; native three-term explanations
use 21.875% fewer versus P021. Both return exactly to the original eager
implementation's per-explain byte totals. All first 18 construction/clone/boost
operations exactly match P021: weights remain 56 bytes, single construction has
one allocation, native phrase construction three, and tested clones/boosts zero.
These are requested-byte totals, not peak/live memory, RSS or latency measurements.
There is no new query-speed or fresh Lucene comparison claim.

## Verification and evidence

All 27 BM25 tests pass in debug and exact native opt3/LTO/overflow-off release,
including all 42 unchanged frozen whole-tree/scalar cases. The original allocation
probe is byte-identical; all 139 dependency identities/checksums/edges match the
retained lock, with only the probe-root name changed. Root independently verified
all 23 operation rows, full source and runner/log/compiler hashes, and before/after
guards. All five explanation rows exactly match the original eager allocation
baseline; all call counts remain unchanged.

The first `--locked` test attempt failed before compilation because a new worktree
does not inherit the ignored root test Cargo.lock. Its failed log/receipt remain.
Preparation now always copies and verifies the retained P021 test lock before a
locked test phase; no dependencies are resolved. The main ignored lock stays
unchanged. Explicit profile settings remove inherited profile overrides and
encoded Rust flags. Subsequent successful runs have separate IDs and artifacts.

Validation is targeted to this renderer-only allocation change. P021's broader
1,381 library tests, frozen330/all three Wiki20 gates and 16 paired/control runs
remain separate historical evidence at P021. They are not attributed to this
new source, and no broader query adapter/timing rerun is claimed. Full Lucene
public-API parity and an all-query speed win remain unfinished.

[manifest.json](manifest.json) hashes every member of [evidence.tar.gz](evidence.tar.gz):
actual baseline/candidate/integrated source and diff, unchanged tests/golden,
adopted lock preparation, all successful and failed test logs/provenance,
unchanged allocation probe/lock/raw outputs, independently reviewed runner and
root audits, and the keep/integration receipt. Build caches and binaries are
identified by provenance rather than embedded. Absolute paths are historical.
Decision `P022` records this narrow efficiency keep.
''')
with tarfile.open(OUT / 'evidence.tar.gz') as tar:
    assert {item.name for item in tar.getmembers()} == set(inventory)
    for item in tar.getmembers():
        assert item.isfile()
        data = tar.extractfile(item).read()
        assert len(data) == inventory[item.name]['bytes']
        assert hashlib.sha256(data).hexdigest() == inventory[item.name]['sha256']
publication = {'members_verified': len(inventory), 'archive_bytes': (OUT / 'evidence.tar.gz').stat().st_size,
               'archive_sha256': archive_sha, 'integrated_commit': receipt['integrated_commit']}
with (BASE / 'explanation-capacity-publication-oct06.json').open('x') as stream:
    json.dump(publication, stream, indent=2)
    stream.write('\n')
print(json.dumps(publication))
