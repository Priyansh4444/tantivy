#!/usr/bin/env python3
import csv,datetime,importlib.util,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('p022_common',ROOT/'stage2-common.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
phase=sys.argv[1]
assert phase in ('debug-bm25-04','release-bm25-05','allocation-v2-candidate-06')
log=ROOT/f'{phase}.log';receipt=ROOT/f'{phase}-receipt.json';output=ROOT/f'{phase}.csv'
assert not log.exists() and not receipt.exists() and not output.exists(),'retain every prior run'
release=not phase.startswith('debug');allocation=phase.startswith('allocation')
subprocess.run([sys.executable,str(ROOT/'prepare-test-lock.py')],check=True,stdout=subprocess.DEVNULL)
before=c.guards();c.write(ROOT/f'{phase}-guards-before.json',before)
compiler=c.compiler();c.write(ROOT/f'{phase}-compiler.json',compiler)
if allocation:
 cwd=ROOT/'allocation-v2-candidate'
 target=Path(c.PREPARED['allocation_target'])
 command=['cargo','run','--locked','--release','--jobs','4','--manifest-path',str(cwd/'Cargo.toml')]
else:
 cwd=c.WORK;target=Path(c.PREPARED['test_target'])
 command=['cargo','test','--locked','--lib','bm25','--jobs','4']
 if release:command.insert(2,'--release')
 command+=['--','--nocapture']
env=c.environment(target,release)
r={'phase':phase,'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'cwd':str(cwd),'rust_flags':env['RUSTFLAGS'],'encoded_rustflags_unset':'CARGO_ENCODED_RUSTFLAGS' not in env,'inherited_profile_environment_removed':True,'explicit_profile_environment':{key:value for key,value in env.items() if key.startswith('CARGO_PROFILE_')},'profile':{'release':release,'opt-level':3 if release else 0,'lto':True if release else False,'overflow-checks':False if release else True},'target_dir':str(target),'source_sha256':before['candidate_all_source_sha256'],'compiler_sha256':c.sha(ROOT/f'{phase}-compiler.json'),'prepared_receipt_sha256':c.sha(ROOT/'stage2-prepared-receipt.json'),'runner_sha256':c.sha(Path(__file__)),'common_runner_sha256':c.sha(ROOT/'stage2-common.py'),'status':'running','timing':False,'physical_index_scans':False}
c.write(receipt,r)
if allocation:
 with output.open('x') as out,log.open('x') as err:result=subprocess.run(command,cwd=cwd,env=env,stdout=out,stderr=err)
else:
 with log.open('x') as out:result=subprocess.run(command,cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT)
r.update(status='complete',exit_code=result.returncode,ended_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=c.sha(log))
receipt.write_text(json.dumps(r,indent=2)+'\n')
assert result.returncode==0,'retain failed run; no expected-output weakening'
after=c.guards();c.write(ROOT/f'{phase}-guards-after.json',after);assert after==before
r['all_guards_equal']=True
if allocation:
 r['output_sha256']=c.sha(output)
 rows=list(csv.DictReader(output.open()));old=list(csv.DictReader((c.OLD/'allocation-v2-candidate.csv').open()))
 assert len(rows)==len(old)==23
 assert rows[:18]==old[:18],'search setup/construction/clone/boost allocation regression'
 expected_bytes={'native-single-explain':1440000,'native-phrase-explain':2000000,'classic-single-explain':1440000,'classic-phrase-explain':1280000,'no-explain-explain':1280000}
 pairs=[]
 for previous,current in zip(old,rows):
  assert previous['operation']==current['operation']
  assert current['weights_per_repeat']=='1000' and current['repeats']=='3'
  assert current['caller_thread_allocation_calls']==previous['caller_thread_allocation_calls']
  if current['operation'] in expected_bytes:assert int(current['caller_thread_requested_bytes'])==expected_bytes[current['operation']]
  pairs.append({'operation':current['operation'],'p021':previous,'p022':current})
 r.update(first_18_exact_p021=True,all_5_explain_counts_unchanged=True,explain_requested_bytes_restored=True,operations=23,retained_outputs_per_repeat=1000,deterministic_repeats=3,probe_sha256=c.PREPARED['probe_sha256'],manifest_sha256=c.PREPARED['manifest_sha256'],lock_sha256=c.PREPARED['lock_sha256'])
 c.write(ROOT/'allocation-pair-comparison.json',{'candidate_source_sha256':after['candidate_all_source_sha256'],'p021_result_sha256':c.sha(c.OLD/'allocation-v2-candidate.csv'),'p022_result_sha256':c.sha(output),'probe_sha256':c.PREPARED['probe_sha256'],'first_18_exact_p021':True,'all_5_explain_counts_unchanged':True,'explain_requested_bytes_restored':True,'scope':'caller-thread calls/requested bytes only;1000 retained outputs x3 deterministic repetitions;setup/vector excluded;no timing/peakRSS','pairs':pairs})
else:
 assert 'test result: ok. 27 passed; 0 failed;' in log.read_text(),'expected complete targeted BM25 gate'
 r.update(tests_passed=27,frozen_whole_tree_cases=42,frozen_golden_sha256=c.sha(c.WORK/'src/query/bm25_explanation_baseline.json'))
receipt.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({key:value for key,value in r.items() if key!='source_sha256'},indent=2))
