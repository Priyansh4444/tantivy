#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
for phase in ['debug-bm25-04','release-bm25-05','allocation-v2-candidate-06']:
 subprocess.run([sys.executable,str(root/'run-stage2.py'),phase],check=True)
