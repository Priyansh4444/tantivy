#!/usr/bin/env python3
"""Adopt the retained P021 test lock; Git worktrees omit this ignored file."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent.parent
SOURCE=BASE/'tantivy-pruning-explanation-inline-oct05/Cargo.lock'
DESTINATION=BASE/'tantivy-explanation-capacity-oct06/Cargo.lock'
EXPECTED='b71c92f2d72b65c9600602cd05e2938d087cf4fee686f22e46a671e534e15d1d'

def prepare():
    data=SOURCE.read_bytes()
    assert hashlib.sha256(data).hexdigest()==EXPECTED,'retained test lock changed; never resolve new dependencies'
    snapshot=ROOT/'retained-test-Cargo.lock'
    if not snapshot.exists():
        with snapshot.open('xb') as stream:stream.write(data)
    assert snapshot.read_bytes()==data
    if not DESTINATION.exists():
        with DESTINATION.open('xb') as stream:stream.write(data)
    assert DESTINATION.read_bytes()==data,'candidate test lock differs from retained P021 lock'
    return {'original_lock':str(SOURCE),'candidate_lock':str(DESTINATION),'sha256':EXPECTED,
            'adopted_byte_identically':True,'dependency_resolution':False,'worktree_ignored_lock_prepared_explicitly':True}

if __name__=='__main__':print(json.dumps(prepare(),indent=2))
