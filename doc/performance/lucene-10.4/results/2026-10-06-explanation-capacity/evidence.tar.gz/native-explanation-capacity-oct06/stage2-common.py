from pathlib import Path
import hashlib,json,os,subprocess
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent.parent
WORK=BASE/'tantivy-explanation-capacity-oct06'
MAIN=BASE/'tantivy-pr2937'
OLD=BASE/'bench/native-pruning-explanation-inline-oct05'
PREPARED=json.loads((ROOT/'stage2-prepared-receipt.json').read_text())
TEST_LOCK=json.loads((ROOT/'test-lock-adoption-receipt.json').read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path,value):
    with path.open('x') as stream:stream.write(json.dumps(value,indent=2)+'\n')

def guards():
    assert sha(ROOT/'root-source-review-oct06.json')==PREPARED['root_review_sha256']
    expected=PREPARED['candidate_all_source_expected_sha256']
    candidate={name:sha(WORK/name) for name in expected};assert candidate==expected,'reviewed candidate source changed'
    candidate['Cargo.lock']=sha(WORK/'Cargo.lock')
    main={name:sha(MAIN/name) for name in PREPARED['base_all_source_expected_sha256']}
    assert main==PREPARED['base_all_source_expected_sha256'],'main production/source bytes changed from integrated176'
    oldsource={name:sha(BASE/'tantivy-pruning-explanation-inline-oct05'/name) for name in PREPARED['p021_source_sha256']}
    assert oldsource==PREPARED['p021_source_sha256'],'P021 source changed'
    retained={name:sha(OLD/name) for name in PREPARED['retained_p021_artifacts_sha256']}
    assert retained==PREPARED['retained_p021_artifacts_sha256'],'retained P021 artifacts changed'
    assert sha(WORK/'Cargo.lock')==TEST_LOCK['sha256']
    assert sha(BASE/'tantivy-pruning-explanation-inline-oct05/Cargo.lock')==TEST_LOCK['sha256']
    assert sha(ROOT/'retained-test-Cargo.lock')==TEST_LOCK['retained_copy_sha256']
    assert sha(MAIN/'Cargo.lock')==TEST_LOCK['main_lock_sha256'],'main ignored lock changed'
    package=ROOT/'allocation-v2-candidate'
    package_hashes={'probe_sha256':sha(package/'src/main.rs'),'manifest_sha256':sha(package/'Cargo.toml'),'lock_sha256':sha(package/'Cargo.lock')}
    assert all(value==PREPARED[name] for name,value in package_hashes.items()),'allocation package changed'
    return {'candidate_all_source_sha256':candidate,'main_source_equal_integrated176':True,
            'p021_source_unchanged':True,'retained_p021_artifacts_unchanged':True,
            'allocation_package':package_hashes,'root_review_sha256':PREPARED['root_review_sha256'],'adopted_test_lock_sha256':TEST_LOCK['sha256']}

def environment(target,release):
    env=os.environ.copy()
    for key in list(env):
        if key.startswith('CARGO_PROFILE_'):env.pop(key)
    env.pop('CARGO_ENCODED_RUSTFLAGS',None)
    env['RUSTFLAGS']='-C target-cpu=native';env['CARGO_TARGET_DIR']=str(target)
    if release:
        env['CARGO_PROFILE_RELEASE_OPT_LEVEL']='3'
        env['CARGO_PROFILE_RELEASE_LTO']='true'
        env['CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS']='false'
    else:
        env['CARGO_PROFILE_DEV_OPT_LEVEL']='0'
        env['CARGO_PROFILE_DEV_OVERFLOW_CHECKS']='true'
        env['CARGO_PROFILE_TEST_OPT_LEVEL']='0'
        env['CARGO_PROFILE_TEST_OVERFLOW_CHECKS']='true'
    return env

def compiler():
    return {'rustc':subprocess.check_output(['rustc','-Vv'],text=True),
            'cargo':subprocess.check_output(['cargo','-V'],text=True).strip()}
