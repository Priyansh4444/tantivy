#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
for phase in ['debug-bm25-01','release-bm25-02','allocation-v2-candidate-03']:
 subprocess.run([sys.executable,str(root/'run-stage2.py'),phase],check=True)
