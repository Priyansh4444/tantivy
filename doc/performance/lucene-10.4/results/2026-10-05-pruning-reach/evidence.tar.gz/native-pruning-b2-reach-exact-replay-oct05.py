#!/usr/bin/env python3
"""Exact offline replay of observed single-term trajectories; never install skips."""
import ast
from collections import Counter
from fractions import Fraction
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
PROBE = BASE / 'native-pruning-b2-reach-oct05'
OUT = BASE / 'native-pruning-b2-reach-exact-replay-oct05'
ORACLE = BASE / 'native-pruning-finite-independent-compiled-oct05/native-pruning-independent-exact-audit-oct05.py'

# Read the independently reviewed quantizer definitions without running its
# original audit or overwriting its retained receipt. Its executable main starts
# at the assignment to data; reject an unexpected source shape.
tree = ast.parse(ORACLE.read_text())
prefix = []
for node in tree.body:
    if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'data' for t in node.targets):
        break
    prefix.append(node)
else:
    raise AssertionError('independent quantizer main boundary missing')
scope = {}
exec(compile(ast.Module(body=prefix, type_ignores=[]), str(ORACLE), 'exec'), scope)
exact, rounded, product, up, score, cache = [scope[name] for name in ('exact', 'rounded', 'product', 'up', 'score', 'cache')]
INF = 0x7f800000
MAX = 0x7f7fffff

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def optional(value):
    if value == 'None':
        return None
    assert value.startswith('Some(') and value.endswith(')'), value
    return int(value[5:-1])

def classify(bits):
    if bits == INF:
        return 'positive_infinity'
    value = exact(bits)
    if value is None:
        return 'other_exceptional'
    if value < 0 or bits == 0x80000000:
        return 'negative'
    return 'zero' if value == 0 else 'positive_finite'

def prepare(env):
    old = tuple(json.loads(env['old_bits'][5:-1]))
    query = tuple(json.loads(env['q_bits']))
    assert len(old) == len(query) == 256
    assert env['selection_tag'] == 'native_saturation_input_tag1'
    assert env['query_native'] == 'true'
    assert all(classify(a) == 'positive_finite' for a in old)
    assert all(classify(q) in ('zero', 'positive_finite', 'positive_infinity') for q in query)
    # Recompute both actual caches using independently quantized scalar ops and
    # the actual, separately observed averages. Never replace reader provenance.
    average = int(env['selection_average_bits'], 16)
    query_average = int(env['query_average_bits'], 16)
    assert cache(average, 0x3f99999a, 0x3f400000) == old
    assert cache(query_average, int(env['k1_bits'], 16), int(env['b_bits'], 16)) == query
    weight = int(env['weight_bits'], 16)
    assert classify(weight) == 'positive_finite'
    exceptional = [n for n, q in enumerate(query) if q == INF]
    h = min((old[n] for n in exceptional), default=None)
    assert env['h_bits'] == ('none' if h is None else f'{h:08x}')
    ratios = tuple(None if q == INF else 0 if q == 0 else
                   up(rounded(exact(q) / exact(a), 64), 64) for a, q in zip(old, query))
    return old, query, weight, h, ratios

def input_enclosure(m, ratio):
    if ratio == 0:
        return 0
    u = exact(up(m))
    v = up(rounded(u * exact(ratio, 64), 64), 64)
    return up(rounded(exact(v, 64)))

def bound_le_threshold(bound, threshold):
    # The actual collector starts at a negative threshold. Positive native
    # bounds cannot reject against it. Retain IEEE infinity/NaN comparison too.
    assert 0 <= bound <= INF
    value = exact(threshold)
    if value is None:
        return threshold == INF
    if value < 0:
        return False
    return bound != INF and exact(bound) <= value

def analyze(profile):
    record = json.loads((PROBE / (profile + '.records.json')).read_text())
    assert record['top_repeats_identical'] and record['all8_validate_top10_passed'] and record['count_exact_baseline_passed']
    assert len(record['rows']) == 32
    summaries, raw = [], []
    for row in record['rows'][:8]:
        assert row['mode'] == 'TOP_10' and len(row['env']) == 1
        old, query, weight, h, ratios = prepare(row['env'][0])
        counts = Counter()
        relations = Counter()
        examples = {}
        for block in row['blocks']:
            counts['requests'] += 1
            counts['original_predicate_true'] += block['original_predicate'] == 'true'
            if block['status'] != 'complete_native_pair':
                counts[block['status']] += 1
                continue
            counts['complete_pairs'] += 1
            norm = optional(block['selected_norm'])
            tf = optional(block['selected_tf_ceiling'])
            assert 0 <= norm < 256 and 0 < tf <= 0xffffffff
            assert block['tf255'] == str(tf == 0xffffffff).lower()
            m = product(rounded(Fraction(tf)), old[norm])
            assert f'{m:08x}' == block['raw_m_bits']
            relation = 'unavailable' if h is None else 'lt' if m < h else 'eq' if m == h else 'gt'
            assert relation == block['h_relation']
            relations[relation] += 1
            unloaded = block['loaded_before'] == 'false'
            counts['unloaded_complete_pairs'] += unloaded
            bound = int(block['returned_bound_bits'], 16)
            threshold = int(block['threshold_bits'], 16)
            assert bound_le_threshold(bound, threshold) == (block['original_predicate'] == 'true')
            result = {'previous_last': block['previous_last'], 'last': block['last'],
                      'loaded_before': block['loaded_before'], 'm_bits': f'{m:08x}',
                      'h_relation': relation, 'threshold_bits': f'{threshold:08x}',
                      'original_bound_bits': f'{bound:08x}'}
            if not (0 < m < MAX):
                counts['M_guard_reject'] += 1
                result['rejection'] = 'M_guard'
            elif h is not None and m >= h:
                counts['strict_exclusion_reject'] += 1
                counts['unloaded_strict_exclusion_reject'] += unloaded
                result['rejection'] = 'strict_exclusion'
                examples.setdefault(relation, result)
            else:
                counts['eligible'] += 1
                counts['unloaded_eligible'] += unloaded
                finite_ratios = [r for r in ratios if r is not None]
                feasible = [n for n, a in enumerate(old) if a <= m]
                assert feasible and all(query[n] != INF for n in feasible)
                scalar_c = input_enclosure(m, max(finite_ratios, default=0))
                feasible_c = input_enclosure(m, max(ratios[n] for n in feasible))
                scalar_bound, feasible_bound = score(weight, scalar_c), score(weight, feasible_c)
                assert feasible_bound <= scalar_bound <= weight
                result.update(scalar_input_bits=f'{scalar_c:08x}', feasible_input_bits=f'{feasible_c:08x}',
                              scalar_bound_bits=f'{scalar_bound:08x}', feasible_bound_bits=f'{feasible_bound:08x}')
                for label, candidate in [('scalar', scalar_bound), ('feasible', feasible_bound)]:
                    crosses = bound_le_threshold(candidate, threshold) and not bound_le_threshold(bound, threshold)
                    counts[label + '_new_predicted_opportunities'] += crosses
                    counts[label + '_new_predicted_unloaded_opportunities'] += crosses and unloaded
                examples.setdefault('eligible', result)
            raw.append({'profile': profile, 'query': row['query'], **result})
        summaries.append({'query': row['query'], 'h_bits': None if h is None else f'{h:08x}',
                          'query_infinite_codes': sum(q == INF for q in query),
                          'counters': row['counters'], 'counts': dict(counts),
                          'M_H_relations': dict(relations), 'examples': examples})
    return summaries, raw

def main():
    assert not OUT.exists(), 'preserve existing replay evidence'
    summary = json.loads((PROBE / 'summary.json').read_text())
    assert summary['completed'] and summary['untimed'] and summary['guards_equal']
    before, after = [(PROBE / p).read_bytes() for p in ('guards-before.json', 'guards-after.json')]
    assert before == after
    profiles, rows = {}, []
    for profile in ('k25-b1', 'k09-b04'):
        profiles[profile], records = analyze(profile)
        rows.extend(records)
    OUT.mkdir()
    (OUT / 'rows.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in rows))
    result = {'diagnostic_only': True, 'profiles': profiles, 'exact_raw_M_and_cache_checks': True,
              'source_sha256': sha(Path(__file__)), 'quantizer_sha256': sha(ORACLE),
              'probe_summary_sha256': sha(PROBE / 'summary.json'),
              'records_sha256': {p: sha(PROBE / (p + '.records.json')) for p in profiles},
              'rows_sha256': sha(OUT / 'rows.jsonl'),
              'scope': 'Original single-term trajectory; predicted opportunities are not observed new skips or a speed claim.'}
    (OUT / 'summary.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'completed': True, 'profiles': profiles}, indent=2))

if __name__ == '__main__':
    main()
