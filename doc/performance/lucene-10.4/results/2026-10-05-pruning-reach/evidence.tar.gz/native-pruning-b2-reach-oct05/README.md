# Isolated B2 prerequisite reach probe — source prepared, unexecuted

This throwaway probe observes retained B1 commit `b50e2aef3abd77a43fbad56dbaecf2f6c0540a50`. It implements no B2 bound or pruning policy. The main checkout remains untouched; the detached instrumented worktree is `/home/pronsh/Coding/playground/search/tantivy-pruning-b2-reach-oct05`. Every build artifact uses this bench directory's own `target`. Older bench/worktree directories remain intact.

Root must independently read every actual worktree diff, the new `src/reach_probe.rs`, the adapter diff, and `build-and-run.py` before any execution. Preparation has performed source reads, copies, worktree creation, and diff generation only. No compiler, formatter, test, index scan, explicit hashing job, profiling, or timing was run. All hash generation and original hash guards are deferred to the reviewed runner.

## Scope and interpretation

The frozen eight single-term Wiki queries are `the`, `of`, `and`, `united`, `states`, `american`, `york`, and `saxophone`. The runner executes k25/b1 first and k09/b04 as the finite B1 control. Each process receives explicit parameter bits and requires the native BM25 receipt with `N=917578`, `TTF=294827020`, scale1, physical collection statistics, and disabled query cache.

The live threshold is recorded only in `block_wand_single_scorer`. The original `block_max_score()` executes once per original condition evaluation, and its returned bound is still compared with the unchanged `<= threshold` predicate. The original skip body and all score/codec/writer/format logic stay intact. No Boolean per-term bound is compared with a sum threshold. No hypothetical candidate bound or skip is installed or recorded.

`ENV` appears once per owning scorer when the scorer first reaches this real single-scorer predicate. It contains the actual segment/term/boost binding, actual reader selection average and comparator tag, actual query average, literal boosted weight and parameter bits, 256 actual query-cache bits, and 256 old native DEFAULT inverse bits computed once through the same production `compute_tf_cache()` at the actual reader selection average. Query and selection averages are separately captured, never assumed equal. An independent observation context survives B1's pending-to-global transition. A cloned scorer receives a new diagnostic identity and its own first-observation ENV; unprobed exhaustive/count scorers do not emit ENV.

`ENV` retains original `safe_normalization` and `has_safe_score_bounds` flags as observations, not new certificates. Cache classes are counts in this order: positive normal, positive subnormal, +0, -0, +infinity, -infinity, NaN, negative finite. The old all-positive-finite classification is explicit. `H` is the minimum actual old inverse across every actual q=+infinity entry, and is unavailable if the old cache is not all positive finite or there are no exceptional q entries. An H record alone grants no eligibility or soundness claim.

Each `BLOCK` contains owner identity, full Dense/FOR versus VInt tail, selected norm, actual decoded selected TF ceiling, raw `M = RN32(F(selected_tf_ceiling)*old[selected_norm])` bits, strict M/H relation (lt/eq/gt/unordered/unavailable), loaded state before/after the original call, previous/current block endpoints, current scorer doc, exact live threshold bits, actual returned bound bits, global bound bits, original predicate result, and original bound policy before/after. TF code255 is recorded as its **actual decoded `u32::MAX` ceiling**, whose f32 conversion is 2^32; it is a ceiling for the selected posting only. Native complete pairs, unsupported provenance, absent pairs, and tails are recorded separately. The records do not assume TF<=norm, norm0 absence, or block-wide independent TF/norm extrema.

All output is observational. A true original predicate on an unloaded full block records actual original control flow, but it is not a prediction of a new B2 skip. Offline future replay would use the original threshold trajectory and still require later candidate validation. k09 H is ordinarily unavailable because no q=+infinity entry exists; that is a control classification rather than an exclusion failure.

## Runtime effects and protocol

Every runtime effect is explicitly untimed: extra scorer context and clone identity, segment/term binding strings and allocation, one old-cache allocation per observed owner, query-cache Arc clone, cache classification/H scans, bit-vector formatting, raw-M arithmetic, atomics, stderr locks/I/O, parsed trace storage, full exhaustive validation, and before/after file/index hashing. No latency, allocation, RSS, or production layout claim can be made from this binary. Seven atomic counters record literal BM25 score calls, actual term score calls, FOR/Dense/VInt decodes, single-bound requests, and true original predicates. There is no numeric block cache mutation by the probe.

The adapter adds only `QUERY_BEGIN`/`QUERY_END` stderr markers and counter snapshots. Stdout remains the original BM25_CONFIG/TOP/COUNT/VALIDATE protocol. For each profile the runner requires two repeated sets of eight TOP responses=1, repeated counters and complete ENV/BLOCK threshold trajectories identical after normalizing only owner IDs, eight exact COUNT matches against the preserved B1 counter-run baseline, and all eight VALIDATE_TOP_10 responses=1. All raw stdin/stdout/stderr, command arguments, compiler identity, source bindings, live thresholds, process outcomes, binary identity and before/after guards are retained. Unsupported stderr lines remain in raw stderr.

## Review paths and execution command

Read `core-instrumentation.patch` (including the new module), `adapter-instrumentation.patch`, `build-and-run.py`, `build-command.json`, `build-environment.json`, `provenance.json`, `counter-map.json`, and this README. `baseline-source/` stores complete original edited files; `instrumented-source/` stores complete edited source including the module; `baseline-adapter/` stores the original protocol source. `review-package/` stores immutable byte-for-byte review snapshots of runner/adapter/commands/docs. The runner checks baseline copies against `git show <b50>:<path>`, checks approved live source against snapshots, hashes those original/diagnostic files, compares the entire index inventory with the original frozen ruler, and verifies main production source identity via `git diff --quiet b50 -- src Cargo.toml Cargo.lock .cargo` before/after. Probe worktree HEAD must remain exactly b50. Main HEAD/status are recorded separately, allowing root's docs/ledger publication and retained results. It preserves the baseline COUNT stdout and original frozen ruler hashes too.

After root reviews and explicitly authorizes execution:

```sh
python /home/pronsh/Coding/playground/search/bench/native-pruning-b2-reach-oct05/build-and-run.py --root-reviewed
```

Build: `cargo build --locked --release --jobs 4 --bin do_query`, manifest and target directory set to this bench package. `RUSTFLAGS=-C target-cpu=native`; release opt3, LTO=true, overflow-checks=false. The build process has an 1800-second deadline; each profile process has a 600-second deadline, with process-group kill on timeout. Exclusive evidence files prevent overwriting or rerunning an attempted execution. Preparation status is **NOT RUN**; no probe result is claimed yet.

B1 is retained as a bounded roughly29.5% k09 TOP improvement, with paired DEFAULT cost2.2–2.4% documented. Fresh unchanged Lucene T/L k09 ratios1.000555/1.034113 and k25 ratios1.368604/1.258441 still leave the all-query/all-API goal open. This prerequisite cannot establish a full victory or fix finite-profile/default/cold/no-bound/other-API gaps.
