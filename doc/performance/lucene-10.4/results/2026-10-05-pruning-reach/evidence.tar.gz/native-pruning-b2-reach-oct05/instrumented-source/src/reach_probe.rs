//! Throwaway, untimed observation only. No value here participates in scoring.
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;

use crate::index::field_statistics::BlockMaxSelection;
use crate::postings::{BlockInfo, SkipReader};

static NEXT_ID: AtomicU64 = AtomicU64::new(1);
static COUNTERS: [AtomicU64; 7] = [const { AtomicU64::new(0) }; 7];

/// Increment an observational counter in the untimed diagnostic binary.
pub fn hit(index: usize) {
    COUNTERS[index].fetch_add(1, Ordering::Relaxed);
}

/// Reset query-local counters; scorer identities remain globally distinct.
pub fn reset() {
    for counter in &COUNTERS {
        counter.store(0, Ordering::Relaxed);
    }
}

/// Return counters in the external counter-map order.
pub fn snapshot() -> Vec<u64> {
    COUNTERS.iter().map(|counter| counter.load(Ordering::Relaxed)).collect()
}

#[derive(Clone)]
pub(crate) struct WeightSnapshot {
    pub(crate) weight: f32,
    pub(crate) query_average: f32,
    pub(crate) k1: f32,
    pub(crate) b: f32,
    pub(crate) native: bool,
    pub(crate) safe_normalization: bool,
    pub(crate) prior_safe_score_bounds: bool,
    pub(crate) query: Arc<[f32; 256]>,
    pub(crate) old: Option<Arc<[f32; 256]>>,
}

pub(crate) struct ScorerContext {
    id: u64,
    pub(crate) selection: Option<(f32, BlockMaxSelection)>,
    pub(crate) binding: Option<String>,
    pub(crate) snapshot: Option<WeightSnapshot>,
}

// A cloned scorer is a distinct owner, with its own first-observation ENV.
impl Clone for ScorerContext {
    fn clone(&self) -> Self {
        let mut context = Self::new();
        context.selection = self.selection;
        context.binding = self.binding.clone();
        context
    }
}

// Counts, in order: positive normal, positive subnormal, +0, -0, +inf,
// -inf, NaN, negative finite. These are classifications, not score safety proofs.
fn classes(cache: &[f32; 256]) -> [u32; 8] {
    let mut counts = [0; 8];
    for &value in cache {
        let index = if value.is_nan() { 6 }
            else if value == f32::INFINITY { 4 }
            else if value == f32::NEG_INFINITY { 5 }
            else if value.to_bits() == 0 { 2 }
            else if value.to_bits() == 0x8000_0000 { 3 }
            else if value.is_sign_negative() { 7 }
            else if value.is_subnormal() { 1 }
            else { 0 };
        counts[index] += 1;
    }
    counts
}

fn bits(value: Option<f32>) -> String {
    value.map(|value| format!("{:08x}", value.to_bits())).unwrap_or_else(|| "none".into())
}

impl ScorerContext {
    pub(crate) fn new() -> Self {
        Self { id: NEXT_ID.fetch_add(1, Ordering::Relaxed), selection: None,
            binding: None, snapshot: None }
    }

    fn h(&self) -> Option<f32> {
        let snapshot = self.snapshot.as_ref()?;
        let old = snapshot.old.as_ref()?;
        // A raw H is meaningful only after this classification. The record does
        // not grant a production pruning certificate in any domain.
        if !old.iter().all(|value| value.is_finite() && *value > 0.0) {
            return None;
        }
        snapshot.query.iter().zip(old.iter())
            .filter_map(|(&query, &old)| (query == f32::INFINITY).then_some(old))
            .reduce(f32::min)
    }

    pub(crate) fn emit_environment(&self) {
        let snapshot = self.snapshot.as_ref().unwrap();
        let selection_average = self.selection.map(|(average, _)| average);
        let selection_tag = match self.selection.map(|(_, selection)| selection) {
            Some(BlockMaxSelection::NativeSaturationInput) => "native_saturation_input_tag1",
            Some(BlockMaxSelection::LegacyTfFactor) => "legacy_tf_factor",
            None => "unbound",
        };
        let query_bits: Vec<u32> = snapshot.query.iter().map(|value| value.to_bits()).collect();
        let old_bits = snapshot.old.as_ref().map(|old| old.iter().map(|value| value.to_bits()).collect::<Vec<u32>>());
        let old_classes = snapshot.old.as_ref().map(|old| classes(old));
        let old_all_positive_finite = snapshot.old.as_ref()
            .is_some_and(|old| old.iter().all(|value| value.is_finite() && *value > 0.0));
        eprintln!("ENV\tid={}\tbinding={}\tselection_tag={}\tselection_average_bits={}\tquery_average_bits={:08x}\tweight_bits={:08x}\tk1_bits={:08x}\tb_bits={:08x}\tquery_native={}\toriginal_safe_normalization={}\toriginal_has_safe_score_bounds={}\told_all_positive_finite={}\tq_classes={:?}\told_classes={:?}\th_bits={}\tq_bits={:?}\told_bits={:?}",
            self.id, self.binding.as_deref().unwrap_or("unbound"), selection_tag,
            bits(selection_average), snapshot.query_average.to_bits(), snapshot.weight.to_bits(),
            snapshot.k1.to_bits(), snapshot.b.to_bits(), snapshot.native,
            snapshot.safe_normalization, snapshot.prior_safe_score_bounds,
            old_all_positive_finite, classes(&snapshot.query), old_classes,
            bits(self.h()), query_bits, old_bits);
    }

    #[allow(clippy::too_many_arguments)]
    pub(crate) fn emit_block(&self, skip: &SkipReader, loaded_before: bool, loaded_after: bool,
        doc: u32, threshold: f32, returned_bound: f32, global: f32,
        policy_before: &str, policy_after: &str) {
        hit(5);
        let snapshot = self.snapshot.as_ref().unwrap();
        let pair = skip.selected_input_pair();
        let (codec, codec_detail, tail_docs) = match skip.block_info() {
            BlockInfo::Dense { num_longs, .. } => ("dense", u32::from(num_longs), 0),
            BlockInfo::BitPacked { doc_num_bits, .. } => ("for", u32::from(doc_num_bits), 0),
            BlockInfo::VInt { num_docs } => ("vint_tail", 0, num_docs),
        };
        let raw_m = pair.and_then(|pair| snapshot.old.as_ref()
            .map(|old| pair.selected_tf_ceiling.get() as f32 * old[pair.norm as usize]));
        let relation = match (raw_m, self.h()) {
            (Some(m), Some(_)) if m.is_nan() => "unordered",
            (Some(m), Some(h)) if m < h => "lt",
            (Some(m), Some(h)) if m == h => "eq",
            (Some(_), Some(_)) => "gt",
            _ => "unavailable",
        };
        let status = if codec == "vint_tail" { "tail" }
            else if pair.is_none() { "absent_pair" }
            else if !snapshot.native || !matches!(self.selection,
                Some((_, BlockMaxSelection::NativeSaturationInput))) { "unsupported_provenance" }
            else { "complete_native_pair" };
        eprintln!("BLOCK\tid={}\tstatus={}\tcodec={}\tcodec_detail={}\ttail_docs={}\tprevious_last={}\tlast={}\tcurrent_doc={}\tloaded_before={}\tloaded_after={}\tselected_norm={:?}\tselected_tf_ceiling={:?}\ttf255={}\traw_m_bits={}\th_relation={}\tthreshold_bits={:08x}\treturned_bound_bits={:08x}\tglobal_bound_bits={:08x}\toriginal_predicate={}\tpolicy_before={}\tpolicy_after={}",
            self.id, status, codec, codec_detail, tail_docs, skip.last_doc_in_previous_block,
            skip.last_doc_in_block(), doc, loaded_before, loaded_after,
            pair.map(|pair| pair.norm), pair.map(|pair| pair.selected_tf_ceiling.get()),
            pair.is_some_and(|pair| pair.selected_tf_ceiling.get() == u32::MAX),
            bits(raw_m), relation, threshold.to_bits(), returned_bound.to_bits(), global.to_bits(),
            returned_bound <= threshold, policy_before, policy_after);
    }
}
