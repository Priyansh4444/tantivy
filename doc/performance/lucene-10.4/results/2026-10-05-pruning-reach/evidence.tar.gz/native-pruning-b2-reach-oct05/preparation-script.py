from pathlib import Path
import shutil, subprocess, json, os
BASE=Path('/home/pronsh/Coding/playground/search')
REPO=BASE/'tantivy-pr2937'
WT=BASE/'tantivy-pruning-b2-reach-oct05'
OUT=BASE/'bench/native-pruning-b2-reach-oct05'
COMMIT='b50e2aef3abd77a43fbad56dbaecf2f6c0540a50'
FILES=['src/lib.rs','src/query/bm25.rs','src/query/term_query/term_scorer.rs','src/query/term_query/term_weight.rs','src/query/boolean_query/block_wand_union.rs','src/postings/block_segment_postings.rs']
def run(argv): return subprocess.run(argv,text=True,capture_output=True,check=True).stdout
assert not os.path.lexists(WT) and not os.path.lexists(OUT)
assert run(['git','-C',str(REPO),'rev-parse','HEAD']).strip()==COMMIT
assert not run(['git','-C',str(REPO),'status','--porcelain'])
OUT.mkdir()
shutil.copyfile(__file__,OUT/'preparation-script.py')
run(['git','-C',str(REPO),'worktree','add','--detach',str(WT),COMMIT])
for rel in FILES:
 p=OUT/'baseline-source'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(WT/rel,p)
def replace(rel,old,new):
 p=WT/rel;s=p.read_text();assert s.count(old)==1,(rel,old,s.count(old));p.write_text(s.replace(old,new))
replace('src/lib.rs','pub mod query;','pub mod query;\n\n#[doc(hidden)]\npub mod reach_probe;')
replace('src/query/bm25.rs','impl Bm25Weight {','''impl Bm25Weight {
    // Diagnostic only: copies the actual query cache and calls the production
    // cache routine at the actual reader selection average. Never used by bounds.
    pub(crate) fn reach_snapshot(&self, selection_average: Option<Score>) -> crate::reach_probe::WeightSnapshot {
        crate::reach_probe::WeightSnapshot {
            weight: self.weight,
            query_average: self.average_fieldnorm,
            k1: self.parameters.k1(),
            b: self.parameters.b(),
            native: self.scoring == Bm25Scoring::NativeLucene,
            safe_normalization: self.safe_normalization,
            prior_safe_score_bounds: self.has_safe_score_bounds(),
            query: self.cache.clone(),
            old: selection_average.map(|average| compute_tf_cache(
                average, Bm25Scoring::NativeLucene, Bm25Parameters::DEFAULT).0),
        }
    }
''')
replace('src/query/bm25.rs','pub fn score(&self, fieldnorm_id: u8, term_freq: u32) -> Score {','pub fn score(&self, fieldnorm_id: u8, term_freq: u32) -> Score {\n        crate::reach_probe::hit(0);')
rel='src/query/term_query/term_scorer.rs'
replace(rel,'use_alternate_mask: bool,','use_alternate_mask: bool,\n    reach: crate::reach_probe::ScorerContext,')
replace(rel,'            use_alternate_mask,','            use_alternate_mask,\n            reach: crate::reach_probe::ScorerContext::new(),')
replace(rel,'    ) -> Self {\n        self.block_bounds = if self','    ) -> Self {\n        self.reach.selection = Some((average_fieldnorm, selection));\n        self.block_bounds = if self')
replace(rel,'    pub(crate) fn seek_block(&mut self, target_doc: DocId) {','''    pub(crate) fn with_reach_binding(mut self, binding: String) -> Self {
        self.reach.binding = Some(binding);
        self
    }

    // Called only by the real single-term <= threshold predicate. The original
    // bound method executes exactly once; logging never loads postings or scores.
    pub(crate) fn reach_block_max_score(&mut self, threshold: Score) -> Score {
        if self.reach.snapshot.is_none() {
            let average = self.reach.selection.map(|(average, _)| average);
            self.reach.snapshot = Some(self.similarity_weight.reach_snapshot(average));
            self.reach.emit_environment();
        }
        let policy_before = self.reach_policy();
        let loaded_before = self.postings.block_cursor.block_is_loaded();
        let bound = self.block_max_score();
        let policy_after = self.reach_policy();
        self.reach.emit_block(
            self.postings.block_cursor.skip_reader(),
            loaded_before,
            self.postings.block_cursor.block_is_loaded(),
            self.doc(), threshold, bound, self.max_score(),
            policy_before, policy_after,
        );
        bound
    }

    fn reach_policy(&self) -> &'static str {
        match self.block_bounds {
            TermBlockBounds::Global => "global",
            TermBlockBounds::StoredDefault => "stored_default",
            TermBlockBounds::PendingNative(_) => "pending_native",
            TermBlockBounds::NativeTransform(_) => "native_transform",
        }
    }

    pub(crate) fn seek_block(&mut self, target_doc: DocId) {''')
replace(rel,'fn score(&mut self) -> Score {','fn score(&mut self) -> Score {\n        crate::reach_probe::hit(1);')
rel='src/query/term_query/term_weight.rs'
replace(rel,'                    inverted_index.stored_block_max_selection(),\n                ),','''                    inverted_index.stored_block_max_selection(),
                )
                .with_reach_binding(format!("segment={:?};term={:?};boost_bits={:08x}",
                    reader.segment_id(), self.term, boost.to_bits())),''')
replace('src/query/boolean_query/block_wand_union.rs','while scorer.block_max_score() <= threshold {','while scorer.reach_block_max_score(threshold) <= threshold {\n            crate::reach_probe::hit(6);')
rel='src/postings/block_segment_postings.rs'
for name,index in [('decode_bitpacked_block',2),('decode_dense_block',3),('decode_vint_block',4)]:
 replace(rel,name+'(\n                    &mut self.doc_decoder,',f'crate::reach_probe::hit({index});\n                '+name+'(\n                    &mut self.doc_decoder,')
# No build, format, test, index read or hash is performed by preparation.
(OUT/'counter-map.json').write_text(json.dumps(['bm25_score_calls','term_score_calls','for_decodes','dense_decodes','vint_decodes','single_bound_requests','single_predicate_true'],indent=2)+'\n')
adapter=OUT/'adapter';(adapter/'src/bin/shared').mkdir(parents=True)
source=WT/'doc/performance/lucene-10.4'
shutil.copyfile(source/'shared/bm25_profile.rs',adapter/'src/bin/shared/bm25_profile.rs')
query=(source/'do_query.rs').read_text()
query=query.replace('let query = query_parser.parse_query(fields[1])?;', '''tantivy::reach_probe::reset();
        eprintln!("QUERY_BEGIN\\tmode={}\\tquery={}", command, fields[1]);
        let query = query_parser.parse_query(fields[1])?;''')
query=query.replace('println!("{}", count);','''eprintln!("QUERY_END\\tmode={}\\tquery={}\\tcounters={:?}",
            command, fields[1], tantivy::reach_probe::snapshot());
        println!("{}", count);''')
(adapter/'src/bin/do_query.rs').write_text(query)
manifest=(BASE/'bench/native-pruning-finite-counters-oct05/adapter/Cargo.toml').read_text().replace('wiki-pruning-counters','wiki-b2-reach').replace(str(BASE/'tantivy-pruning-finite-counters-oct05'),str(WT))
(adapter/'Cargo.toml').write_text(manifest)
lock=(BASE/'bench/native-pruning-finite-counters-oct05/adapter/Cargo.lock').read_text().replace('name = "wiki-pruning-counters"','name = "wiki-b2-reach"')
(adapter/'Cargo.lock').write_text(lock)
(OUT/'build-command.json').write_text(json.dumps(['cargo','build','--manifest-path',str(adapter/'Cargo.toml'),'--target-dir',str(OUT/'target'),'--locked','--release','--jobs','4','--bin','do_query'],indent=2)+'\n')
(OUT/'build-environment.json').write_text(json.dumps({'RUSTFLAGS':'-C target-cpu=native','lto':True,'opt-level':3,'overflow-checks':False,'jobs':4,'status':'NOT RUN; root full actual diff and runner review required'},indent=2)+'\n')
(OUT/'provenance.json').write_text(json.dumps({'baseline_commit':COMMIT,'worktree':str(WT),'main_repo':str(REPO),'out':str(OUT),'baseline_files':FILES,'query_suite':str(source/'queries-wiki.jsonl'),'query_suite_expected_sha256':'47feb065c35e50ef465beab072ae8549ffef9dd23e20e708c458139adcfccfc5','untimed':True,'execution_status':'not started','hash_status':'all hashing deferred to reviewed runner; baseline copies guarded against original git objects then'},indent=2)+'\n')
print('Prepared worktree/adapter source only. Module and runner follow; no build/runtime/hash.')
