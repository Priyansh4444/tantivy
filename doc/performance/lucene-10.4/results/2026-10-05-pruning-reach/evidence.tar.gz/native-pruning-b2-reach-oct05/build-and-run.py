#!/usr/bin/env python3
"""Reviewed, bounded, untimed diagnostic. Preserves all prior artifacts."""
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess

OUT = Path(__file__).resolve().parent
BASE = OUT.parent.parent
WT = BASE / 'tantivy-pruning-b2-reach-oct05'
REPO = BASE / 'tantivy-pr2937'
INDEX = BASE / 'bench/wiki-1m-native-aligned-v11-oct05.idx'
OLD = BASE / 'bench/native-pruning-finite-counters-oct05'
COMMIT = 'b50e2aef3abd77a43fbad56dbaecf2f6c0540a50'
QUERY_SHA = '47feb065c35e50ef465beab072ae8549ffef9dd23e20e708c458139adcfccfc5'
TOOLS = WT / 'doc/performance/lucene-10.4'
PROFILES = {'k25-b1': ('40200000', '3f800000'), 'k09-b04': ('3f666666', '3ecccccd')}
QUERIES = ['the', 'of', 'and', 'united', 'states', 'american', 'york', 'saxophone']


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(name, value):
    with (OUT / name).open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def git(argv, cwd=WT):
    return subprocess.check_output(['git', '-C', str(cwd), *argv])


def guards():
    assert git(['rev-parse', 'HEAD']).decode().strip() == COMMIT
    assert subprocess.run(['git', '-C', str(REPO), 'diff', '--quiet', COMMIT, '--',
        'src', 'Cargo.toml', 'Cargo.lock', '.cargo']).returncode == 0, 'main production source differs from b50'
    provenance = json.loads((OUT / 'provenance.json').read_text())
    assert git(['status', '--porcelain']).decode() == provenance['instrumented_git_status'], \
        'unexpected worktree mutation outside reviewed source'
    originals = {}
    for rel in provenance['baseline_files']:
        original = git(['show', COMMIT + ':' + rel])
        snapshot = OUT / 'baseline-source' / rel
        assert snapshot.read_bytes() == original, ('original source guard', rel)
        originals[rel] = hashlib.sha256(original).hexdigest()
    for rel in ['do_query.rs', 'shared/bm25_profile.rs']:
        original = git(['show', COMMIT + ':doc/performance/lucene-10.4/' + rel])
        assert (OUT / 'baseline-adapter' / rel).read_bytes() == original
        originals['doc/performance/lucene-10.4/' + rel] = hashlib.sha256(original).hexdigest()
    source_hashes = {}
    for snapshot in sorted((OUT / 'instrumented-source').rglob('*')):
        if snapshot.is_file():
            live = WT / snapshot.relative_to(OUT / 'instrumented-source')
            assert live.read_bytes() == snapshot.read_bytes(), ('reviewed source changed', live)
            source_hashes[str(live)] = sha(live)
    for snapshot in sorted((OUT / 'review-package').rglob('*')):
        if snapshot.is_file():
            live = OUT / snapshot.relative_to(OUT / 'review-package')
            assert live.read_bytes() == snapshot.read_bytes(), ('reviewed runner/adapter changed', live)
            source_hashes[str(live)] = sha(live)
    assert sha(TOOLS / 'queries-wiki.jsonl') == QUERY_SHA
    source_hashes[str(TOOLS / 'queries-wiki.jsonl')] = QUERY_SHA
    frozen_path = BASE / 'bench/native-profile-aligned-oct05/frozen-ruler.json'
    frozen = json.loads(frozen_path.read_text())
    expected = {path: row for path, row in frozen['artifacts'].items() if Path(path).parent == INDEX}
    actual = {}
    for path in sorted(INDEX.rglob('*')):
        assert not path.is_symlink(), ('index symlink', path)
        if path.is_file():
            actual[str(path)] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
    assert actual == expected, 'index differs from original frozen ruler'
    # Preserved exact COUNT baseline and original source provenance are guarded
    # before/after. No old directory receives a write.
    retained = {str(path): sha(path) for path in [frozen_path, OLD / 'summary.json',
        OLD / 'k25-b1.stdout', OLD / 'k09-b04.stdout',
        BASE / 'bench/native-pruning-b2-arena-brief-oct05.md',
        BASE / 'bench/native-pruning-b2-design-judge-oct05.md']}
    return {'commit': COMMIT, 'original_source_sha256': originals,
        'reviewed_source_sha256': source_hashes, 'index': actual, 'retained_sha256': retained}


def bounded(argv, timeout, *, payload=None, env=None, stdout=None, stderr=None):
    process = subprocess.Popen(argv, stdin=subprocess.PIPE if payload is not None else subprocess.DEVNULL,
        stdout=stdout if stdout is not None else subprocess.PIPE,
        stderr=stderr if stderr is not None else subprocess.PIPE,
        text=True, env=env, start_new_session=True)
    timed_out = False
    try:
        output, errors = process.communicate(payload, timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        output, errors = process.communicate(timeout=5)
    except BaseException:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait(timeout=5)
        raise
    return subprocess.CompletedProcess(argv, process.returncode, output, errors), timed_out


def parse_records(stderr, requests, names):
    sections = []
    section = None
    env_ids = set()
    for line in stderr.splitlines():
        parts = line.split('\t')
        kind = parts[0]
        if kind not in ('QUERY_BEGIN', 'QUERY_END', 'ENV', 'BLOCK'):
            continue  # Preserve all raw stderr, including warnings, separately.
        values = dict(part.split('=', 1) for part in parts[1:])
        if kind == 'QUERY_BEGIN':
            assert section is None
            section = {'mode': values['mode'], 'query': values['query'], 'env': [], 'blocks': []}
            env_ids = set()
        elif kind == 'ENV':
            assert section is not None
            assert values['id'] not in env_ids, 'multiple ENV per owning scorer'
            env_ids.add(values['id'])
            assert len(json.loads(values['q_bits'])) == 256
            # Rust Option debug wrapper is retained in raw stderr; no bit reconstruction.
            assert values['old_bits'].startswith('Some('), 'actual reader old cache missing'
            assert len(json.loads(values['old_bits'][5:-1])) == 256
            section['env'].append(values)
        elif kind == 'BLOCK':
            assert section is not None and values['id'] in env_ids
            section['blocks'].append(values)
        else:
            assert section is not None
            assert (values['mode'], values['query']) == (section['mode'], section['query'])
            counters = json.loads(values['counters'])
            assert len(counters) == len(names)
            assert all(type(value) is int and value >= 0 for value in counters)
            section['counters'] = dict(zip(names, counters, strict=True))
            assert section['counters']['single_bound_requests'] == len(section['blocks'])
            assert section['counters']['single_predicate_true'] == sum(
                block['original_predicate'] == 'true' for block in section['blocks'])
            if section['mode'] == 'COUNT':
                assert not section['env'] and not section['blocks']
                assert section['counters']['term_score_calls'] == 0
            else:
                assert section['env'] and section['blocks'], 'single-term route was not observed'
            sections.append(section)
            section = None
    assert section is None
    assert [(row['mode'], row['query']) for row in sections] == requests
    # Repeated TOP observations must be bit-identical on the original trajectory.
    # Owner IDs are deliberately distinct, so normalize only this identity field.
    def normalize(row):
        row = json.loads(json.dumps(row))
        identifiers = {env['id']: str(index) for index, env in enumerate(row['env'])}
        for record in row['env'] + row['blocks']:
            record['id'] = identifiers[record['id']]
        return row
    assert [normalize(row) for row in sections[:8]] == [normalize(row) for row in sections[8:16]], \
        'repeated TOP outputs/counters/threshold trajectory differ'
    return sections


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root-reviewed', action='store_true', required=True,
        help='root has independently reviewed every actual source diff and this runner')
    parser.parse_args()
    assert not (OUT / 'execution-started.json').exists(), 'preserve prior execution; do not overwrite'
    write('execution-started.json', {'utc': datetime.now(timezone.utc).isoformat(),
        'untimed': True, 'status': 'reviewed diagnostic execution started'})
    before = guards()
    write('guards-before.json', before)
    write('main-status-at-start.json', {'head': git(['rev-parse', 'HEAD'], REPO).decode().strip(),
        'status': git(['status', '--porcelain'], REPO).decode(),
        'note': 'root docs/ledger publication is allowed; src/Cargo.toml/Cargo.lock/.cargo must match b50'})
    compiler = {name: subprocess.check_output([name, '--version'], text=True).strip()
        for name in ['rustc', 'cargo']}
    compiler['rustc_verbose'] = subprocess.check_output(['rustc', '-Vv'], text=True)
    write('compiler.json', compiler)
    command = json.loads((OUT / 'build-command.json').read_text())
    env = os.environ.copy()
    env['RUSTFLAGS'] = '-C target-cpu=native'
    with (OUT / 'build.stdout').open('x') as stdout, (OUT / 'build.stderr').open('x') as stderr:
        result, timeout = bounded(command, 1800, env=env, stdout=stdout, stderr=stderr)
    write('build-result.json', {'command': command, 'RUSTFLAGS': env['RUSTFLAGS'],
        'returncode': result.returncode, 'timed_out': timeout, 'untimed': True})
    assert result.returncode == 0 and not timeout, 'build failed; retain evidence'
    assert guards() == before
    binary = OUT / 'do_query-reach'
    assert not binary.exists()
    shutil.copyfile(OUT / 'target/release/do_query', binary)
    binary.chmod(0o755)
    identity = {'sha256': sha(binary), 'bytes': binary.stat().st_size, 'commit': COMMIT}
    write('binary-identity.json', identity)
    suite = [json.loads(line) for line in (TOOLS / 'queries-wiki.jsonl').read_text().splitlines()]
    assert [row['query'] for row in suite if 'term' in row['tags']] == QUERIES
    names = json.loads((OUT / 'counter-map.json').read_text())
    requests = [('TOP_10', query) for _ in range(2) for query in QUERIES]
    requests += [('COUNT', query) for query in QUERIES]
    requests += [('VALIDATE_TOP_10', query) for query in QUERIES]
    payload = 'BM25_CONFIG\t\n' + ''.join(mode + '\t' + query + '\n' for mode, query in requests)
    summary = {}
    for profile, (k1, b) in PROFILES.items():
        argv = [str(binary), str(INDEX), k1, b]
        write(profile + '.command.json', {'argv': argv, 'timeout_seconds': 600, 'untimed': True})
        with (OUT / (profile + '.stdin')).open('x') as stream:
            stream.write(payload)
        result, timeout = bounded(argv, 600, payload=payload)
        for suffix, data in [('stdout', result.stdout), ('stderr', result.stderr)]:
            with (OUT / (profile + '.' + suffix)).open('x') as stream:
                stream.write(data)
        write(profile + '.process-result.json', {'returncode': result.returncode, 'timed_out': timeout})
        assert result.returncode == 0 and not timeout, (profile, 'failed process')
        lines = result.stdout.splitlines()
        assert len(lines) == 33
        receipt = json.loads(lines[0])
        assert receipt == {'protocol': 'bm25-profile-v1', 'engine': 'tantivy', 'field': 'text',
            'k1_bits': k1, 'b_bits': b, 'scale_bits': '3f800000',
            'collection_statistics': 'physical', 'query_cache': 'disabled',
            'doc_count': 917578, 'sum_total_term_freq': 294827020}, receipt
        assert lines[1:17] == ['1'] * 16
        assert lines[25:33] == ['1'] * 8, 'all eight exhaustive validators must pass'
        old_lines = (OLD / (profile + '.stdout')).read_text().splitlines()
        assert len(old_lines) == 81
        assert lines[17:25] == old_lines[41:49], 'COUNT exact preserved baseline mismatch'
        rows = parse_records(result.stderr, requests, names)
        summary[profile] = {'receipt': receipt, 'rows': rows, 'count_responses': lines[17:25],
            'top_repeats_identical': True, 'all8_validate_top10_passed': True,
            'count_exact_baseline_passed': True}
        write(profile + '.records.json', summary[profile])
    after = guards()
    write('guards-after.json', after)
    write('main-status-at-end.json', {'head': git(['rev-parse', 'HEAD'], REPO).decode().strip(),
        'status': git(['status', '--porcelain'], REPO).decode()})
    assert after == before
    assert sha(binary) == identity['sha256']
    write('summary.json', {'untimed': True, 'completed': True, 'commit': COMMIT,
        'binary_identity': identity, 'guards_equal': True, 'profiles': summary,
        'scope': 'single-term original trajectory observation; no B2 policy, hypothetical skip, timing or all-API claim'})
    print(json.dumps({'completed': True, 'untimed': True, 'profiles': 2, 'queries_each': 8,
        'summary_sha256': sha(OUT / 'summary.json')}))


if __name__ == '__main__':
    main()
