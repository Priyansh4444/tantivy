from pathlib import Path
import shutil, subprocess, json
BASE=Path('/home/pronsh/Coding/playground/search')
WT=BASE/'tantivy-pruning-b2-reach-oct05'
OUT=BASE/'bench/native-pruning-b2-reach-oct05'
def run(argv, allowed=(0,)):
 p=subprocess.run(argv,capture_output=True,text=True);assert p.returncode in allowed,(argv,p.stderr);return p.stdout
provenance=json.loads((OUT/'provenance.json').read_text())
provenance['instrumented_git_status']=run(['git','-C',str(WT),'status','--porcelain'])
provenance['review_scope']='six tracked core files plus new diagnostic module; adapter and runner copied into isolated bench; no runtime/build/hash job performed'
(OUT/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
for rel in provenance['baseline_files']+['src/reach_probe.rs']:
 p=OUT/'instrumented-source'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(WT/rel,p)
for rel in ['do_query.rs','shared/bm25_profile.rs']:
 p=OUT/'baseline-adapter'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(WT/'doc/performance/lucene-10.4'/rel,p)
tracked=run(['git','-C',str(WT),'diff','--no-ext-diff','--src-prefix=a/','--dst-prefix=b/'])
module=run(['git','diff','--no-index','--no-ext-diff','--src-prefix=a/','--dst-prefix=b/','--','/dev/null',str(WT/'src/reach_probe.rs')],allowed=(1,))
module=module.replace(str(WT)+'/', '/')
(OUT/'core-instrumentation.patch').write_text(tracked+module)
(OUT/'adapter-instrumentation.patch').write_text(run(['git','diff','--no-index','--no-ext-diff','--',str(OUT/'baseline-adapter/do_query.rs'),str(OUT/'adapter/src/bin/do_query.rs')],allowed=(1,)))
shutil.copyfile(__file__,OUT/'finalize-preparation.py')
review_files=['build-and-run.py','build-command.json','build-environment.json','provenance.json','counter-map.json','README.md','core-instrumentation.patch','adapter-instrumentation.patch','preparation-script.py','finalize-preparation.py']
review_files += [str(p.relative_to(OUT)) for p in (OUT/'adapter').rglob('*') if p.is_file()]
for rel in review_files:
 p=OUT/'review-package'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(OUT/rel,p)
(OUT/'preparation-receipt.json').write_text(json.dumps({'status':'READY FOR ROOT REVIEW; NOT BUILT OR RUN','baseline_commit':provenance['baseline_commit'],'instrumented_worktree':str(WT),'reviewed_snapshot_files':review_files,'explicit_hashing':'not performed; deferred to reviewed runner','runtime_status':'not started','main_git_status':run(['git','-C',str(BASE/'tantivy-pr2937'),'status','--porcelain']),'instrumented_git_status':provenance['instrumented_git_status']},indent=2)+'\n')
print('Review package ready. No build/runtime/index/hash job executed.')
