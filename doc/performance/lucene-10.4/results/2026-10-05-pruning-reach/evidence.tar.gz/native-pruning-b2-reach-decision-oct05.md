# B2 observed information limit and disposition

Production B2 deferred: the three same-format designs cannot solve the dense single-term losses.

Root fully reviewed actual source and runner before build. Untimed native binary 1e0df74e31265bf255180ff88e455835221f76cbde05daf88beb9cc1d1cc8eab passes two full TOP threshold/counter trajectories, all8 exact COUNT baselines and all8 exhaustive validators for k25 and k09. Source and full frozen index inventories remain identical. Exact rational IEEE32/IEEE64 replay independently reconstructed all16 actual old/query caches and all complete-pair M/H classifications.

| k25 query | Unloaded full requests | Strict eligible | Scalar predicted extra | Feasible predicted extra |
| --- | ---: | ---: | ---: | ---: |
| the | 6441 | 0 | 0 | 0 |
| of | 5927 | 0 | 0 | 0 |
| and | 5377 | 0 | 0 | 0 |
| united | 916 | 9 | 0 | 7 |
| states | 845 | 13 | 0 | 8 |
| american | 928 | 13 | 0 | 9 |
| york | 424 | 0 | 0 | 0 |
| saxophone | 6 | 0 | 0 | 0 |

All17745 unloaded the/of/and requests fail strict exclusion. Only35/20864 full unloaded requests qualify overall (0.168%); scalar produces zero predicted extra opportunities, feasible produces24/20864 (0.115%). These are comparisons against original live thresholds, not observed candidate skips, changed execution, or a speed claim. Exact TF-cap cannot repair any failing exclusion, so its ceiling is the same35 eligible blocks; no need to implement its expensive table to reject it as the dense-gap solution. The remaining35 narrow blocks may justify revisiting a cheaper design on a different workload, not a production policy on this ruler.

The finite k09 control produces zero extra opportunities for either scalar or feasible; retained B1 bound already matches their score bounds on these selected pairs. No conclusion about all Boolean thresholds, rare terms or all corpora is implied.

Replay initially rejected the actual negative f32MIN starting collector threshold because its local assumption incorrectly required a nonnegative threshold. Root corrected offline comparison to retain IEEE signed/infinite/NaN threshold semantics before any output directory was created. All original raw input remains unchanged. Final artifacts: native-pruning-b2-reach-oct05/{summary,execution-evidence,guards-before,guards-after}.json; native-pruning-b2-reach-exact-replay-oct05/{summary.json,rows.jsonl}; native-pruning-b2-reach-exact-replay-oct05.py. No new production source or timing claim.

Next category: eliminate explanation tree construction/deep clones from ordinary query setup; source bm25.rs builds eager IDF trees in for_terms/for_one_term, then derived Clone and boost_by duplicate them per scorer although score/block bounds never read them. Design and measure one isolated representation change against b50, preserving all explanation/scalar/profile contracts. Richer metadata/format remains a separate future category.
