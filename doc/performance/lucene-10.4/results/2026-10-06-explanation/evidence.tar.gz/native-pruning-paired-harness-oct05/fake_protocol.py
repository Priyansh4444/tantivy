#!/usr/bin/env python3
"""Fixture child; never use for performance measurements."""
import json
import os
from pathlib import Path
import signal
import sys
import time

config = json.loads(Path(__file__).with_suffix('.config.json').read_text())
with Path(config['log']).open('a') as log:
    log.write(json.dumps({'event': 'start', 'pid': os.getpid(), 'argv': sys.argv}) + '\n')
    log.flush()
    if config['mode'] == 'ignore_eof':
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
    queries = 0
    for line in sys.stdin:
        command, value = line.rstrip('\n').split('\t', 1)
        log.write(json.dumps({'event': 'request', 'command': command, 'value': value}) + '\n')
        log.flush()
        if command == 'BM25_CONFIG':
            if config['mode'] == 'ack_eof':
                sys.exit(3)
            if config['mode'] == 'ack_hang':
                time.sleep(30)
            if config['mode'] == 'ack_overline':
                print('x' * 4097, flush=True)
                continue
            if config['mode'] == 'ack_error':
                print('ERROR fixture', flush=True)
                continue
            receipt = {'protocol': 'bm25-profile-v1', 'engine': 'tantivy', 'field': 'text',
                       'k1_bits': sys.argv[2], 'b_bits': sys.argv[3], 'scale_bits': '3f800000',
                       'collection_statistics': 'physical', 'query_cache': 'disabled',
                       'doc_count': 23, 'sum_total_term_freq': 456}
            receipt.update(config.get('receipt', {}))
            encoded = json.dumps(receipt) + '\n'
            if config['mode'] == 'ack_extra':
                encoded += '12\n'
            sys.stdout.write(encoded)
            sys.stdout.flush()
            continue
        queries += 1
        if config['mode'] == 'query_eof':
            sys.exit(4)
        if config['mode'] == 'query_hang':
            time.sleep(30)
        if config['mode'] == 'query_overline':
            print('9' * 65, flush=True)
            continue
        if config['mode'] == 'query_error':
            print('ERROR fixture', flush=True)
            continue
        count = sum(value.encode()) % 100 + int(config.get('count_delta', 0))
        if config['mode'] == 'late_count_mismatch' and queries > 20:
            count += 1
        if config['mode'] == 'query_extra':
            sys.stdout.write(f'{count}\n{count}\n')
            sys.stdout.flush()
        else:
            print(count, flush=True)
        if config['mode'] == 'delayed_extra':
            time.sleep(.03)
            print(count, flush=True)
    if config['mode'] == 'ignore_eof':
        while True:
            time.sleep(1)
    log.write(json.dumps({'event': 'eof'}) + '\n')
