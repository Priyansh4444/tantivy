#!/usr/bin/env python3
"""Deterministic boundary/lifecycle checks with fake children, never timed engines."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import selectors
import shutil
import subprocess
import sys
import time
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('paired', HERE / 'suite_paired.py')
paired = importlib.util.module_from_spec(spec)
spec.loader.exec_module(paired)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def alive(pid):
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    root = args.output.absolute()
    root.mkdir()  # never overwrite evidence from another invocation
    commit = subprocess.check_output(['git', '-C', str(paired.SOURCE), 'rev-parse', 'HEAD'], text=True).strip()
    records = []

    def fixture(name, *, mode='normal', receipt=None, count_delta=0, flags=(), prepare=None, success=False,
                expected_error=None, expected_starts=None):
        case = root / name
        case.mkdir()
        index = case / 'index'
        index.mkdir()
        (index / 'payload').write_bytes(b'fake index identity only\x00\xff')
        binaries = {}
        for label in ('baseline', 'candidate'):
            directory = case / label
            directory.mkdir()
            binary = directory / 'fake_protocol.py'
            shutil.copyfile(HERE / 'fake_protocol.py', binary)
            binary.chmod(0o755)
            config = {'log': str(directory / 'lifecycle.jsonl'), 'mode': mode if label == 'candidate' else 'normal',
                      'receipt': (receipt or {}) if label == 'candidate' else {}, 'count_delta': count_delta if label == 'candidate' else 0}
            binary.with_suffix('.config.json').write_text(json.dumps(config))
            (directory / 'provenance.json').write_text(json.dumps({'commit': commit,
                                            'binaries_sha256': {binary.name: sha(binary)}}))
            binaries[label] = binary
        output = case / 'measurement.json'
        command = [sys.executable, str(HERE / 'suite_paired.py'), '--baseline-binary', str(binaries['baseline']),
                   '--candidate-binary', str(binaries['candidate']), '--index', str(index), '--profile', 'default',
                   '--command', 'COUNT', '--cpu-core', 'none', '--warmup-seconds', '0', '--iterations', '2',
                   '--request-timeout', '.12', '--output', str(output),
                   '--baseline-source-commit', commit, '--candidate-source-commit', commit] + list(flags)
        if prepare:
            prepare(case, binaries, index, output)
        started = time.monotonic()
        run = subprocess.run(command, capture_output=True, text=True, timeout=12)
        elapsed = time.monotonic() - started
        (case / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
        (case / 'stdout.txt').write_text(run.stdout)
        (case / 'stderr.txt').write_text(run.stderr)
        pids, requests = [], {}
        for label in binaries:
            log = case / label / 'lifecycle.jsonl'
            events = [json.loads(line) for line in log.read_text().splitlines()] if log.exists() else []
            pids += [event['pid'] for event in events if event['event'] == 'start']
            requests[label] = sum(event['event'] == 'request' for event in events)
        assert all(not alive(pid) for pid in pids), (name, 'unreaped child', pids)
        if expected_starts is not None:
            assert len(pids) == expected_starts, (name, pids)
        if success:
            assert run.returncode == 0, (name, run.stderr)
            result = json.loads(output.read_text())
            sidecar = output.with_name(output.name + '.sha256')
            assert sidecar.read_text().split()[0] == sha(output), name
            assert result['completed'] is True and result['engines'] == {'baseline': 'tantivy', 'candidate': 'tantivy'}
            assert result['provenance_before'] == result['provenance_after'], name
            assert all(len(values) == 2 for rows in result['samples_us'].values() for values in rows.values())
            assert all(count == sum(q.encode()) % 100 for q, count in result['counts'].items()), name
            assert requests == {'baseline': 61, 'candidate': 61}, (name, requests)
        else:
            assert run.returncode != 0, name
            if expected_error:
                assert expected_error in run.stderr, (name, expected_error, run.stderr)
            # Deliberately existing paths are foreign artifacts and must be preserved.
            if output.exists():
                assert output.read_bytes() == b'foreign', (name, 'completed output on failure')
            sidecar = output.with_name(output.name + '.sha256')
            if sidecar.exists():
                assert sidecar.read_bytes() == b'foreign', (name, 'orphan completed sidecar')
        records.append({'name': name, 'passed': True, 'returncode': run.returncode,
                        'seconds': elapsed, 'child_pids': pids, 'all_children_reaped': True,
                        'request_counts': requests, 'expected_error': expected_error})

    for profile in paired.PAIRED_PROFILES:
        for command in ('COUNT', 'TOP_10'):
            for reverse in (False, True):
                fixture(f'success-{profile}-{command}-{reverse}', flags=['--profile', profile, '--command', command] +
                        (['--candidate-first'] if reverse else []), success=True, expected_starts=2)
    for name, flags, error in (
        ('iterations-zero', ['--iterations', '0'], 'iterations must be positive'),
        ('iterations-negative', ['--iterations', '-1'], 'iterations must be positive'),
        ('warmup-negative', ['--warmup-seconds', '-1'], 'finite and nonnegative'),
        ('warmup-nan', ['--warmup-seconds', 'nan'], 'finite and nonnegative'),
        ('warmup-inf', ['--warmup-seconds', 'inf'], 'finite and nonnegative'),
        ('timeout-zero', ['--request-timeout', '0'], 'finite and positive'),
        ('timeout-nan', ['--request-timeout', 'nan'], 'finite and positive'),
        ('profile-unknown', ['--profile', 'bogus'], 'invalid choice'),
        ('command-unknown', ['--command', 'bogus'], 'invalid choice'),
        ('cpu-negative', ['--cpu-core', '-1'], 'CPU core must be nonnegative'),
        ('cpu-unavailable', ['--cpu-core', '999999'], 'outside the available'),
        ('source-claim-mismatch', ['--candidate-source-commit', '0' * 40], 'source commit assertion differs')):
        fixture(name, flags=flags, expected_error=error, expected_starts=0)
    fixture('index-missing', prepare=lambda c,b,i,o: shutil.rmtree(i), expected_error='existing directory', expected_starts=0)
    fixture('index-symlink', prepare=lambda c,b,i,o: (i/'link').symlink_to(i/'payload'), expected_error='symlink entries', expected_starts=0)
    fixture('binary-nonexec', prepare=lambda c,b,i,o: b['candidate'].chmod(0o644), expected_error='executable file', expected_starts=0)
    fixture('binary-hash-mismatch', prepare=lambda c,b,i,o: b['candidate'].write_text(b['candidate'].read_text()+'\n# changed\n'), expected_error='binary bytes differ', expected_starts=0)
    fixture('provenance-malformed', prepare=lambda c,b,i,o: (b['candidate'].parent/'provenance.json').write_text('{'), expected_error='candidate:', expected_starts=0)
    fixture('provenance-duplicate', prepare=lambda c,b,i,o: (b['candidate'].parent/'provenance.json').write_text('{"commit":"'+commit+'","commit":"'+commit+'"}'), expected_error='duplicate JSON key', expected_starts=0)
    fixture('output-existing', prepare=lambda c,b,i,o: o.write_bytes(b'foreign'), expected_error='must both be absent', expected_starts=0)
    fixture('sidecar-existing', prepare=lambda c,b,i,o: o.with_name(o.name+'.sha256').write_bytes(b'foreign'), expected_error='must both be absent', expected_starts=0)
    fixture('output-dangling-symlink', prepare=lambda c,b,i,o: o.symlink_to(c/'absent'), expected_error='must both be absent', expected_starts=0)
    for key, value in (('engine','lucene'), ('k1_bits','00000000'), ('b_bits','00000000'),
                       ('collection_statistics','logical'), ('query_cache','enabled'), ('doc_count',True)):
        fixture('receipt-'+key, receipt={key:value}, expected_error='profile receipt differs' if key != 'doc_count' else 'invalid physical', expected_starts=2)
    for key in ('doc_count', 'sum_total_term_freq'):
        fixture('pair-mismatch-'+key, receipt={key:999}, expected_error='physical N/TTF mismatch', expected_starts=2)
    for mode, error in (('ack_eof','EOF before profile receipt'), ('ack_hang','profile receipt deadline'),
                        ('ack_overline','profile receipt exceeds'), ('ack_error','Expecting value'),
                        ('ack_extra','unexpected extra profile output'), ('query_eof','EOF before Tantivy query'),
                        ('query_hang','query response deadline'), ('query_overline','exceeds byte limit'),
                        ('query_error','exactly one nonnegative integer'), ('query_extra','exactly one nonnegative integer')):
        fixture(mode, mode=mode, expected_error=error, expected_starts=2)
    fixture('count-mismatch', count_delta=1, expected_error='count mismatch', expected_starts=2)
    fixture('late-count-mismatch', mode='late_count_mismatch', expected_error='count mismatch', expected_starts=2)
    # Ignore EOF and SIGTERM: the bounded cleanup must reach SIGKILL and reap.
    fixture('kill-fallback', mode='ignore_eof', count_delta=1, expected_error='count mismatch', expected_starts=2)

    # Publication races use actual exclusive links/files; preserve competing writers.
    for race in ('output', 'sidecar'):
        case = root / ('publish-race-' + race)
        case.mkdir()
        output = case / 'result.json'
        if race == 'sidecar':
            output.with_name(output.name+'.sha256').write_bytes(b'foreign')
            try:
                paired.publish(output, {'completed':True})
            except FileExistsError:
                pass
            else:
                raise AssertionError('sidecar race accepted')
            assert not output.exists()
        else:
            actual_link = paired.os.link
            def competing_link(source, target):
                Path(target).write_bytes(b'foreign')
                actual_link(source, target)
            with patch.object(paired.os, 'link', competing_link):
                try:
                    paired.publish(output, {'completed':True})
                except FileExistsError:
                    pass
                else:
                    raise AssertionError('output race accepted')
            assert output.read_bytes() == b'foreign'
            assert not output.with_name(output.name+'.sha256').exists()
        assert not list(case.glob('.result.json.*')), 'publication temporary leaked'
        records.append({'name':'publish-race-'+race, 'passed':True, 'foreign_writer_preserved':True})

    # A delayed unsolicited integer queued before another request is rejected.
    case = root / 'delayed-extra-before-request'
    case.mkdir()
    binary = case / 'fake_protocol.py'
    shutil.copyfile(HERE/'fake_protocol.py', binary)
    binary.chmod(0o755)
    binary.with_suffix('.config.json').write_text(json.dumps({'mode':'delayed_extra','log':str(case/'lifecycle.jsonl')}))
    profile = paired.PAIRED_PROFILES['default']
    child = paired.start([str(binary), str(case)] + profile.arguments())
    selector = selectors.DefaultSelector()
    try:
        paired.request_profile(child, profile, 'tantivy', timeout=.5)
        selector.register(child.stdout, selectors.EVENT_READ)
        paired.query(child, selector, 'the', 'COUNT', .5)
        time.sleep(.08)  # fixture only; never part of real measurement path
        try:
            paired.query(child, selector, 'of', 'COUNT', .5)
        except ValueError as error:
            assert 'before Tantivy query request' in str(error)
        else:
            raise AssertionError('queued delayed output shifted request')
    finally:
        paired.cleanup({'fixture':child})
        selector.close()
    assert not alive(child.pid)
    records.append({'name':'delayed-extra-before-request','passed':True,'all_children_reaped':True})
    inventory = {str(p.relative_to(root)): sha(p) for p in sorted(root.rglob('*')) if p.is_file()}
    sources = {str(path): sha(path) for path in (HERE/'suite_paired.py', HERE/'fake_protocol.py', Path(__file__))}
    receipt = {'scope':'fake protocol boundary/lifecycle evidence only; no production timing or correctness claim',
               'source_commit_claim':commit, 'sources_sha256':sources, 'cases':records,
               'all_passed':True, 'case_count':len(records), 'files_sha256':inventory}
    (root/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps({'output':str(root/'receipt.json'),'case_count':len(records),'all_passed':True}))


if __name__ == '__main__':
    main()
