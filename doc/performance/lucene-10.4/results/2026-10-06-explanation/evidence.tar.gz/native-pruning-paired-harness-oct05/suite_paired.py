#!/usr/bin/env python3
"""Supplemental paired ruler: two real Tantivy binaries on the frozen Wiki20 suite."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import random
import re
import selectors
import statistics
import subprocess
import sys
import tempfile
import time

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent.parent / 'tantivy-pr2937'
TOOLS = SOURCE / 'doc/performance/lucene-10.4'
sys.path.insert(0, str(TOOLS))
from lucene_mode import NativeProfile, PROFILES, request_profile, stop_process

QUERY_SHA256 = '47feb065c35e50ef465beab072ae8549ffef9dd23e20e708c458139adcfccfc5'
PAIRED_PROFILES = {'default': NativeProfile('default', '1.2', '.75',
                                         '3f99999a', '3f400000'), **PROFILES}


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def unique_object(pairs):
    row = {}
    for key, value in pairs:
        if key in row:
            raise ValueError(f'duplicate JSON key: {key}')
        row[key] = value
    return row


def cpu_core(value):
    if value.lower() == 'none':
        return None
    try:
        core = int(value)
    except ValueError as error:
        raise argparse.ArgumentTypeError('CPU core must be nonnegative or none') from error
    if core < 0:
        raise argparse.ArgumentTypeError('CPU core must be nonnegative or none')
    return core


def parser():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--baseline-binary', type=Path, required=True)
    ap.add_argument('--candidate-binary', type=Path, required=True)
    ap.add_argument('--index', type=Path, required=True)
    ap.add_argument('--profile', choices=PAIRED_PROFILES, required=True)
    ap.add_argument('--command', choices=['COUNT', 'TOP_10'], required=True)
    ap.add_argument('--candidate-first', action='store_true')
    ap.add_argument('--cpu-core', type=cpu_core, default=4, metavar='CORE|none')
    ap.add_argument('--warmup-seconds', type=float, default=40)
    ap.add_argument('--iterations', type=int, default=256)
    ap.add_argument('--request-timeout', type=float, default=15)
    ap.add_argument('--output', type=Path, required=True)
    for name in ('baseline', 'candidate'):
        ap.add_argument(f'--{name}-provenance', type=Path,
                        help='build provenance JSON (default: BINARY.parent/provenance.json)')
        ap.add_argument(f'--{name}-source-commit',
                        help='optional exact commit assertion; must match build provenance')
    return ap


def output_paths(output):
    return output, output.with_name(output.name + '.sha256')


def binary_origin(binary, manifest, expected_commit):
    row = json.loads(manifest.read_text(), object_pairs_hook=unique_object)
    if not isinstance(row, dict) or re.fullmatch(r'[0-9a-f]{40}', str(row.get('commit'))) is None:
        raise ValueError('build provenance requires a full lowercase source commit')
    if expected_commit is not None and expected_commit != row['commit']:
        raise ValueError('source commit assertion differs from build provenance')
    hashes = row.get('binaries_sha256')
    actual = digest(binary)
    if not isinstance(hashes, dict) or hashes.get(binary.name) != actual:
        raise ValueError('binary bytes differ from required build provenance')
    return {'binary': str(binary), 'sha256': actual, 'bytes': binary.stat().st_size,
            'source_commit': row['commit'], 'source_commit_assertion': expected_commit,
            'build_provenance': str(manifest), 'build_provenance_sha256': digest(manifest),
            'build_provenance_record': row,
            'origin_evidence': 'manifest source claim; binary digest checked, compilation not inferred'}


def validate_args(args, ap):
    if args.iterations < 1:
        ap.error('--iterations must be positive')
    if not math.isfinite(args.warmup_seconds) or args.warmup_seconds < 0:
        ap.error('--warmup-seconds must be finite and nonnegative')
    if not math.isfinite(args.request_timeout) or args.request_timeout <= 0:
        ap.error('--request-timeout must be finite and positive')
    args.output = args.output.absolute()
    if any(os.path.lexists(path) for path in output_paths(args.output)):
        ap.error('output and SHA sidecar must both be absent')
    if not args.output.parent.is_dir():
        ap.error('output parent directory must already exist')
    args.index = args.index.resolve()
    if not args.index.is_dir():
        ap.error('--index must be an existing directory')
    if args.cpu_core is not None and args.cpu_core not in os.sched_getaffinity(0):
        ap.error('--cpu-core is outside the available process affinity')
    origins = {}
    for name in ('baseline', 'candidate'):
        binary = getattr(args, name + '_binary').resolve()
        if not binary.is_file() or not os.access(binary, os.X_OK):
            ap.error(f'{name} binary must be an executable file')
        setattr(args, name + '_binary', binary)
        manifest = (getattr(args, name + '_provenance') or binary.parent / 'provenance.json').resolve()
        setattr(args, name + '_provenance', manifest)
        try:
            origins[name] = binary_origin(binary, manifest, getattr(args, name + '_source_commit'))
        except (OSError, ValueError) as error:
            ap.error(f'{name}: {error}')
    suite = TOOLS / 'queries-wiki.jsonl'
    if digest(suite) != QUERY_SHA256:
        ap.error('query bytes differ from frozen Wiki20 SHA-256')
    queries = [json.loads(line, object_pairs_hook=unique_object)['query']
               for line in suite.read_text().splitlines()]
    if len(queries) != 20 or len(set(queries)) != 20 or any(
            not isinstance(q, str) or '\n' in q or '\t' in q for q in queries):
        ap.error('frozen suite requires 20 unique one-line queries')
    return queries, origins


def identities(args):
    sources = [Path(__file__).resolve()] + [TOOLS / name for name in (
        'suite_lucene_interleaved.py', 'lucene_mode.py', 'tantivy_statistics.py',
        'provenance.py', 'queries-wiki.jsonl', 'do_query.rs', 'shared/bm25_profile.rs')]
    index = {}
    for path in sorted(args.index.rglob('*')):
        if path.is_symlink():
            raise ValueError('index identity does not accept symlink entries')
        if path.is_file():
            index[str(path.relative_to(args.index))] = {'sha256': digest(path), 'bytes': path.stat().st_size}
    commit = subprocess.run(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'],
                            capture_output=True, text=True, check=True, timeout=5).stdout.strip()
    return {'observed_helper_repository_commit': commit,
            'sources_sha256': {str(path): digest(path) for path in sources},
            'index': {'path': str(args.index), 'files': index,
                      'total_bytes': sum(row['bytes'] for row in index.values())},
            'binaries': {name: binary_origin(getattr(args, name + '_binary'),
                         getattr(args, name + '_provenance'), getattr(args, name + '_source_commit'))
                         for name in ('baseline', 'candidate')}}


def process_snapshot():
    result = subprocess.run(['ps', '-eo', 'pid,ppid,comm,pcpu,rss', '--no-headers'],
                            capture_output=True, text=True, timeout=5, check=True)
    return {'utc': datetime.now(timezone.utc).isoformat(), 'load_average': os.getloadavg(),
            'affinity': sorted(os.sched_getaffinity(0)), 'process_columns': 'pid ppid comm pcpu rss',
            'processes': result.stdout, 'platform': platform.platform()}


def start(command):
    return subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.DEVNULL, text=True, bufsize=1)


def paired_receipts(receipts):
    if set(receipts) != {'baseline', 'candidate'}:
        raise ValueError('both Tantivy receipts are required')
    before, after = (receipts[name]['observed'] for name in ('baseline', 'candidate'))
    if any(before[key] != after[key] for key in ('doc_count', 'sum_total_term_freq')):
        raise ValueError('baseline/candidate physical N/TTF mismatch')


def query(process, selector, q, command, timeout):
    # Same begin/end boundaries as the original request timer. Selector was
    # registered once, outside timing; bounded raw reads add supplemental overhead.
    if selector.select(0):
        raise ValueError('unexpected output before Tantivy query request')
    begin = time.perf_counter_ns()
    process.stdin.write(f'{command}\t{q}\n')
    process.stdin.flush()
    deadline = time.monotonic() + timeout
    data = bytearray()
    while b'\n' not in data:
        remaining = deadline - time.monotonic()
        if remaining <= 0 or not selector.select(remaining):
            raise TimeoutError('Tantivy query response deadline exceeded')
        chunk = os.read(process.stdout.fileno(), 65 - len(data))
        if not chunk:
            raise ValueError('EOF before Tantivy query response')
        data.extend(chunk)
        if len(data) > 64:
            raise ValueError('Tantivy query response exceeds byte limit')
    line, extra = bytes(data).split(b'\n', 1)
    if extra or selector.select(0) or re.fullmatch(rb'[0-9]+', line) is None:
        raise ValueError('expected exactly one nonnegative integer response')
    count = int(line)
    return count, (time.perf_counter_ns() - begin) / 1000


def cleanup(processes):
    failures = []
    for name, process in processes.items():
        try:
            stop_process(process)
        except Exception as error:
            # One broken cleanup cannot prevent cleanup of later registered children.
            try:
                if process.poll() is None:
                    process.kill()
                process.wait(timeout=2)
            except Exception as fallback:
                failures.append(f'{name}: {error}; fallback: {fallback}')
    if failures:
        raise RuntimeError('child cleanup failed: ' + '; '.join(failures))


def publish(output, row):
    # Completion JSON is installed last, exclusively, after its digest sidecar.
    encoded = (json.dumps(row, indent=2, allow_nan=False) + '\n').encode()
    sha = hashlib.sha256(encoded).hexdigest()
    sidecar = output_paths(output)[1]
    created_sidecar = False
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=output.parent, prefix='.' + output.name + '.',
                                         delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
        with sidecar.open('x') as stream:
            created_sidecar = True
            stream.write(sha + '  ' + output.name + '\n')
        os.link(temporary, output)
    except BaseException:
        if created_sidecar:
            sidecar.unlink()
        raise
    finally:
        if temporary is not None:
            temporary.unlink()
    return sha


def main(argv=None):
    ap = parser()
    args = ap.parse_args(argv)
    queries, origins = validate_args(args, ap)
    profile = PAIRED_PROFILES[args.profile]
    names = ['candidate', 'baseline'] if args.candidate_first else ['baseline', 'candidate']
    pin = [] if args.cpu_core is None else ['taskset', '-c', str(args.cpu_core)]
    commands = {name: pin + [str(getattr(args, name + '_binary')), str(args.index)] + profile.arguments()
                for name in names}
    config = {'profile': profile.requested(), 'command': args.command,
              'candidate_first': args.candidate_first, 'cpu_core': args.cpu_core,
              'warmup_seconds': args.warmup_seconds, 'iterations': args.iterations,
              'request_timeout': args.request_timeout, 'shuffle_seed': 23,
              'commands': commands, 'output': str(args.output)}
    config_sha = hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest()
    before = identities(args)
    if before['binaries'] != origins:
        raise ValueError('binary/provenance changed after argument validation')
    pre = process_snapshot()
    processes, readers, receipts = {}, {}, {}
    samples = {name: {q: [] for q in queries} for name in names}
    counts = {}
    try:
        for name in names:
            processes[name] = start(commands[name])  # register BEFORE acknowledgement
            receipts[name] = request_profile(processes[name], profile, 'tantivy',
                                             timeout=args.request_timeout)
        paired_receipts(receipts)
        for name, process in processes.items():
            readers[name] = selectors.DefaultSelector()
            readers[name].register(process.stdout, selectors.EVENT_READ)
        i = 0
        until = time.monotonic() + args.warmup_seconds
        # Default40s schedule is unchanged; a zero/tiny fixture warmup still
        # observes one whole alternating cycle so all measured counts are seeded.
        while time.monotonic() < until or i < 2 * len(queries):
            name = names[i % 2]
            q = queries[(i // 2) % len(queries)]
            count, _ = query(processes[name], readers[name], q, args.command, args.request_timeout)
            if q in counts and counts[q] != count:
                raise ValueError(f'count mismatch for {q!r}: {name}={count}, expected={counts[q]}')
            counts[q] = count
            i += 1
        rng = random.Random(23)
        for iteration in range(args.iterations):
            order = queries.copy()
            rng.shuffle(order)
            for j, q in enumerate(order):
                pair = names if (iteration + j) % 2 == 0 else names[::-1]
                for name in pair:
                    count, us = query(processes[name], readers[name], q, args.command, args.request_timeout)
                    if count != counts[q]:
                        raise ValueError(f'count mismatch for {q!r}: {name}={count}, expected={counts[q]}')
                    samples[name][q].append(us)
    finally:
        try:
            cleanup(processes)
        finally:
            for reader in readers.values():
                reader.close()
    post = process_snapshot()
    after = identities(args)  # full index/source/binary hashing only after children stop
    if before != after:
        raise ValueError('input/source/binary provenance changed during paired run')
    medians = {name: {q: statistics.median(values) for q, values in rows.items()}
               for name, rows in samples.items()}
    ratios = {q: medians['candidate'][q] / medians['baseline'][q] for q in queries}
    overall = math.exp(sum(math.log(r) for r in ratios.values()) / len(queries))
    row = {'protocol': 'tantivy-paired-ruler-v1', 'completed': True,
           'engines': {'baseline': 'tantivy', 'candidate': 'tantivy'},
           'queries': queries, 'counts': counts, 'command': args.command,
           'medians_us': medians, 'samples_us': samples,
           'candidate_baseline_ratios': ratios, 'geomean_candidate_baseline_ratio': overall,
           'configuration': config, 'configuration_sha256': config_sha,
           'profile_receipts': receipts, 'provenance_before': before, 'provenance_after': after,
           'process_snapshot_before': pre, 'process_snapshot_after': post,
           'ruler_scope': 'supplements frozen Tantivy/Lucene ruler; absolute latency is not transferable',
           'reader_policy': 'both labels use identical persistent-selector bounded raw reads',
           'timer_policy': 'perf_counter_ns before write/flush through parsed response; no timed provenance work'}
    sha = publish(args.output, row)
    for q in queries:
        print(f'{q:20} baseline={medians["baseline"][q]:.1f} candidate={medians["candidate"][q]:.1f} C/B={ratios[q]:.3f}')
    print(json.dumps({'output': str(args.output), 'sha256': sha,
                      'geomean_candidate_baseline_ratio': overall}))
    return row


if __name__ == '__main__':
    main()
