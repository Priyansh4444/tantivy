#!/usr/bin/env python3
"""Root regression gate for a reviewed, committed explanation-only trial."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import shutil
import struct
import subprocess
import time

BENCH = Path(__file__).resolve().parent
OLD_GATE = BENCH / 'native-pruning-finite-root-release-oct05'
CASES_SHA = 'f632da13074c6556bcd9a2ba7605d7974f96c5bbab455100dfb711cfa30c8826'

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def write(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')

def inventory(path):
    return {str(p.relative_to(path)): sha(p) for p in sorted(path.rglob('*')) if p.is_file()}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--worktree', type=Path, required=True)
    parser.add_argument('--artifact', type=Path, required=True)
    parser.add_argument('--source-review', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    args.output.mkdir()
    commit = subprocess.check_output(['git', '-C', str(args.worktree), 'rev-parse', 'HEAD'], text=True).strip()
    assert not subprocess.check_output(['git', '-C', str(args.worktree), 'status', '--porcelain'], text=True).strip()
    review = json.loads(args.source_review.read_text())
    assert review['root_reviewed_actual_source']
    sources = review['files_sha256']
    assert all(sha(args.worktree / name) == digest for name, digest in sources.items())
    build = json.loads((args.artifact / 'provenance.json').read_text())
    assert build['commit'] == commit and build['rust_flags'] == '-C target-cpu=native'
    assert build['profile'] == {'lto': True, 'opt-level': 3, 'overflow-checks': False}
    binaries = build['binaries_sha256']
    assert len(binaries) == 8 and all(sha(args.artifact / name) == digest for name, digest in binaries.items())
    tools = args.worktree / 'doc/performance/lucene-10.4'
    old_tools = BENCH.parent / 'tantivy-pr2937/doc/performance/lucene-10.4'
    tool_files = ['parity/run.py', 'parity/rust/Cargo.toml', 'parity/rust/src/main.rs',
                  'parity/LuceneParity.java', 'compare_wiki_correctness.py', 'provenance.py', 'lucene_mode.py']
    tool_hashes = {name: sha(tools / name) for name in tool_files}
    assert all(tool_hashes[name] == sha(old_tools / name) for name in tool_files)
    cases = OLD_GATE / 'frozen-cases.jsonl'
    assert sha(cases) == CASES_SHA
    (args.output / 'frozen-cases.jsonl').write_bytes(cases.read_bytes())
    index = BENCH / 'wiki-1m-native-aligned-v11-oct05.idx'
    lucene_index = BENCH.parent / 'search-benchmark-game/engines/lucene-10.4.0/idx'
    before = {str(p): inventory(p) for p in (index, lucene_index)}
    write(args.output / 'before.json', {'commit': commit, 'sources_sha256': sources,
          'tools_sha256': tool_hashes, 'binaries_sha256': binaries, 'indices': before,
          'started_at_utc': datetime.now(timezone.utc).isoformat()})
    environment = os.environ.copy()
    environment.update(RUSTFLAGS='-C target-cpu=native', CARGO_BUILD_JOBS='4',
        CARGO_PROFILE_RELEASE_LTO='true', CARGO_PROFILE_RELEASE_OPT_LEVEL='3',
        CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS='false')
    records = []
    def run(name, command, timeout):
        write(args.output / (name + '.started.json'), {'command': command, 'cwd': str(args.worktree)})
        started = time.monotonic()
        with (args.output / (name + '.log')).open('x') as log:
            child = subprocess.Popen(command, cwd=args.worktree, env=environment,
                stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                rc = child.wait(timeout=timeout)
            except BaseException:
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                child.wait(timeout=5)
                raise
        record = {'command': command, 'cwd': str(args.worktree), 'returncode': rc,
                  'seconds': time.monotonic() - started, 'log_sha256': sha(args.output / (name + '.log'))}
        write(args.output / (name + '.command.json'), record)
        records.append(record)
        assert rc == 0, name
    # Compile the unchanged synthetic adapter with the retained dependency lock;
    # use the exact retained Java classes, avoiding a new dependency resolution.
    package = args.output / 'synthetic-package'
    package.mkdir()
    shutil.copytree(tools / 'parity/rust/src', package / 'src')
    manifest = (tools / 'parity/rust/Cargo.toml').read_text()
    assert manifest.count('"../../../../.."') == 1
    (package / 'Cargo.toml').write_text(manifest.replace('"../../../../.."', json.dumps(str(args.worktree))))
    lock = old_tools / 'parity/rust/Cargo.lock'
    (package / 'Cargo.lock').write_bytes(lock.read_bytes())
    package_before = inventory(package)
    synthetic_dir = args.output / 'synthetic'
    synthetic_dir.mkdir()
    old_java = OLD_GATE / 'synthetic/java'
    java_before = inventory(old_java)
    assert java_before and all(name.endswith('.class') for name in java_before)
    shutil.copytree(old_java, synthetic_dir / 'java')
    write(args.output / 'synthetic-build-inputs.json', {'package_sha256': package_before,
          'retained_lock_path': str(lock), 'retained_lock_sha256': sha(lock),
          'retained_java_classes_sha256': java_before})
    run('synthetic-build', ['cargo', 'build', '--offline', '--locked', '--release', '--jobs', '4',
        '--manifest-path', str(package / 'Cargo.toml'), '--target-dir', str(args.output / 'synthetic-target')], 1800)
    assert inventory(package) == package_before
    run('synthetic', ['python', str(tools / 'parity/run.py'), '--skip-build', '--cases', str(cases),
        '--target', str(args.output / 'synthetic-target'), '--output', str(synthetic_dir)], 300)
    synthetic = json.loads((args.output / 'synthetic/report.json').read_text())
    assert synthetic['passed'] and synthetic['queries'] == 330 and synthetic['cases'] == 16
    assert not synthetic['structural_issues'] and not synthetic['native_raw_score_mismatches']
    scores = {}
    for profile in ('default', 'k09-b04', 'k25-b1'):
        old = json.loads((OLD_GATE / (profile + '-correctness.command.json')).read_text())['command']
        command = old.copy()
        command[1] = str(tools / 'compare_wiki_correctness.py')
        command[command.index('--tantivy-validator') + 1] = str(args.artifact / 'validate_index')
        command[command.index('--commit') + 1] = commit
        destination = args.output / (profile + '-correctness.json')
        command[command.index('--output') + 1] = str(destination)
        run(profile + '-correctness', command, 300)
        result = json.loads(destination.read_text())
        assert len(result['comparisons']) == 20
        count = 0
        for t, l in zip(result['tantivy'], result['lucene'], strict=True):
            assert t['query'] == l['query']
            ts = {d['id']: d['score'] for d in t['top100']}
            ls = {d['id']: d['score'] for d in l['top100']}
            for identifier in ts.keys() & ls.keys():
                assert struct.pack('!f', ts[identifier]) == struct.pack('!f', ls[identifier]), (profile, identifier)
                count += 1
        assert count == 1913
        scores[profile] = {'common_scores': count, 'f32_mismatches': []}
    assert before == {str(p): inventory(p) for p in (index, lucene_index)}
    assert all(sha(args.worktree / name) == digest for name, digest in sources.items())
    assert all(sha(tools / name) == digest for name, digest in tool_hashes.items())
    assert all(sha(args.artifact / name) == digest for name, digest in binaries.items())
    assert inventory(old_java) == java_before == inventory(synthetic_dir / 'java')
    assert sha(lock) == package_before['Cargo.lock']
    assert subprocess.check_output(['git', '-C', str(args.worktree), 'rev-parse', 'HEAD'], text=True).strip() == commit
    assert not subprocess.check_output(['git', '-C', str(args.worktree), 'status', '--porcelain'], text=True).strip()
    write(args.output / 'summary.json', {'passed': True, 'commit': commit,
          'root_reviewed_actual_source': True, 'source_review_sha256': sha(args.source_review),
          'indices_unchanged': True, 'sources_unchanged': True, 'binaries_unchanged': True,
          'records': records, 'synthetic_queries': 330, 'synthetic_cases': 16, 'scores': scores})
    print('PASS', commit, 'frozen330, all3 Wiki20,1913exactf32scores/profile', flush=True)

if __name__ == '__main__':
    main()
