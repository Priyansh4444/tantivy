# Direction C: one shared, typed, deferred IDF recipe

Design only against fork `41b10df91e8450f49975e0b01b01f08759bc5f18`. No source changes, builds, tests, or timing runs performed.

## Caller first

Existing callers remain unchanged:

```rust
let base = Bm25Weight::for_terms(statistics, &terms)?;
let segment_weight = base.boost_by(boost); // scalar multiplication + shared ownership
let score = segment_weight.score(norm, frequency); // never reads recipe
let explanation = segment_weight.explain(norm, frequency); // owned output tree
```

`TermWeight::specialized_scorer` still obtains a weight using `boost_by`; `TermScorer::explain` still delegates to its weight. Phrase, regex phrase, and phrase prefix scorer construction retain their existing optional weight and boost flows. Fractional phrase explanations still call `explain_with_frequency`. There is no new public API, provider lifetime, closure, trait object, or scoring call layer.

## Data shape and signatures

All types below are private in `src/query/bm25.rs`; only the existing private field/build parameter changes representation.

```rust
#[derive(Clone, Copy)]
struct IdfTermRecipe {
    value: Score,     // original, already-rounded IDF
    doc_freq: Score,  // original u64 -> Score conversion for explanation
}

enum IdfExplanationRecipe {
    ClassicSingle { term: IdfTermRecipe, doc_count: Score },
    NativeSingle { term: IdfTermRecipe, doc_count: Score },
    ClassicSum { value: Score },
    NativeSum {
        value: Score,                 // cached final f64 sum -> Score
        doc_count: Score,             // common collection snapshot
        terms: Box<[IdfTermRecipe]>,  // original order, including duplicates
    },
    Provided(Explanation),            // arbitrary owned tree, preserved verbatim
}

impl IdfExplanationRecipe {
    fn to_explanation(&self) -> Explanation;
}

#[derive(Clone)]
pub struct Bm25Weight {
    idf_explain: Option<Arc<IdfExplanationRecipe>>,
    // weight, cache, average_fieldnorm, scoring, parameters, safe_normalization unchanged
}

fn build(
    idf: Score,
    idf_explain: Option<Arc<IdfExplanationRecipe>>,
    average_fieldnorm: Score,
    scoring: Bm25Scoring,
    parameters: Bm25Parameters,
) -> Bm25Weight;
```

The scalar is passed explicitly to `build`, as today. Do not derive scoring weight from a reconstructed explanation. Each normal constructor computes its scalar once and places those same rounded values in the recipe. A local `Vec::with_capacity(terms.len())` collects native sum records and becomes `into_boxed_slice()`; it retains neither terms nor the provider. `Provided` deliberately stays inline within the cold enum: boxing it would shrink normal recipe allocations but introduce another allocation and indirection for explicit trees. The heap enum's maximum size is therefore governed by `Explanation`, not the small numeric variants. This is a deliberate minimality tradeoff, not a claim that its allocation is as small as three floats.

In `explain_with_frequency`, replace only the IDF child insertion with `explanation.add_detail(recipe.to_explanation())`. The outer tree, TF tree, scalar score calculation, labels, ordering, and context attachment remain as currently written. Repeated explanations return independently owned mutable trees; there is no lazy memoization or mutable shared state.

## Construction and exact contracts

| Entry point | Scalar calculation, construction-time metadata | Owned IDF output on explain |
|---|---|---|
| Classic single through `for_one_term[_with_parameters]` or `for_terms` | Existing `idf(n, N)` with its f32 operations and assertion; cache `idf`, `n as Score`, `N as Score` | Root `idf, computed as log(1 + (N - n + 0.5) / (n + 0.5))`; children `n, number of docs containing this term`, then `N, total number of docs` |
| Native single through `for_terms` | Existing `native_idf(n, N)`: f64 formula, final f32 cast; cache scalar and f32 statistics | Same formula root and n child, then `N, number of docs with this field` |
| Classic multiple terms | Start `0.0: Score`; original ordered `idf_sum += idf(n, N)` in f32; store only final scalar | Bare `Explanation::new("idf", value)`, with `details: None` |
| Native multiple terms | Original ordered per-term `native_idf` f32 values; accumulate `sum += f64::from(value)` into f64; cast once; store every per-term f32 scalar/stat | `idf, sum of:` root; children are native single trees in original order; retain duplicates |
| `new[_with_parameters]`, `new_native[_with_parameters]` | Read the supplied tree's `value()` before moving the entire tree to `Provided` | Deep-clone the supplied tree, including owned descriptions, children, contexts, unusual nesting, and absent vectors |
| `new_without_explain`, `for_one_term_without_explain`, `for_native_block_bounds` | Identical scalar, policy, parameters, and cache paths; recipe `None` | Omit IDF child exactly as today |

Important constraints:

- Keep the empty-terms and mixed-field assertions before provider work. Call `field_statistics(field)` once, then `doc_freq(term)` once for each term in input order. Duplicate terms still make duplicate calls. Preserve first-error short circuit. Default `field_statistics` still calls `total_num_tokens` before `total_num_docs`. Do not prefetch, retry, batch, defer, or call the provider while explaining.
- Cache f32 explanation statistics during construction. Do not retain u64 counts and accidentally replace the already-rounded IDF with a formula operating on rounded statistics. IDF functions and their invalid-statistics assertions execute during construction as today.
- Native multi-term sums must not use raw f64 IDFs, f32 accumulation, sorting, reduction, deduplication, or recomputation while explaining. Classic multi-term sums must not gain details or switch to f64.
- Keep average rounding, parameter snapshot, classic `idf * (1.0 + k1)`, native scalar weight, cache generation/classification, score arithmetic, bounds, and pruning eligibility unchanged.
- `boost_by(1.0)` keeps its early-return clone, including its current special floating-point behavior. Other boosts multiply only `weight` using the same expression. Clone/boost share the recipe Arc and existing cache Arc. They never boost IDF child values or rebuild trees. Include signed zero, NaN, infinity, negative, and repeated boosts in verification.
- Explanation descriptions currently use borrowed static `Cow` strings for normal BM25 trees. Savings here concern tree/vector construction and deep vector clones; there are no normal description-string allocations to remove. Explicit `Provided` owned strings remain supported.

## Module map and source scope

`bm25.rs`: add two private recipe types and one materializer; change the field/build argument; replace normal eager IDF tree construction with cached recipes; wrap existing explicit-tree constructors in `Provided`; replace the one explain clone with materialization. Retain the existing native helper under tests if baseline reference code needs it. No changes to `Explanation`, term/phrase weights/scorers, cache types, query flow, index/writer, bounds, or public exports.

Baseline source anchors: `bm25.rs` functions `native_idf_explanation`, `for_terms`, `for_one_term_with_parameters`, `build`, `boost_by`, `explain_with_frequency`; `explanation.rs` struct, constructors, and `add_detail`/`add_context`; `term_query/term_weight.rs::specialized_scorer`; `phrase_query/phrase_weight.rs::phrase_scorer_danger` and `Weight::explain`.

## Whole-shape comparison

| Shape | Setup without explanation | Clone/boost | Hot layout | Explanation request |
|---|---|---|---|---|
| Existing owned eager `Option<Explanation>` | Builds normal trees; native phrase builds per-term detail vectors, temporary details vector, and parent children | Deep clones vectors and any owned strings | Brief reports weight 112 B | Deep clones IDF tree |
| Shared eager `Option<Arc<Explanation>>` | Same trees plus one Arc allocation; classic multi-term goes from allocation-free IDF to one allocation | One atomic Arc increment, no tree clone | Expected one-pointer recipe field | Deep clones IDF tree |
| **Shared typed deferred recipe (this design)** | One Arc allocation; native phrase adds one compact numeric record buffer; normal detail vectors only built on explain | One atomic Arc increment, no tree clone | Same one-pointer field as shared eager | Builds standard trees from cached values; deep-clones `Provided` |
| Inline typed recipe including arbitrary `Provided(Explanation)` | Avoids Arc allocation but retains a wide enum and per-term buffer | Native sum buffer/tree clones remain unless separately shared | Largest variant dictated by owned `Explanation`; cannot obtain one-pointer weight | Builds/clones IDF tree |

On the supplied 64-bit layout, replacing an approximately 80 B `Option<Explanation>` with 8 B `Option<Arc<_>>` predicts weight near 40 B (about 72 B smaller) and correspondingly smaller embedded `TermScorer`. This is an estimate; report actual release/native size diagnostics after implementation. Do not claim compiler layout stability or infer throughput from size.

For single-term normal IDF, the original children Vec allocation is replaced by one Arc allocation whose cold payload includes the enum's large `Provided` variant. Expected saving is fewer constructed/copied nodes and less reserved child storage, not zero setup allocations. For classic multi-term IDF, this design adds an allocation absent in baseline; shared eager does the same. That can matter for custom-provider setup, so measure it. For native multi-term IDF, compact records replace multiple tree vectors and repeated scalar-node storage. Explain becomes more construction-heavy than using an existing tree, intentionally restricted to the cold request. Atomic clone cost and the added cold allocation remain real costs.

Choose full defer over shared eager if removing normal construction work is part of the hypothesis. Choose shared eager if smallest implementation and strongest mechanical parity dominate. Both isolate the hot field representation equally; a result favoring either cannot establish that smaller hot layout caused the runtime difference.

## Verification gates for the eventual isolated implementation

1. **Baseline whole-tree oracle.** Freeze the original eager IDF constructor/materialization logic in test-only reference code, independent of the new recipe materializer. Construct complete original and candidate BM25 trees for both policies, single and multiple terms, duplicates, boosts, integer and fractional phrase frequencies, boundary counts (including >2^24), parameters, valid/exceptional averages, and multiple norms. Compare complete serialized tree shape/order/labels/context, including omitted `details`/`context`, and recursively compare every numeric node's `to_bits()` using test-only extraction. JSON alone hides signed-zero/nonfinite details; scalar-only equality misses changed children. Include an adversarial native phrase where f32 versus f64 accumulation differs and a classic phrase where reordering/precision differs.
2. **Explicit-tree ownership.** Give internal classic/native constructors an arbitrary nested owned-description tree with contexts and nontrivial f32 bit patterns. Compare baseline and candidate outputs before/after clone, boost, and dropping the original weight. Modify one returned tree and verify a later explain still equals baseline. Cover `None` constructors and missing-IDF child position.
3. **Provider observation.** A recording provider verifies the exact `field_statistics`/default tokens/docs/ordered doc-frequency call trace, duplicate calls, errors at each term, no calls during clone/boost/explain, and that explanation still works after provider destruction. Verify assertions precede provider work as baseline.
4. **Runtime scalar isolation.** Use the frozen baseline oracle and unchanged formulas to compare weight/average/cache/profile bits and all score/max/bounds/threshold results over every norm ID, representative integer/fractional frequencies, boost edge values, native/classic, DEFAULT/k09/other validated profiles. Retain existing native pruning/raw-score/ranking and phrase explanation gates. A recipe-only test that calculates expected results with candidate helpers is insufficient.
5. **Cheap structural evidence.** Inspect actual `size_of::<Bm25Weight/TermScorer>()` via existing layout diagnostics. In private tests use `Arc::ptr_eq` to show recipe/cache identity survives boost/clone; `Provided` proves deep cloning is postponed to explain. A tightly scoped allocation probe around IDF construction and repeated weight clone (excluding cache allocation and test formatting) compares baseline versus candidate single/native phrase/classic phrase cases. Do not add fragile global allocation counts to ordinary concurrent CI tests.

After these gates, frozen native paired runs are required for any speed claim: same provenance/cache, DEFAULT and small queries as well as k09, unchanged exact counts/raw scores. Existing B1 costs/gains do not establish explanation representation as their cause. User all-query/all-47 scope remains open; this proposal does not narrow it.

## Rubric (5 best; design assessment, not measured result)

| Criterion | Score | Reason |
|---|---:|---|
| Exact contracts | 5/5 | Cached original scalars/statistics, explicit policy-shaped variants, verbatim owned-tree fallback, unchanged provider flow |
| Cold clone/construction saving | 4/5 | Eliminates normal tree setup and deep scorer clones; Arc allocation remains, classic sum gains one |
| Hot layout/surface | 5/5 | One nullable immutable pointer, no recipe access in score/bounds, no public/caller API changes |
| Minimality | 4/5 | One enum/materializer local to BM25; more code than shared eager, no caching framework or provider retention |
| Verifiable scope | 5/5 | Independent frozen tree oracle, provider trace, scalar bits, ownership/layout probes; one production module |

Workflow record: investigation steps 1–4 completed for design. `throughput checkpoint: n/a, read-only investigation`. Model-the-domain shaped the policy-specific variants and arbitrary-tree fallback; laziness-protocol kept the materializer beside its only caller and rejected a new explanation/provider abstraction.
