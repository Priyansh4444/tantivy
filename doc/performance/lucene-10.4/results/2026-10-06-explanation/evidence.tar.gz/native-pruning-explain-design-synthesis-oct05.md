# Explanation representation synthesis

Root read all three complete packages and the fresh independent judge. Current
main a2e525dbe differs from original brief41b10df only in proof docs; baseline
production source is b50e2aef3. Ground/Frame/Fanout/Crossjudge/Pick complete.
Agree proceeds without a human checkpoint. No source/timing result yet.

Pick inline B: explicitly eliminate ordinary single-term explanation construction
and deep clones together. Equal-weight root scores A5/3/5/5/5=23, B5/5/4/3/5=22,
C5/4/5/3/5=22; narrower minimality favors A, but root's selected construction-plus-
clone objective weights cold categorical removal over incremental source size.
Judge independently recommends B for that same objective. No false claim the
smaller shape will repair the measured DEFAULT cost; exact target remains measured.

One private exhaustive IdfExplanation enum None,Single(threecachedf32stats),
NativeSum{cachedsum,Arccompactrecords},ClassicScalar(f32),Explicit(ArcExplanation).
Existing Bm25Scoring controls only Single N description. score/cache/weight/boost/
profile/bounds/provider order all remain literal. Store original unboosted IDF and
alreadyrounded stats; do not recover scalar from boostedweight/recomputeidf during
explain. Native phrase sum remains ordered f64 of individuallyroundedf32 values;
classic remainsorderedf32. Pertermn/Ncasts remain in originalloop positions.
Caller/public API unchanged; metadata only materializes at owned explain boundary.

Grafts: A independent owned-output/mutation/drop and shared explicit-tree/cache
checks, no globalallocator inCI; C cached scalar/stat guards and adversarial sum
fixture that distinguishes native f64 from f32. Freeze untouched baseline whole-tree
bit snapshots before core edit and comparecandidateactualoutputs; no candidate-to-
candidate oracle. Scope28–64 representativecases rather than multiplying huge
mirroredmatrices; existing frozen330/rawbit/exhaustive/profile gates stayunchanged.
Provider call spy includesduplicates/override/defaulttokens-docs order/errorstop,
zero calls after clone/boost/explain. Native identicaltarget before/afterlayoutreceipt.
Ownership evidence is not allocator measurement; single inline/None has no metadata
heapallocation byshape, native phrase Arcfreezingcan allocate/copy, explicitconstructor
addsrootallocation. No perrequestcacheorinteriormutablememoization.

Rejected A as first objective: still builds trees and addsrootallocation; remainscheap
laterisolatedbaselinecandidateifBmeasurementfails. Rejected C: singles still allocate
Arc withwideProvided payload; no benefit overinline for targeted setup. Neither is
stacked withB. Remove oldeagerproductionnative_idf_explanation onceunused; preserve
copiedbaselineoracle onlytestproof. GenericExplanationrepresentationunchanged; cfgtest
bit-structurehelper maybeaddedwithoutproductionfieldchanges. Noformat/indexchange.

Next implement one isolatedworktree atcurrenta2e sourceb50. Freezebaseline tree/prov;
root fullreviewactualdiff beforefinalcandidatebuild/native measurement. Native
correctnessgates then frozenpaired4run DEFAULT/k09screen; keep/revertbeforebroader
count/k25/T-Lacceptance. Nativebaselinebinaryb50 remainsimmutable, currentmainclean.
ArchitectScrap ifrepeatedshape deviations; no PRthispass/fullscope47stillopen.
