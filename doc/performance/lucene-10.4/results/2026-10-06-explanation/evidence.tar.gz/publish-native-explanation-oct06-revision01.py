#!/usr/bin/env python3
"""Publish P021's reviewed evidence without build targets, binaries or indices."""
from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

BASE = Path(__file__).resolve().parent
REPO = BASE.parent / 'tantivy-pr2937'
CORE = '176410bb56a4d711b403a959fbafddf5b8d04847'
TESTED = '7322109659d1f163fbd24f804b2cff906bbdaa1b'
OUT = REPO / 'doc/performance/lucene-10.4/results/2026-10-06-explanation'
assert not OUT.exists()
assert subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip() == CORE
assert not subprocess.check_output(['git', '-C', str(REPO), 'status', '--porcelain'], text=True).strip()
subprocess.run(['git', '-C', str(REPO), 'diff', '--quiet', TESTED, 'HEAD', '--', 'src', 'Cargo.toml', 'Cargo.lock', '.cargo'], check=True)
decision = json.loads((BASE / 'native-pruning-explanation-decision-oct06.json').read_text())
assert decision['verdict'] == 'kept' and decision['root_recalculated_all_16_runs_from_256_raw_samples']
members = {}
folders = ('native-pruning-explanation-inline-oct05', 'native-pruning-explanation-root-release-oct06',
           'native-pruning-explanation-screen-oct06', 'native-pruning-explanation-floors-oct06',
           'native-pruning-explanation-k09-controls-oct06', 'native-pruning-paired-harness-oct05')
for dirname in folders:
    folder = BASE / dirname
    for path in sorted(folder.rglob('*')):
        relative = path.relative_to(folder)
        if any(part in ('target', 'allocation-target', 'test-target', 'synthetic-target', '__pycache__', 'baseline-package') for part in relative.parts):
            continue
        if path.name == 'baseline-package.tar' or (relative.parts[0] == 'artifacts' and path.name in ('do_query', 'validate_index', 'reencode_index', 'payload_identity', 'payload_fixtures', 'build_index', 'dump_termtotals', 'dump_docmap')):
            continue
        assert not path.is_symlink()
        if path.is_file():
            members[str(path.relative_to(BASE))] = path.read_bytes()
for name in ('native-pruning-explanation-correctness-oct06.py', 'native-pruning-explanation-paired-controller-oct05.py',
             'native-pruning-explanation-floor-controller-oct06.py', 'native-pruning-explanation-k09-controls-oct06.py',
             'native-pruning-explanation-decision-oct06.json', 'native-pruning-explanation-integration-oct06.json',
             'native-pruning-explain-design-eager-oct05.md', 'native-pruning-explain-design-inline-oct05.md',
             'native-pruning-explain-design-shared-oct05.md', 'native-pruning-explain-design-judge-oct05.md',
             'native-pruning-explain-design-synthesis-oct05.md'):
    members[name] = (BASE / name).read_bytes()
for relative in decision['files_sha256']:
    data = (REPO / relative).read_bytes()
    assert hashlib.sha256(data).hexdigest() == decision['files_sha256'][relative]
    members['integrated-source/' + relative] = data
members['b50-to-tested.patch'] = subprocess.check_output(['git', '-C', str(REPO), 'diff', 'b50e2aef3abd77a43fbad56dbaecf2f6c0540a50', TESTED, '--', 'src'])
members['publisher.py'] = Path(__file__).read_bytes()
OUT.mkdir()
inventory = {}
with tarfile.open(OUT / 'evidence.tar.gz', 'w:gz') as tar:
    for name, data in sorted(members.items()):
        assert not name.startswith('/') and '..' not in Path(name).parts
        inventory[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        tar.addfile(info, io.BytesIO(data))
archive_sha = hashlib.sha256((OUT / 'evidence.tar.gz').read_bytes()).hexdigest()
(OUT / 'manifest.json').write_text(json.dumps({'attempt': 'P021', 'status': 'kept: allocation/size improvement; no significant incremental query-speed claim',
    'integrated_commit': CORE, 'tested_commit': TESTED, 'baseline_core': 'b50e2aef3abd77a43fbad56dbaecf2f6c0540a50',
    'archive_sha256': archive_sha, 'members': inventory}, indent=2) + '\n')
(OUT / 'README.md').write_text('''# Deferred BM25 explanations — October 6, 2026

Search setup now stores the IDF value and rounded display statistics, and builds
an owned explanation tree only when requested. Single-term statistics stay inline;
multi-term and explicit metadata are immutable and shared when cloned or boosted.
This removes eager tree construction and deep cloning from ordinary search setup.
Accepted source is `176410bb56a4d711b403a959fbafddf5b8d04847`, identical across
all source/Cargo/lock/config files to tested candidate `7322109659d1f163fbd24f804b2cff906bbdaa1b`.

## Measured efficiency

The unchanged standalone native release probe retains 1,000 outputs per operation
and repeats each operation three times. Setup and retention-vector allocation are
outside the counter. These are caller-thread allocation calls and requested-byte
totals, not peak/live memory, RSS or query latency.

| Operation | Before | After |
| --- | ---: | ---: |
| BM25 weight size |112 bytes |56 bytes |
| Native term scorer size |2128 bytes |2072 bytes |
| Single construction calls / requested bytes per output |2 /1360 |1 /1040 |
| Three-term native phrase construction |6 /2560 |3 /1132 |
| Tested single clone or boost |1 /160 |0 /0 |
| Tested native phrase clone or boost |4 /720 |0 /0 |

Classic phrase and no-explanation construction/clone paths remain unchanged.
On-demand explanation allocation counts are unchanged, but requested bytes rise:
single native/classic 1440→1600 (+11.1%); three-term native phrase 2000→2560
(+28%). New child vectors grow to capacity four instead of the original cloned
length. This cost is retained in the accepted evidence; exact-capacity construction
is the next separate experiment. Explicit-constructor allocation was not measured.

## Query latency and limits

The frozen supplemental paired ruler compares the candidate with retained b50:
40-second warmup, 256 samples per query, CPU4, 20 queries and both process orders.
All owned CPU jobs were idle during timing; user background load stayed active.
Ratios below are candidate/baseline geometric means; smaller is lower latency.

| Profile/mode | Baseline first | Candidate first |
| --- | ---: | ---: |
| DEFAULT TOP_10 |0.988232 |0.979781 |
| 0.9/0.4 TOP_10, initial |1.000488 |1.015725 |
| 0.9/0.4 TOP_10, justified repeat |0.991785 |0.988773 |
| DEFAULT COUNT |0.988466 |1.005979 |
| 0.9/0.4 COUNT |1.007450 |0.999065 |
| 2.5/1 COUNT |0.997999 |0.989413 |
| 2.5/1 TOP_10 |0.985791 |0.996585 |
| 0.9/0.4 TOP_10, same b50 binary |1.011696 |1.060548 |

The initial reverse 0.9/0.4 run had sharply higher absolute latencies and mixed
per-query outliers. Initial runs remain intact; favorable repeats do not replace
them. Same-binary controls show substantial load variation, including per-query
differences up to 25.3%. Latency broadly holds within this observed variation;
there is no significant incremental latency claim. The deterministic size and
allocation reduction justifies this efficiency keep. A loaded-machine comparison
cannot establish an all-query speed win.

These are not fresh Tantivy/Lucene timings. Supplemental absolute times cannot
be transferred to the [original Lucene ruler](../2026-10-05-native-pruning-finite/README.md).
Its DEFAULT advantage, near-parity 0.9/0.4 result and slower 2.5/1 result remain
separate retained observations at b50. This change adds no pruning or index-format
policy and leaves both retained indices unchanged. Full 47-family/public-API
parity and the all-query speed target remain unfinished.

## Correctness and evidence

All 42 frozen full-tree cases match the original eager implementation in debug
and exact native release, including owned output independence, provider call/error
order, signed zero, nonfinite bits, duplicate terms and ordered native f64 phrase
accumulation. The full normal library suite passes 1,381 tests (seven ignored;
one format-writing fixture filtered). The BM25 target passes 27 tests in debug
and native release. All eight unchanged native adapters build with opt3/LTO/native
CPU and retained locks. Root independently passes the frozen 330-query/16-case
matrix and all three strict Wiki20 gates, including 1,913 exact f32 score comparisons
per profile and unchanged source/binary/index guards.

[manifest.json](manifest.json) hashes every member of [evidence.tar.gz](evidence.tar.gz):
original/reviewed source and patch, frozen fixtures, allocation probes/locks/raw
results, build/test logs and provenance, regression outputs, all 16 raw paired and
control runs, frozen helper and design/decision records. Root independently
recomputed all sample medians, ratios and hashes. Large baseline packages, build
targets, binaries and indices are identified by provenance rather than embedded.
Absolute paths are historical provenance. Decision `P021` records the bounded keep.
''')
with tarfile.open(OUT / 'evidence.tar.gz') as tar:
    assert {member.name for member in tar.getmembers()} == set(inventory)
    for member in tar.getmembers():
        assert member.isfile()
        data = tar.extractfile(member).read()
        assert len(data) == inventory[member.name]['bytes']
        assert hashlib.sha256(data).hexdigest() == inventory[member.name]['sha256']
receipt = {'members_verified': len(inventory), 'archive_bytes': (OUT / 'evidence.tar.gz').stat().st_size,
           'archive_sha256': archive_sha, 'integrated_commit': CORE}
with (BASE / 'native-explanation-publication-oct06.json').open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps(receipt))
