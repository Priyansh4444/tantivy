# Direction A: one shared eager IDF tree

Design only, October 5. Baseline identified by the brief: pushed fork `41b10df91`, core `b50e2aef3`. Source inspected in `search/tantivy-pr2937`; no source edits, builds, tests, layout measurements, or timings performed.

Workflow investigation todos:
1. Trace the relevant source, configuration, and runtime path. For motivation questions, inspect the change history and rationale. — done via the brief and source listed below; no claim of independently auditing history.
2. Throughput checkpoint stays one line: `throughput checkpoint: n/a, read-only investigation`.
3. Produce an evidence-backed explanation (Overview / Key Concepts / How It Works / Where Things Live / Gotchas), or a recommendation with a tradeoffs table if the request is a decision between alternatives. — this package.
4. Apply a plain-writing pass to the reply. — done.

throughput checkpoint: n/a, read-only investigation

## Caller usage first

Every caller keeps its present API and order of work:

```rust
let weight = Bm25Weight::for_terms(provider, terms)?; // same eager tree and statistics calls
let scorer_weight = weight.boost_by(boost);          // same scalar behavior; shares IDF root
let owned: Explanation = scorer_weight.explain(norm, frequency);
// owned remains independently mutable with add_detail/add_context.
```

`for_one_term`, `new(Explanation, average)`, the parameterized private constructors, test-only native constructor, phrase fractional-frequency explain, and no-explain constructors keep their signatures. Explicit arbitrary trees are consumed and preserved exactly, including owned descriptions, nested details, contexts, and their root value. No new public type, API, helper call chain, or caller branch is needed.

The change shares only the IDF tree held by `Bm25Weight`. Returned `Explanation` remains the current fully owned mutable tree. Sharing the private root cannot leak into user-visible explanations.

## Data shape and exact production delta

```rust
#[derive(Clone)]
pub struct Bm25Weight {
    idf_explain: Option<Arc<Explanation>>, // only field representation changes
    // weight/cache/average/scoring/parameters/safe_normalization unchanged
}

// Keep the existing private input boundary:
fn build(
    idf: Score,
    idf_explain: Option<Explanation>,
    average_fieldnorm: Score,
    scoring: Bm25Scoring,
    parameters: Bm25Parameters,
) -> Self;

// In build's existing Self initializer:
idf_explain: idf_explain.map(Arc::new),

// In explain_with_frequency's existing Some branch:
explanation.add_detail(idf_explain.as_ref().clone());
```

No enum or wrapper: `Option` already expresses the complete domain, absent tree or present immutable root. `Arc` is already imported for the TF cache. The owned `build` input keeps all constructor call sites and the `idf_explain.value()` extraction literally unchanged. `None.map(...)` allocates nothing. There is exactly one `Arc` allocation for a present root, not one per child. Do not introduce `Arc::make_mut`, locks, caches, interior mutability, or root extraction tricks.

Keep derived `Clone` and both branches of `boost_by` verbatim. With `boost == 1.0f32`, `self.clone()` shares both cache and explanation root; otherwise the existing clone of `idf_explain` shares the root and `self.weight * boost` remains literal. Floating point boosts, signed zero, NaN, negative values, and infinity inherit their current behavior. Dropping the original weight leaves clones valid; the last owner frees the original tree. `explain` deliberately deep-clones the borrowed root into its result; mutating or dropping that result cannot affect any weight or another result.

## Exact contracts that constrain implementation

| Contract | Keep literally |
|---|---|
| Native term IDF | `x = ((doc_count - doc_freq) as f64 + 0.5) / (doc_freq as f64 + 0.5); (1.0 + x).ln() as Score` and existing assertion. Child n/N values remain their original `as Score` casts. |
| Native multi-term IDF | Each child IDF rounds to f32 first; accumulate `sum += f64::from(detail.value())` in term order, then `sum as Score` once. Keep each child and description `idf, sum of:`. No recomputation from counts on explain. |
| Classic term IDF | Existing f32 `idf` arithmetic; child label `N, total number of docs`, rather than native `N, number of docs with this field`. |
| Classic multi-term IDF | Existing ordered f32 `idf_sum += idf(...)`; single leaf `Explanation::new("idf", idf_sum)`, without added term children. |
| Weight and TF | Classic `idf * (1.0 + parameters.k1())`, native `idf`; all cache, scoring, bound, TF-explanation, and profile expressions remain unchanged. Boost still changes scalar weight only, not the stored IDF value. |
| Provider behavior | Validate nonempty/same-field terms before provider calls; one `field_statistics(field)` then one `doc_freq` per term in input order, including repeated terms. Preserve `?` short-circuit at the same failing call. Default `field_statistics` continues tokens then docs. Explain, clone, and boost never call providers. |
| Arbitrary constructor input | Wrap the supplied tree after extracting its existing root value. Do not infer provenance, replace it with generated IDF metadata, or discard contexts/descriptions. |
| Absent explanation | `new_without_explain`, `for_one_term_without_explain`, and `for_native_block_bounds` keep `None`; explain omits precisely that detail, not TF or classic `(K1+1)`. |
| Output format | Same node ordering, descriptions, value bits, context ordering, and optional children/context presence. Term wrapper still appends its `Term=...` context; phrase wrapper and fractional frequency remain intact. |

One important cold case: scoring-disabled `TermQuery::specialized_weight` currently uses explicit `Explanation::new("<no score>", 1.0)` through `Bm25Weight::new`. It remains present and gains the same root allocation; it must not be silently converted into a no-explain constructor.

## Module map and real clone path

Production edit is confined to three sites in `src/query/bm25.rs`: field at line 225, `build` initializer around line 461, and owned IDF attachment around line 730. `src/query/explanation.rs:18` and its public representation/serialization/Clone stay unchanged. Tests may add a test-only structural comparison helper there; it must not alter production fields or API.

Observed ordinary term path: `term_query.rs::specialized_weight` constructs BM25; `term_weight.rs:179::specialized_scorer` reads postings and norms, then at line 203 calls `self.similarity_weight.boost_by(boost)` before moving it into a boxed `TermScorer`. `scorer`, scored iteration, unscored iteration, pruning, and term explain reach this method, usually with 1.0. Missing term and all-match/no-score early returns bypass the clone. This is scorer setup per invoked segment path, not a clone per matched document.

`phrase_query/phrase_weight.rs:60::phrase_scorer_danger` maps its optional weight through `boost_by` before reading the terms' postings. It can thus clone even when a later posting is missing. Regex phrase and phrase-prefix weights also map through `boost_by`. Leave those paths untouched. Fractional phrase explain at line 178 continues `explain_with_frequency` on the original optional weight. Once constructed, score/bounds read scalar/cache/profile fields, never the explanation root.

## Expected costs and layout scope

| Operation | Baseline eager owned tree | Shared eager root |
|---|---|---|
| Initial IDF construction | Builds all current trees/temporary vectors | Same tree construction plus one root allocation and two Arc counters |
| Weight/scorer clone | Deep-clones detail vectors, contexts, and owned strings; borrowed static strings are cheap | One optional root pointer copy plus atomic reference-count increment; cache Arc cost unchanged |
| Boost | Same deep-clone cost plus unchanged scalar multiply for non-1 boost | Shared root plus unchanged scalar multiply |
| Owned explain | Deep-clones stored IDF subtree into result | Same subtree deep clone; still builds full TF/output tree |
| No-explain construction | No IDF tree allocation | Same |

This direction eliminates cold deep clones and shrinks the embedded hot object; it does **not** eliminate initial explanation-tree construction. Native/legacy single terms currently allocate a detail vector; native phrases build child detail vectors and temporary/root vectors. Preserve all of them. Classic multi-term leaf and `<no score>` leaf currently have no IDF-tree heap allocation and now gain one. An explicit context-rich arbitrary tree gains one root allocation but avoids cloning its owned strings in scorer setup. Very small/one-segment queries can lose if the added allocation costs more than the eliminated deep clone. This is a measurable hypothesis, not a promised improvement.

On the same native 64-bit target/compiler baseline, the brief reports `Bm25Weight = 112` bytes and `TermScorer = 2128` bytes. Source fields suggest an 80-byte inline `Option<Explanation>` becomes an 8-byte `Option<Arc<Explanation>>`; expected weight is 40 bytes, a 72-byte reduction. Embedded term scorer plausibly becomes 2056 bytes, subject to Rust field layout/padding. These are estimates, not measurements or stable ABI promises. Record both old/new `size_of`/alignment on the identical native build before accepting the layout claim. Keep large postings/decoder buffers separate from this size argument; their bytes do not disappear. There is no per-document root pointer dereference in score/bounds and no new hot branch, but layout/codegen effects need real paired runs.

A cheap ownership gate can inspect private fields in BM25 unit tests: `Arc::ptr_eq` across clone, boost(1), and boost(non-1); unchanged cache pointer; `None` retained; original owner dropped before using clone. This proves shared identity, not allocator counts. If allocation evidence is required, use an isolated diagnostic allocation-count process for construct versus repeated clone, keeping fixture creation/explain outside the counted region. Present roots must add one allocation at construction and repeated clones must add zero allocations; do not add a process-wide test allocator to production or claim ptr equality alone measures allocations.

## Verification plan: meaningful whole-tree baseline gates

Do this only in the later authorized implementation worktree. Expected output must come from the frozen baseline, not from `candidate.explain()` compared with its clone or from only comparing root scores.

1. Before source changes, capture complete expected finite trees for native single and native multi-term cases, classic single and classic multi-term, explicit nested/owned/context-rich constructor trees, absent-IDF weights, and clone/boost variants. Use baseline fixtures or a small copied baseline reference builder independent of candidate constructors. Include terms/counts selected to distinguish native rounded-f32/f64 sum from a f32 sum, duplicate terms, large counts above f32 integer precision, and nondefault parameters. Choose the discriminating phrase fixture during implementation; prove the two summations differ in bits.
2. Compare all nodes recursively: `value.to_bits()`, exact description, ordered children, `None` versus present details, exact ordered context strings, and context absence/presence. A `#[cfg(test)] pub(crate)` helper in `explanation.rs` can access private fields for this assertion without exposing production getters. Include nonfinite/signed-zero explicit values with bit comparison; JSON alone can hide nonfinite values. For finite fixtures also compare whole pretty JSON against the baseline to cover serialization shape. Preserve arbitrary tree payload bits rather than canonicalizing NaN constructor data.
3. Cover norms 0/1/255, integer and fractional frequencies, boost 1/non-1/zero/negative, DEFAULT and k09/nondefault profiles, and repeated explain calls. Mutate one returned tree via `add_detail` and `add_context`, then verify another returned tree still exactly matches the frozen baseline. Test a clone after original drop. These verify the owned-output contract; ptr equality separately verifies the optimization.
4. Recording providers assert exactly one field-statistics call, then ordered doc-frequency calls, including duplicates, plus error short-circuit and the default tokens/docs order. Exercise native override and classic default. No providers during explain/clone/boost. Verify no-IDF child omission, classic `(K1+1)` inclusion, native omission, native term-child labels, and classic phrase's leaf shape.
5. Retain current native raw-score/profile/bound gates and full native explanation integration checks through TermQuery/PhraseQuery/BoostQuery wrappers, then frozen supplemental native paired DEFAULT/k09 setup-sensitive ruler and count checks. Do not change writer/index/cache provenance, bound arithmetic, or query flow to improve the result. User all-query/all47 scope stays open; this isolated package cannot close it.

## Alternatives and rubric

Workflow's “Subtract Before You Add” changes the choice here: keep one existing `Option` boundary and replace storage only, instead of introducing another representation enum and reconstruction path.

| Alternative | Decision |
|---|---|
| `Option<Box<Explanation>>` | Similar inline size and added root allocation, but derived clone still deep-copies the tree; misses the observed scorer setup problem. |
| `Rc` | Same sharing idea without atomics, but unsuitable for the existing thread-safe query/weight ecosystem. Do not weaken auto-trait behavior. |
| Shared `Explanation` nodes/public Arc children | Larger API/serialization/mutation scope; root sharing alone solves weight cloning while preserving owned output. |
| Typed lazy IDF metadata | Can avoid initial generated-tree allocations, but needs provenance variants, reconstruction, exact cached scalars, and arbitrary-tree escape hatch. Worth a separate direction B package; it is not this isolated hypothesis. |
| Move explanation out into another hot/cold struct | Adds an abstraction and call surface beyond the single private root field. |

| Rubric (5 maximum) | Design assessment |
|---|---|
| Exact contracts | 5: no arithmetic/provider/caller rework; output tree clone stays owned. |
| Cold clone/construction saving | 3: removes repeated deep clones, but keeps eager construction and adds one root allocation, including leaf inputs. |
| Hot layout/surface | 5 expected: pointer-sized root and unchanged scoring surface; numerical size pending native measurement. |
| Minimality | 5: three production sites in one file, existing Arc import, no new production type/API. |
| Verifiable scope | 5: independent baseline whole-tree fixture comparison, pointer ownership gate, same-target layout evidence, frozen paired ruler. No measurements performed yet. |

Select A when the first experiment should isolate shared-root storage with the smallest compatibility risk. Acceptance still requires actual native correctness gates and paired performance; neither the B1 DEFAULT regression nor k09 gains can be attributed to this representation from the available evidence.
