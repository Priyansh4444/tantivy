
use std::cell::RefCell;
struct Spy {
    calls: RefCell<Vec<String>>,
    fail: Option<&'static str>,
}
impl Spy {
    fn new(fail: Option<&'static str>) -> Self { Self { calls: RefCell::new(Vec::new()), fail } }
    fn record(&self, call: String, value: u64) -> crate::Result<u64> {
        self.calls.borrow_mut().push(call.clone());
        if self.fail == Some(call.as_str()) {
            Err(crate::TantivyError::InvalidArgument(call))
        } else { Ok(value) }
    }
    fn freq(&self, term: &Term) -> crate::Result<u64> {
        self.record(format!("freq:{}",std::str::from_utf8(term.serialized_value_bytes()).unwrap()),53)
    }
}
impl Bm25StatisticsProvider for Spy {
    fn total_num_tokens(&self, _:Field) -> crate::Result<u64> { self.record("tokens".into(),1403) }
    fn total_num_docs(&self) -> crate::Result<u64> { self.record("docs".into(),347) }
    fn doc_freq(&self,term:&Term) -> crate::Result<u64> { self.freq(term) }
}
struct NativeSpy(Spy);
impl Bm25StatisticsProvider for NativeSpy {
    fn total_num_tokens(&self, _:Field) -> crate::Result<u64> { self.0.record("tokens".into(),1403) }
    fn total_num_docs(&self) -> crate::Result<u64> { self.0.record("docs".into(),347) }
    fn doc_freq(&self,term:&Term) -> crate::Result<u64> { self.0.freq(term) }
    fn field_statistics(&self,_:Field) -> crate::Result<Bm25FieldStatistics> {
        self.0.record("field".into(),0)?;
        Ok(Bm25FieldStatistics::native(347,1403))
    }
}
#[test]
fn provider_order_duplicates_failures_and_cold_operations() -> crate::Result<()> {
    let query=terms(&["a","b","a"]);
    let classic=Spy::new(None);
    let weight=Bm25Weight::for_terms(&classic,&query)?;
    let expected=["tokens","docs","freq:a","freq:b","freq:a"];
    assert_eq!(classic.calls.borrow().as_slice(),expected);
    let clone=weight.clone();let boosted=clone.boost_by(3.25).boost_by(1.0);
    drop(weight);drop(clone);drop(boosted.explain(91,7));
    assert_eq!(classic.calls.borrow().as_slice(),expected);
    let native=NativeSpy(Spy::new(None));
    let weight=Bm25Weight::for_terms(&native,&query)?;
    let expected=["field","freq:a","freq:b","freq:a"];
    assert_eq!(native.0.calls.borrow().as_slice(),expected);
    drop(weight.clone().boost_by(3.25).boost_by(1.0).explain_with_frequency(91,0.5));
    assert_eq!(native.0.calls.borrow().as_slice(),expected);
    for (failure,expected) in [
        ("tokens",vec!["tokens"]),
        ("docs",vec!["tokens","docs"]),
        ("freq:b",vec!["tokens","docs","freq:a","freq:b"]),
    ] {
        let spy=Spy::new(Some(failure));
        assert!(Bm25Weight::for_terms(&spy,&query).is_err());
        assert_eq!(spy.calls.borrow().as_slice(),expected);
    }
    for (failure,expected) in [
        ("field",vec!["field"]),
        ("freq:b",vec!["field","freq:a","freq:b"]),
    ] {
        let spy=NativeSpy(Spy::new(Some(failure)));
        assert!(Bm25Weight::for_terms(&spy,&query).is_err());
        assert_eq!(spy.0.calls.borrow().as_slice(),expected);
    }
    let single=NativeSpy(Spy::new(None));
    drop(Bm25Weight::for_terms(&single,&query[..1])?);
    assert_eq!(single.0.calls.borrow().as_slice(),["field","freq:a"]);
    let assertions=Spy::new(None);
    assert!(std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| Bm25Weight::for_terms(&assertions,&[]))).is_err());
    let mixed=[query[0].clone(),Term::from_field_text(Field::from_field_id(1),"a")];
    assert!(std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| Bm25Weight::for_terms(&assertions,&mixed))).is_err());
    assert!(assertions.calls.borrow().is_empty());
    Ok(())
}

#[test]
fn metadata_sharing_drop_and_independent_owned_outputs() -> crate::Result<()> {
    let stats=Statistics {docs:347,tokens:1403,freqs:vec![1,346],native:true,parameters:Bm25Parameters::DEFAULT};
    let base=Bm25Weight::for_terms(&stats,&terms(&["a","b","a"]))?;
    let clone=base.boost_by(1.0);
    assert!(Arc::ptr_eq(&base.cache,&clone.cache));
    let IdfExplanation::NativeSum {terms:records,..}=&base.idf_explain else {panic!("native phrase metadata")};
    let IdfExplanation::NativeSum {terms:copied,..}=&clone.idf_explain else {panic!("cloned native phrase metadata")};
    assert!(Arc::ptr_eq(records,copied));assert_eq!(records.len(),3);
    let boosted=base.boost_by(3.25);
    let IdfExplanation::NativeSum {terms:boosted_records,..}=&boosted.idf_explain else {panic!("boosted native phrase metadata")};
    assert!(Arc::ptr_eq(records,boosted_records));
    let weak=Arc::downgrade(records);
    let mut first=base.explain_with_frequency(91,0.5);
    let frozen:Value=serde_json::from_str(BASELINE).unwrap();
    let expected=frozen.as_array().unwrap().iter().find(|case|case["name"]=="native-f64-sum-witness").unwrap()["explanation"]["bits"].clone();
    drop(base);drop(boosted);assert!(weak.upgrade().is_some());
    let second=clone.explain_with_frequency(91,0.5);
    assert_eq!(second.bit_snapshot(),expected);
    assert_eq!(format!("{:08x}",clone.score_with_frequency(91,0.5).to_bits()),expected["value_bits"]);
    drop(clone);assert!(weak.upgrade().is_none());
    first.add_context("independent output mutation".into());first.add_const("extra",7.0);
    assert_ne!(first.bit_snapshot(),expected);assert_eq!(second.bit_snapshot(),expected);

    let mut supplied=Explanation::new_with_string("custom owned idf".into(),1.25);
    supplied.add_context("owned context".into());supplied.add_detail(Explanation::new_with_string("owned child".into(),-0.0));
    let weight=Bm25Weight::new(supplied,4.0);let boosted=weight.boost_by(3.25);
    let IdfExplanation::Explicit(shared)=&weight.idf_explain else {panic!("explicit metadata")};
    let IdfExplanation::Explicit(copied)=&boosted.idf_explain else {panic!("cloned explicit metadata")};
    assert!(Arc::ptr_eq(shared,copied));assert!(Arc::ptr_eq(&weight.cache,&boosted.cache));
    let weak=Arc::downgrade(shared);
    let mut output=boosted.explain(91,7);let expected=output.bit_snapshot();
    drop(weight);drop(boosted);assert!(weak.upgrade().is_none());
    output.add_context("after owners dropped".into());assert_ne!(output.bit_snapshot(),expected);

    let single=Bm25Weight::for_terms(&stats,&terms(&["a"]))?;
    assert!(matches!(single.idf_explain,IdfExplanation::Single(_)));
    let classic=Statistics {native:false,..stats};
    assert!(matches!(Bm25Weight::for_terms(&classic,&terms(&["a","b"]))?.idf_explain,IdfExplanation::ClassicScalar(_)));
    assert!(matches!(Bm25Weight::for_one_term_without_explain(53,347,4.0).idf_explain,IdfExplanation::None));
    Ok(())
}
