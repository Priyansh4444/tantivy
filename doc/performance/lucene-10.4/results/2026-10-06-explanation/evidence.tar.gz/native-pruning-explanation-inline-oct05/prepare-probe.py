from pathlib import Path
import hashlib,json,subprocess,tarfile,shutil
root=Path(__file__).resolve().parent
work=Path('/home/pronsh/Coding/playground/search/tantivy-pruning-explanation-inline-oct05')
archive=root/'baseline-package.tar';baseline=root/'baseline-package'
if archive.exists() or baseline.exists(): raise SystemExit('baseline already exists')
subprocess.run(['git','-C',str(work),'archive','--format=tar','--output',str(archive),'a2e525dbe'],check=True)
baseline.mkdir()
with tarfile.open(archive) as f:f.extractall(baseline,filter='data')
for label,path in [('baseline',baseline),('candidate',work)]:
 p=root/f'allocation-{label}';(p/'src').mkdir(parents=True)
 shutil.copy2(root/'allocation-probe.rs',p/'src/main.rs')
 (p/'Cargo.toml').write_text(f'''[package]\nname = "explanation-allocation-{label}"\nversion = "0.0.0"\nedition = "2021"\n[dependencies]\ntantivy = {{ path = "{path}" }}\n[profile.release]\nlto = true\nopt-level = 3\noverflow-checks = false\n''')
(root/'allocation-source-receipt.json').write_text(json.dumps({'baseline_revision':'a2e525dbe','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'probe_sha256':hashlib.sha256((root/'allocation-probe.rs').read_bytes()).hexdigest(),'scope':'standalone public constructors; no private explicit tree allocation measurement; no timing'},indent=2)+'\n')
