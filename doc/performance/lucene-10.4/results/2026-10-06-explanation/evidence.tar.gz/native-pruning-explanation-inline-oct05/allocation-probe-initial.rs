use std::alloc::{GlobalAlloc,Layout,System};
use std::sync::atomic::{AtomicBool,AtomicUsize,Ordering};
use tantivy::query::{Bm25Weight,Bm25StatisticsProvider};
use tantivy::schema::{Field,Schema,TEXT};
use tantivy::{Term,Index,doc};
struct Counting;
static ENABLED:AtomicBool=AtomicBool::new(false);
static CALLS:AtomicUsize=AtomicUsize::new(0);
static BYTES:AtomicUsize=AtomicUsize::new(0);
unsafe impl GlobalAlloc for Counting {
 unsafe fn alloc(&self,l:Layout)->*mut u8 {if ENABLED.load(Ordering::Relaxed){CALLS.fetch_add(1,Ordering::Relaxed);BYTES.fetch_add(l.size(),Ordering::Relaxed);}System.alloc(l)}
 unsafe fn alloc_zeroed(&self,l:Layout)->*mut u8 {if ENABLED.load(Ordering::Relaxed){CALLS.fetch_add(1,Ordering::Relaxed);BYTES.fetch_add(l.size(),Ordering::Relaxed);}System.alloc_zeroed(l)}
 unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8 {if ENABLED.load(Ordering::Relaxed){CALLS.fetch_add(1,Ordering::Relaxed);BYTES.fetch_add(n,Ordering::Relaxed);}System.realloc(p,l,n)}
 unsafe fn dealloc(&self,p:*mut u8,l:Layout){System.dealloc(p,l)}
}
#[global_allocator]static ALLOCATOR:Counting=Counting;
struct Classic;
impl Bm25StatisticsProvider for Classic {
 fn total_num_tokens(&self,_:Field)->tantivy::Result<u64>{Ok(15)}
 fn total_num_docs(&self)->tantivy::Result<u64>{Ok(3)}
 fn doc_freq(&self,_:&Term)->tantivy::Result<u64>{Ok(2)}
}
fn measure(name:&str,mut f:impl FnMut()->Bm25Weight){
 let mut results=Vec::with_capacity(1000);CALLS.store(0,Ordering::Relaxed);BYTES.store(0,Ordering::Relaxed);
 ENABLED.store(true,Ordering::Relaxed);
 for _ in 0..1000{results.push(std::hint::black_box(f()));}
 ENABLED.store(false,Ordering::Relaxed);
 println!("{name},{},{}",CALLS.load(Ordering::Relaxed),BYTES.load(Ordering::Relaxed));
 std::hint::black_box(results);
}
fn main()->tantivy::Result<()> {
 let mut schema=Schema::builder();let field=schema.add_text_field("text",TEXT);let index=Index::create_in_ram(schema.build());
 let mut writer=index.writer_with_num_threads(1,15_000_000)?;
 for text in ["a b a b c","a b c","a c"]{writer.add_document(doc!(field=>text))?;}writer.commit()?;drop(writer);
 let searcher=index.reader()?.searcher();let single=[Term::from_field_text(field,"a")];let phrase=[single[0].clone(),Term::from_field_text(field,"b"),single[0].clone()];
 println!("operation,allocation_calls,requested_bytes");
 for (name,provider,terms) in [("native-single",&searcher as &dyn Bm25StatisticsProvider,single.as_slice()),("native-phrase",&searcher as &dyn Bm25StatisticsProvider,phrase.as_slice()),("classic-single",&Classic as &dyn Bm25StatisticsProvider,single.as_slice()),("classic-phrase",&Classic as &dyn Bm25StatisticsProvider,phrase.as_slice())] {
  let base=Bm25Weight::for_terms(provider,terms)?;
  measure(&format!("{name}-construct"),||Bm25Weight::for_terms(provider,terms).unwrap());
  measure(&format!("{name}-clone"),||base.clone());
  measure(&format!("{name}-boost1"),||base.boost_by(1.0));
  measure(&format!("{name}-boost3.25"),||base.boost_by(3.25));
 }
 let base=Bm25Weight::for_one_term_without_explain(2,3,5.0);
 measure("no-explain-construct",||Bm25Weight::for_one_term_without_explain(2,3,5.0));
 measure("no-explain-clone",||base.clone());
 Ok(())
}
