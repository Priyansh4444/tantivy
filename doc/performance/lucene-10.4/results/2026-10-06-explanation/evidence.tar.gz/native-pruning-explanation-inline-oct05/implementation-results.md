# Inline BM25 explanation candidate — implementation proof

Candidate commit `7322109659d1f163fbd24f804b2cff906bbdaa1b` is clean in the existing isolated worktree. Only `src/query/bm25.rs`, the test-only `Explanation` snapshot, the dedicated tests, and the single frozen golden file are committed. Main was not modified by this agent. Root reviewed the complete source and test diff before native building.

The 42-case original baseline is frozen at SHA256 `3ba164f56afcf642adddc6df85a26aca669f9313835985d186678966100322ec`; original debug and exact native release fixtures match. Final CI has no expected-output regeneration branch. Candidate gates preserve whole explanation trees, optional fields, contexts, f32 bits, cache/weight/average/max-score/profile predicates, provider order and failure stops, independent owned outputs, and clone/drop lifetimes. The native phrase witness remains `412e5d5d`, distinct from f32 accumulation `412e5d5e`.

Focused debug passed 5 tests. Broader BM25 debug and exact native release each passed 27 tests. Full normal library testing passed 1,381 tests, ignored seven, and filtered only the authorized `create_format` writing fixture. Actual native release layout is weight 112 → 56 bytes (alignment eight), embedded term scorer 2,128 → 2,072 bytes.

The standalone caller-thread TLS probes retain 1,000 outputs per repetition and require three identical repetitions. Index/searcher setup and retention-vector allocation are excluded. Values below are per output, not timing or peak RSS. Both v2 probes reproduce all original 18 v1 rows exactly before adding five explanation-demand rows.

| Operation | Baseline calls / requested bytes | Candidate calls / requested bytes |
| --- | ---: | ---: |
| Native or classic single construction | 2 / 1,360 | 1 / 1,040 |
| Native three-term phrase construction | 6 / 2,560 | 3 / 1,132 |
| Native/classic single clone or boost | 1 / 160 | 0 / 0 |
| Native phrase clone or boost | 4 / 720 | 0 / 0 |
| Classic phrase or no-explain construction | 1 / 1,040 | 1 / 1,040 |
| Classic phrase or no-explain clone | 0 / 0 | 0 / 0 |
| Native/classic single explanation | 4 / 1,440 | 4 / 1,600 |
| Native phrase explanation | 7 / 2,000 | 7 / 2,560 |
| Classic phrase or no-explain explanation | 3 / 1,280 | 3 / 1,280 |

The explanation demand tradeoff is explicit: unchanged allocation counts, but 160 additional requested bytes per native/classic single output and 560 additional bytes per native phrase output. Construction and clone savings do not establish a timing win. Arbitrary private explicit-tree constructors are covered by semantic/ownership tests, not this public-constructor allocation probe.

All eight native adapters were built with `--locked`, native CPU, optimization three, LTO true, overflow checks false, and four jobs. The exclusive artifact directory is `artifacts/7322109659d1f163fbd24f804b2cff906bbdaa1b/`. Before/after HEAD, all tracked core source, all ten adapter sources, manifest, lockfile, and root review hashes match. Copied binaries match their build outputs and are read-only. `provenance.json` SHA256 is `b3cc99f1f6e15db6abb80dc41c4ccfce3c731648dac643521611cbb9c5a79e00`.

Auditable entry points: `implementation-completion-receipt.json`, `candidate-commit-receipt.json`, `allocation-v2-comparison.json`, the per-run receipts/logs, and native artifact `provenance.json`. The final guard-only v2 runner amendment, original reviewed runner, diff, and hashes are retained separately. All 1,063 original baseline archive files remain exact.

All owned CPU jobs finished. No benchmark scans or timing runs were performed. The prior B1 context remains the 29.5% target gain with the recorded 2.2–2.4% DEFAULT cost; the candidate has no timing result. The user's all-47 public Lucene API/all-query goal remains open for root's correctness controller, frozen paired ruler, and subsequent hillclimb work.
