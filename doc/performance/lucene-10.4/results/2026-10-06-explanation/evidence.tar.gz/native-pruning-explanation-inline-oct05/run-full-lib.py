#!/usr/bin/env python3
from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys
root=Path(__file__).resolve().parent
work=root.parent.parent/'tantivy-pruning-explanation-inline-oct05'
phase='candidate-full-debug-lib-07'
log=root/f'{phase}.log';receipt=root/f'{phase}-receipt.json'
assert not log.exists() and not receipt.exists(), 'retain every prior run'
env=os.environ.copy();env['RUSTFLAGS']='-C target-cpu=native';env['CARGO_TARGET_DIR']=str(root/'test-target')
command=['cargo','test','--lib','--jobs','4','--','--skip','create_format','--test-threads','4','--nocapture']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=['src/query/bm25.rs','src/query/explanation.rs','src/query/bm25_explanation_tests.rs','src/query/bm25_explanation_baseline.json']
source={name:sha(work/name) for name in paths}
r={'phase':phase,'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':str(work),'command':command,'rust_flags':env['RUSTFLAGS'],'target_dir':env['CARGO_TARGET_DIR'],'profile':{'release':False,'opt-level':0,'overflow-checks':True},'status':'running','source_sha256':source,'skip_reason':'create_format writes compatibility format fixture; normal library suite otherwise complete'}
receipt.write_text(json.dumps(r,indent=2)+'\n')
with log.open('x') as out:result=subprocess.run(command,cwd=work,env=env,stdout=out,stderr=subprocess.STDOUT)
after={name:sha(work/name) for name in paths}
r.update(status='complete',exit_code=result.returncode,ended_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=sha(log),source_after_sha256=after,source_unchanged=after==source)
receipt.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));assert source==after;sys.exit(result.returncode)
