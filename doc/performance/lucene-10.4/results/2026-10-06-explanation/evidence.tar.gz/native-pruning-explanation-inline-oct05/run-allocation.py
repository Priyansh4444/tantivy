#!/usr/bin/env python3
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
root=Path(__file__).resolve().parent
label=sys.argv[1]
if label not in ('baseline','candidate'):raise SystemExit('expected baseline/candidate')
package=root/f'allocation-{label}';output=root/f'allocation-{label}.csv';log=root/f'allocation-{label}-build.log';receipt=root/f'allocation-{label}-run.json'
if any(p.exists() for p in [output,log,receipt]):raise SystemExit('refuse to replace retained run')
env=os.environ.copy();env['RUSTFLAGS']='-C target-cpu=native';env['CARGO_TARGET_DIR']=str(root/'allocation-target')
cmd=['cargo','run','--release','--jobs','4','--manifest-path',str(package/'Cargo.toml')]
r={'label':label,'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'rust_flags':env['RUSTFLAGS'],'profile':{'lto':True,'opt-level':3,'overflow-checks':False},'status':'running','probe_sha256':hashlib.sha256((package/'src/main.rs').read_bytes()).hexdigest(),'scope':'caller-thread allocations/requested-byte total for 1000 retained weights; 3 deterministic repetitions; preallocated retention vec/index/searcher excluded; no timing'}
receipt.write_text(json.dumps(r,indent=2)+'\n')
with output.open('w') as out,log.open('w') as err:result=subprocess.run(cmd,cwd=package,env=env,stdout=out,stderr=err)
r.update(status='complete',exit_code=result.returncode,ended_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),output_sha256=hashlib.sha256(output.read_bytes()).hexdigest(),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest());receipt.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));sys.exit(result.returncode)
