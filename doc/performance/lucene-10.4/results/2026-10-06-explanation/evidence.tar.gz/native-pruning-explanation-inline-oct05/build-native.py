#!/usr/bin/env python3
"""Build all eight native adapters into a new immutable candidate revision artifact."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
FORK = ROOT.parent.parent / 'tantivy-pruning-explanation-inline-oct05'
ADAPTER = ROOT / 'adapter'
TOOLS = FORK / 'doc/performance/lucene-10.4'
ORIGINAL = ROOT.parent / 'native-perf-adapter-oct03'
BINS = ('do_query', 'validate_index', 'reencode_index', 'payload_identity', 'payload_fixtures',
        'build_index', 'dump_termtotals', 'dump_docmap')
SUPPORT = ('shared/bm25_profile.rs', 'shared/wiki_physical.rs')
FLAGS = '-C target-cpu=native'
PROFILE = {'lto': True, 'opt-level': 3, 'overflow-checks': False}


def command(*args):
    return subprocess.check_output(args, text=True, cwd=ROOT).strip()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def guards(revision):
    assert command('git', '-C', str(FORK), 'rev-parse', 'HEAD') == revision
    assert command('git', '-C', str(FORK), 'status', '--porcelain') == '', 'candidate worktree must be clean'
    review = json.loads((ROOT / 'root-source-review-oct06.json').read_text())
    assert review['root_reviewed_actual_source']
    for name, expected in review['files_sha256'].items():
        assert digest(FORK / name) == expected, ('reviewed candidate changed', name)
    names = tuple(name + '.rs' for name in BINS) + SUPPORT
    sources = {name: digest(ADAPTER / 'src/bin' / name) for name in names}
    for name, expected in sources.items():
        assert digest(TOOLS / name) == expected, ('adapter differs from original source', name)
    expected_manifest = (ORIGINAL / 'Cargo.toml').read_text().replace(
        str(ROOT.parent.parent / 'tantivy-pr2937'), str(FORK))
    assert (ADAPTER / 'Cargo.toml').read_text() == expected_manifest
    assert (ADAPTER / 'Cargo.lock').read_bytes() == (ORIGINAL / 'Cargo.lock').read_bytes()
    core = {name: digest(FORK / name) for name in
            command('git', '-C', str(FORK), 'ls-files', 'src', 'Cargo.toml', 'Cargo.lock', '.cargo').splitlines()}
    return {'commit': revision, 'core_files_sha256': core,
            'adapter_sources_sha256': sources, 'manifest_sha256': digest(ADAPTER / 'Cargo.toml'),
            'cargo_lock_sha256': digest(ADAPTER / 'Cargo.lock'),
            'original_lock_sha256': digest(ORIGINAL / 'Cargo.lock'),
            'root_review_sha256': digest(ROOT / 'root-source-review-oct06.json'),
            'builder_sha256': digest(Path(__file__))}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', action='store_true')
    parser.add_argument('--expect-commit', required=True)
    parser.add_argument('--jobs', type=int, default=4)
    args = parser.parse_args()
    assert args.jobs == 4, 'bounded build uses exactly four jobs'
    revision = command('git', '-C', str(FORK), 'rev-parse', 'HEAD')
    assert revision == args.expect_commit, 'full exact candidate commit required'
    artifact = ROOT / 'artifacts' / revision
    argv = ['cargo', 'build', '--locked', '--manifest-path', str(ADAPTER / 'Cargo.toml'),
            '--target-dir', str(artifact / 'target'), '--release', '--jobs', str(args.jobs)]
    for name in BINS:
        argv += ['--bin', name]
    plan = {'commit': revision, 'command': argv, 'rust_flags': FLAGS, 'profile': PROFILE,
            'artifact_directory': str(artifact), 'timing': False}
    if args.plan:
        print(json.dumps(plan, indent=2))
        return
    artifact.mkdir(parents=True, exist_ok=False)
    write(artifact / 'execution-started.json', {**plan, 'utc': datetime.now(timezone.utc).isoformat()})
    before = guards(revision)
    write(artifact / 'guards-before.json', before)
    compiler = {'rustc': command('rustc', '-vV'), 'cargo': command('cargo', '-V')}
    write(artifact / 'compiler.json', compiler)
    environment = os.environ.copy()
    environment['RUSTFLAGS'] = FLAGS
    environment['CARGO_PROFILE_RELEASE_LTO'] = 'true'
    environment['CARGO_PROFILE_RELEASE_OPT_LEVEL'] = '3'
    environment['CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS'] = 'false'
    with (artifact / 'build.stdout').open('x') as stdout, (artifact / 'build.stderr').open('x') as stderr:
        result = subprocess.run(argv, env=environment, cwd=ADAPTER, stdout=stdout, stderr=stderr)
    write(artifact / 'build-result.json', {'command': argv, 'returncode': result.returncode,
          'rust_flags': FLAGS, 'profile': PROFILE, 'stdout_sha256': digest(artifact / 'build.stdout'),
          'stderr_sha256': digest(artifact / 'build.stderr'), 'ended_at_utc': datetime.now(timezone.utc).isoformat()})
    assert result.returncode == 0, 'build failed; preserve this artifact and all logs'
    after = guards(revision)
    write(artifact / 'guards-after.json', after)
    assert after == before, 'source/provenance changed during build'
    binaries = {}
    for name in BINS:
        destination = artifact / name
        assert not destination.exists()
        shutil.copy2(artifact / 'target/release' / name, destination)
        binaries[name] = digest(destination)
    version = int(re.search(r'INDEX_FORMAT_VERSION: u32 = (\d+)', (FORK / 'src/lib.rs').read_text()).group(1))
    provenance = {**plan, **compiler, 'index_format': version, 'manifest_sha256': before['manifest_sha256'],
        'cargo_lock_sha256': before['cargo_lock_sha256'], 'sources_sha256': before['adapter_sources_sha256'],
        'core_files_sha256': before['core_files_sha256'], 'binaries_sha256': binaries,
        'guards_equal': True, 'built_at_utc': datetime.now(timezone.utc).isoformat()}
    write(artifact / 'provenance.json', provenance)
    for name in BINS + ('provenance.json', 'guards-before.json', 'guards-after.json', 'compiler.json',
                        'execution-started.json', 'build-result.json', 'build.stdout', 'build.stderr'):
        path = artifact / name
        path.chmod(0o555 if name in BINS else 0o444)
    print(json.dumps({'artifact_directory': str(artifact), 'binaries_sha256': binaries,
                     'provenance_sha256': digest(artifact / 'provenance.json')}, indent=2))


if __name__ == '__main__':
    main()
