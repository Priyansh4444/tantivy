use std::alloc::{GlobalAlloc,Layout,System};
use std::cell::Cell;
use tantivy::query::{Bm25Weight,Bm25StatisticsProvider};
use tantivy::schema::{Field,Schema,TEXT};
use tantivy::{Term,Index,doc};
struct Counting;
#[derive(Clone,Copy,Debug,Default,PartialEq,Eq)]
struct Counts { enabled:bool, calls:usize, bytes:usize }
thread_local! { static COUNTS:Cell<Counts> = const { Cell::new(Counts { enabled:false,calls:0,bytes:0 }) }; }
fn record(bytes:usize) {
 // The allocator can run during thread teardown; absent TLS means tracking is off.
 let _=COUNTS.try_with(|slot| {let mut counts=slot.get();if counts.enabled {counts.calls+=1;counts.bytes+=bytes;slot.set(counts);}});
}
unsafe impl GlobalAlloc for Counting {
 unsafe fn alloc(&self,l:Layout)->*mut u8 {record(l.size());System.alloc(l)}
 unsafe fn alloc_zeroed(&self,l:Layout)->*mut u8 {record(l.size());System.alloc_zeroed(l)}
 unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8 {record(n);System.realloc(p,l,n)}
 unsafe fn dealloc(&self,p:*mut u8,l:Layout){System.dealloc(p,l)}
}
#[global_allocator]static ALLOCATOR:Counting=Counting;
struct Classic;
impl Bm25StatisticsProvider for Classic {
 fn total_num_tokens(&self,_:Field)->tantivy::Result<u64>{Ok(15)}
 fn total_num_docs(&self)->tantivy::Result<u64>{Ok(3)}
 fn doc_freq(&self,_:&Term)->tantivy::Result<u64>{Ok(2)}
}
fn measure(name:&str,mut f:impl FnMut()->Bm25Weight){
 let mut previous=None;
 for _ in 0..3 {
  // This retained-vector allocation is outside the measured caller-thread region.
  let mut results=Vec::with_capacity(1000);
  COUNTS.with(|slot|slot.set(Counts {enabled:true,calls:0,bytes:0}));
  for _ in 0..1000{results.push(std::hint::black_box(f()));}
  let counts=COUNTS.with(|slot|{let mut counts=slot.get();counts.enabled=false;slot.set(counts);counts});
  if let Some(expected)=previous {assert_eq!(counts,expected,"non-deterministic allocation counts: {name}");}
  previous=Some(counts);
  std::hint::black_box(results);
 }
 let counts=previous.unwrap();println!("{name},1000,3,{},{}",counts.calls,counts.bytes);
}
fn main()->tantivy::Result<()> {
 let mut schema=Schema::builder();let field=schema.add_text_field("text",TEXT);let index=Index::create_in_ram(schema.build());
 let mut writer=index.writer_with_num_threads(1,15_000_000)?;
 for text in ["a b a b c","a b c","a c"]{writer.add_document(doc!(field=>text))?;}writer.commit()?;drop(writer);
 let searcher=index.reader()?.searcher();let single=[Term::from_field_text(field,"a")];let phrase=[single[0].clone(),Term::from_field_text(field,"b"),single[0].clone()];
 println!("operation,weights_per_repeat,repeats,caller_thread_allocation_calls,caller_thread_requested_bytes");
 for (name,provider,terms) in [("native-single",&searcher as &dyn Bm25StatisticsProvider,single.as_slice()),("native-phrase",&searcher as &dyn Bm25StatisticsProvider,phrase.as_slice()),("classic-single",&Classic as &dyn Bm25StatisticsProvider,single.as_slice()),("classic-phrase",&Classic as &dyn Bm25StatisticsProvider,phrase.as_slice())] {
  let base=Bm25Weight::for_terms(provider,terms)?;
  measure(&format!("{name}-construct"),||Bm25Weight::for_terms(provider,terms).unwrap());
  measure(&format!("{name}-clone"),||base.clone());
  measure(&format!("{name}-boost1"),||base.boost_by(1.0));
  measure(&format!("{name}-boost3.25"),||base.boost_by(3.25));
 }
 let base=Bm25Weight::for_one_term_without_explain(2,3,5.0);
 measure("no-explain-construct",||Bm25Weight::for_one_term_without_explain(2,3,5.0));
 measure("no-explain-clone",||base.clone());
 Ok(())
}
