from pathlib import Path
import shutil,json,hashlib,subprocess
w=Path('/home/pronsh/Coding/playground/search/tantivy-pruning-explanation-inline-oct05')
a=Path('/home/pronsh/Coding/playground/search/bench/native-pruning-explanation-inline-oct05'); a.mkdir()
(a/'baseline-source').mkdir()
for f in ['bm25.rs','explanation.rs','bm25_parameter_tests.rs','term_query/term_weight.rs','phrase_query/phrase_weight.rs']:
 p=a/'baseline-source'/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(w/'src/query'/f,p)
p=w/'src/query/explanation.rs';p.write_text(p.read_text()+'''
#[cfg(test)]
impl Explanation {
    /// Lossless test snapshot: preserve nonfinite/signed-zero bits and optional fields.
    pub(crate) fn bit_snapshot(&self) -> serde_json::Value {
        serde_json::json!({
            "value_bits": format!("{:08x}", self.value.to_bits()),
            "description": self.description,
            "details": self.details.as_ref().map(|details| details.iter().map(Self::bit_snapshot).collect::<Vec<_>>()),
            "context": self.context,
        })
    }

    pub(crate) fn is_finite_tree(&self) -> bool {
        self.value.is_finite() && self.details.as_ref().is_none_or(|details| details.iter().all(Self::is_finite_tree))
    }
}
''')
p=w/'src/query/bm25.rs';p.write_text(p.read_text()+'''
#[cfg(test)]
#[path = "bm25_explanation_tests.rs"]
mod explanation_tests;
''')
