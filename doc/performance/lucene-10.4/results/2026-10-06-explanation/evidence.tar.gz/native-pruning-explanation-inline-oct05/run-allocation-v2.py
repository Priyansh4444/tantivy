#!/usr/bin/env python3
from pathlib import Path
import csv,datetime,hashlib,json,os,subprocess,sys
root=Path(__file__).resolve().parent
label=sys.argv[1]
assert label in ('baseline','candidate')
package=root/f'allocation-v2-{label}'
output=root/f'allocation-v2-{label}.csv';log=root/f'allocation-v2-{label}-build.log';receipt=root/f'allocation-v2-{label}-run.json'
assert not any(p.exists() for p in [output,log,receipt]), 'retain every prior v2 run'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prepared=json.loads((root/'allocation-v2-source-receipt.json').read_text())
reviewed=json.loads((root/'root-source-review-oct06.json').read_text())
work=root.parent.parent/'tantivy-pruning-explanation-inline-oct05'
core={name:sha(work/name) for name in reviewed['files_sha256']}
assert core==reviewed['files_sha256']
assert sha(package/'src/main.rs')==prepared['probe_sha256']==sha(root/'allocation-probe-v2.rs')
assert sha(package/'Cargo.toml')==prepared['packages'][label]['manifest_sha256']
assert sha(package/'Cargo.lock')==prepared['packages'][label]['v2_lock_sha256']
v1names=f'explanation-allocation-{label}';v2names=f'explanation-allocation-v2-{label}'
assert (package/'Cargo.lock').read_text()==(root/f'allocation-{label}/Cargo.lock').read_text().replace(f'name = "{v1names}"',f'name = "{v2names}"')
env=os.environ.copy();env['RUSTFLAGS']='-C target-cpu=native';env['CARGO_TARGET_DIR']=str(root/'allocation-target')
env['CARGO_PROFILE_RELEASE_LTO']='true'
env['CARGO_PROFILE_RELEASE_OPT_LEVEL']='3'
env['CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS']='false'
cmd=['cargo','run','--locked','--release','--jobs','4','--manifest-path',str(package/'Cargo.toml')]
r={'label':label,'version':2,'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'rust_flags':env['RUSTFLAGS'],'profile':{'lto':True,'opt-level':3,'overflow-checks':False},'status':'running','probe_sha256':sha(package/'src/main.rs'),'manifest_sha256':sha(package/'Cargo.toml'),'cargo_lock_sha256':sha(package/'Cargo.lock'),'candidate_source_sha256':core,'target_dir':env['CARGO_TARGET_DIR'],'scope':'original18 operations plus5 explain-demand operations; each1000 retained outputs x3 deterministic callerTLS repeats; setup/retention vector excluded; requested-byte totals only; no timing'}
receipt.write_text(json.dumps(r,indent=2)+'\n')
with output.open('x') as out,log.open('x') as err:result=subprocess.run(cmd,cwd=package,env=env,stdout=out,stderr=err)
after={name:sha(work/name) for name in reviewed['files_sha256']}
r.update(status='complete',exit_code=result.returncode,ended_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),output_sha256=sha(output),log_sha256=sha(log),candidate_source_unchanged=after==core,probe_unchanged=sha(package/'src/main.rs')==prepared['probe_sha256'],lock_unchanged=sha(package/'Cargo.lock')==prepared['packages'][label]['v2_lock_sha256'],manifest_unchanged=sha(package/'Cargo.toml')==prepared['packages'][label]['manifest_sha256'])
if result.returncode==0:
 rows=list(csv.DictReader(output.open()));original=list(csv.DictReader((root/f'allocation-{label}.csv').open()))
 r['first_18_exact_v1']=rows[:18]==original;r['operations']=len(rows)
 r['all_retained_outputs_and_repeats_exact']=all(row['weights_per_repeat']=='1000' and row['repeats']=='3' for row in rows)
receipt.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
assert r['candidate_source_unchanged'] and r['probe_unchanged'] and r['lock_unchanged'] and r['manifest_unchanged']
if result.returncode==0:assert r['first_18_exact_v1'] and r['operations']==23 and r['all_retained_outputs_and_repeats_exact']
sys.exit(result.returncode)
