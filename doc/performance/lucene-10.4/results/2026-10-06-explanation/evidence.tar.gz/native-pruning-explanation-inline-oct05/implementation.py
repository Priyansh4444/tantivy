from pathlib import Path
p=Path('/home/pronsh/Coding/playground/search/tantivy-pruning-explanation-inline-oct05/src/query/bm25.rs')
s=p.read_text()
s=s.replace('fn native_idf_explanation(doc_freq: u64, doc_count: u64) -> Explanation {','// Kept only as the original eager oracle for existing parameter/reference tests.\n#[cfg(test)]\nfn native_idf_explanation(doc_freq: u64, doc_count: u64) -> Explanation {')
pos=s.index('fn cached_tf_component(')
s=s[:pos]+'''/// Rounded IDF and display statistics, captured before any query boost.
#[derive(Clone, Copy)]
struct IdfTermStatistics {
    value: Score,
    doc_freq: Score,
    doc_count: Score,
}

#[derive(Clone)]
enum IdfExplanation {
    None,
    Single(IdfTermStatistics),
    NativeSum {
        value: Score,
        terms: Arc<[IdfTermStatistics]>,
    },
    ClassicScalar(Score),
    Explicit(Arc<Explanation>),
}

impl IdfExplanation {
    fn materialize(&self, scoring: Bm25Scoring) -> Option<Explanation> {
        match self {
            Self::None => None,
            Self::Single(statistics) => Some(single_idf_explanation(*statistics, scoring)),
            Self::NativeSum { value, terms } => {
                let mut explanation = Explanation::new("idf, sum of:", *value);
                for statistics in terms.iter() {
                    explanation.add_detail(single_idf_explanation(
                        *statistics,
                        Bm25Scoring::NativeLucene,
                    ));
                }
                Some(explanation)
            }
            Self::ClassicScalar(value) => Some(Explanation::new("idf", *value)),
            Self::Explicit(explanation) => Some((**explanation).clone()),
        }
    }
}

fn single_idf_explanation(statistics: IdfTermStatistics, scoring: Bm25Scoring) -> Explanation {
    let mut explanation = Explanation::new(
        "idf, computed as log(1 + (N - n + 0.5) / (n + 0.5))",
        statistics.value,
    );
    explanation.add_const("n, number of docs containing this term", statistics.doc_freq);
    explanation.add_const(
        match scoring {
            Bm25Scoring::LegacyClassic => "N, total number of docs",
            Bm25Scoring::NativeLucene => "N, number of docs with this field",
        },
        statistics.doc_count,
    );
    explanation
}

'''+s[pos:]
s=s.replace('idf_explain: Option<Explanation>,','idf_explain: IdfExplanation,')
a=s.index('        if collection.scoring == Bm25Scoring::NativeLucene {',s.index('pub fn for_terms('))
b=s.index('\n        if terms.len() == 1 {',a)
s=s[:a]+'''        if collection.scoring == Bm25Scoring::NativeLucene {
            let (idf, idf_explain) = if terms.len() == 1 {
                let doc_freq = statistics.doc_freq(&terms[0])?;
                let detail = IdfTermStatistics {
                    value: native_idf(doc_freq, total_num_docs),
                    doc_freq: doc_freq as Score,
                    doc_count: total_num_docs as Score,
                };
                (detail.value, IdfExplanation::Single(detail))
            } else {
                // Lucene rounds each individual IDF to f32, sums in f64, then rounds once.
                let mut sum = 0.0f64;
                let mut details = Vec::with_capacity(terms.len());
                for term in terms {
                    let doc_freq = statistics.doc_freq(term)?;
                    let detail = IdfTermStatistics {
                        value: native_idf(doc_freq, total_num_docs),
                        doc_freq: doc_freq as Score,
                        doc_count: total_num_docs as Score,
                    };
                    sum += f64::from(detail.value);
                    details.push(detail);
                }
                let value = sum as Score;
                (value, IdfExplanation::NativeSum { value, terms: details.into() })
            };
            return Ok(Bm25Weight::build(
                idf,
                idf_explain,
                average_fieldnorm,
                Bm25Scoring::NativeLucene,
                parameters,
            ));
        }
'''+s[b:]
s=s.replace('''            let idf_explain = Explanation::new("idf", idf_sum);
            Ok(Bm25Weight::new_with_parameters(
                idf_explain,
                average_fieldnorm,
                parameters,
            ))''','''            Ok(Bm25Weight::build(
                idf_sum,
                IdfExplanation::ClassicScalar(idf_sum),
                average_fieldnorm,
                Bm25Scoring::LegacyClassic,
                parameters,
            ))''')
a=s.index('        let mut idf_explain =',s.index('fn for_one_term_with_parameters('));b=s.index('\n    }',a)
s=s[:a]+'''        let idf_explain = IdfExplanation::Single(IdfTermStatistics {
            value: idf,
            doc_freq: term_doc_freq as Score,
            doc_count: total_num_docs as Score,
        });
        Bm25Weight::build(
            idf,
            idf_explain,
            avg_fieldnorm,
            Bm25Scoring::LegacyClassic,
            parameters,
        )'''+s[b:]
s=s.replace('            Some(idf_explain),','            IdfExplanation::Explicit(Arc::new(idf_explain)),')
s=s.replace('''            None,
            average_fieldnorm,
            Bm25Scoring::''','''            IdfExplanation::None,
            average_fieldnorm,
            Bm25Scoring::''')
s=s.replace('    fn new_native_with_parameters(','    #[cfg(test)]\n    fn new_native_with_parameters(')
s=s.replace('''        if let Some(idf_explain) = &self.idf_explain {
            explanation.add_detail(idf_explain.clone());
        }''','''        if let Some(idf_explain) = self.idf_explain.materialize(self.scoring) {
            explanation.add_detail(idf_explain);
        }''')
p.write_text(s)
