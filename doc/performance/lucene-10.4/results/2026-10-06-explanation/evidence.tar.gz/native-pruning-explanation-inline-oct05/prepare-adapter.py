from pathlib import Path
import shutil,json,hashlib,subprocess
r=Path(__file__).resolve().parent
main=Path('/home/pronsh/Coding/playground/search/tantivy-pr2937');tool=main/'doc/performance/lucene-10.4';adapter=r/'adapter';adapter.mkdir();(adapter/'src/bin/shared').mkdir(parents=True)
files=['do_query.rs','validate_index.rs','reencode_index.rs','payload_identity.rs','payload_fixtures.rs','build_index.rs','dump_termtotals.rs','dump_docmap.rs','shared/bm25_profile.rs','shared/wiki_physical.rs']
for name in files:shutil.copy2(tool/name,adapter/'src/bin'/name)
manifest=Path('/home/pronsh/Coding/playground/search/bench/native-perf-adapter-oct03/Cargo.toml').read_text().replace(str(main),'/home/pronsh/Coding/playground/search/tantivy-pruning-explanation-inline-oct05')
(adapter/'Cargo.toml').write_text(manifest)
(r/'adapter-source-receipt.json').write_text(json.dumps({'source_main_commit':subprocess.check_output(['git','-C',str(main),'rev-parse','HEAD'],text=True).strip(),'copied_without_source_edits':True,'built':False,'files_sha256':{name:hashlib.sha256((adapter/'src/bin'/name).read_bytes()).hexdigest() for name in files},'manifest_sha256':hashlib.sha256((adapter/'Cargo.toml').read_bytes()).hexdigest()},indent=2)+'\n')
