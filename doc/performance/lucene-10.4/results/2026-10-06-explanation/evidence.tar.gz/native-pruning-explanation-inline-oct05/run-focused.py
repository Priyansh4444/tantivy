#!/usr/bin/env python3
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
root=Path(__file__).resolve().parent
work=Path('/home/pronsh/Coding/playground/search/tantivy-pruning-explanation-inline-oct05')
phase,scope=sys.argv[1:3]
log=root/f'{phase}.log'; receipt=root/f'{phase}-receipt.json'
if log.exists() or receipt.exists(): raise SystemExit('refuse to replace a prior run')
env=os.environ.copy();env['RUSTFLAGS']='-C target-cpu=native';env['CARGO_TARGET_DIR']=str(root/'test-target')
if phase.startswith('baseline'):env['INLINE_BASELINE_FIXTURE_OUT']=str(root/('baseline-fixtures-release.json' if 'release' in phase else 'baseline-fixtures.json'))
command=['cargo','test','--lib',scope,'--jobs','4','--','--nocapture']
if 'release' in phase:
    command.insert(2,'--release')
    env['CARGO_PROFILE_RELEASE_LTO']='true'
    env['CARGO_PROFILE_RELEASE_OPT_LEVEL']='3'
    env['CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS']='false'
r={'phase':phase,'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':str(work),'command':command,'rust_flags':env['RUSTFLAGS'],'target_dir':env['CARGO_TARGET_DIR'],'profile':{'release': 'release' in phase, 'lto':True if 'release' in phase else None, 'opt-level':3 if 'release' in phase else 0, 'overflow-checks':False if 'release' in phase else True},'status':'running','source_sha256':{str(p.relative_to(work)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [work/'src/query/bm25.rs',work/'src/query/explanation.rs',work/'src/query/bm25_explanation_tests.rs']}}
receipt.write_text(json.dumps(r,indent=2)+'\n')
with log.open('w') as f: result=subprocess.run(command,cwd=work,env=env,stdout=f,stderr=subprocess.STDOUT)
r.update(status='complete',exit_code=result.returncode,ended_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest());receipt.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));sys.exit(result.returncode)
