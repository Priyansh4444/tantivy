#!/usr/bin/env python3
"""Serial frozen paired ruler for one isolated explanation representation trial."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import signal
import statistics
import subprocess
import time
import os

BASE = Path(__file__).resolve().parent
REPO = BASE.parent / 'tantivy-pr2937'
RULER = BASE / 'native-pruning-paired-harness-oct05'
BASELINE = 'b50e2aef3abd77a43fbad56dbaecf2f6c0540a50'
BASE_BINARY = BASE / 'native-perf-adapter-oct03/artifacts' / BASELINE / 'do_query'

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def write(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate-binary', type=Path, required=True)
    parser.add_argument('--candidate-commit', required=True)
    parser.add_argument('--candidate-worktree', type=Path, required=True)
    parser.add_argument('--candidate-build-receipt', type=Path, required=True)
    parser.add_argument('--correctness-receipt', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--all-own-cpu-jobs-idle', action='store_true', required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    commit = subprocess.check_output(['git', '-C', str(args.candidate_worktree), 'rev-parse', 'HEAD'], text=True).strip()
    assert commit == args.candidate_commit and len(commit) == 40
    assert not subprocess.check_output(['git', '-C', str(args.candidate_worktree), 'status', '--porcelain'], text=True).strip()
    subprocess.run(['git', '-C', str(args.candidate_worktree), 'diff', '--quiet', 'HEAD'], check=True)
    build = json.loads(args.candidate_build_receipt.read_text())
    assert build['commit'] == commit and build['rust_flags'] == '-C target-cpu=native'
    assert build['profile'] == {'lto': True, 'opt-level': 3, 'overflow-checks': False}
    assert build['binaries_sha256']['do_query'] == sha(args.candidate_binary)
    gate = json.loads(args.correctness_receipt.read_text())
    assert gate['passed'] and gate['commit'] == commit
    assert gate['root_reviewed_actual_source']
    frozen = json.loads((RULER / 'frozen-ruler.json').read_text())
    for path, expected in frozen['sources_sha256'].items():
        assert sha(Path(path)) == expected
    base_provenance = json.loads((BASE_BINARY.parent / 'provenance.json').read_text())
    assert sha(BASE_BINARY) == base_provenance['binaries_sha256']['do_query']
    identity = {str(p): sha(p) for p in (BASE_BINARY, args.candidate_binary, Path(__file__),
                RULER / 'frozen-ruler.json', args.candidate_build_receipt, args.correctness_receipt)}
    args.output.mkdir()
    (args.output / 'controller.py').write_bytes(Path(__file__).read_bytes())
    write(args.output / 'state.json', {'baseline_core': BASELINE, 'candidate_commit': commit,
          'candidate_worktree': str(args.candidate_worktree), 'identities': identity,
          'timing': 'Own CPU jobs idle; user background load remains active; frozen helper unchanged.',
          'absolute_times': 'Supplemental paired ruler only; not transferable to original Lucene ruler.'})
    summaries = {}
    # First bounded screening: target DEFAULT setup plus retained finite B1 gain.
    for profile in ('default', 'k09-b04'):
        for reverse in (False, True):
            name = profile + ('-candidate-first' if reverse else '-baseline-first')
            output = args.output / (name + '.json')
            command = ['python', str(RULER / 'suite_paired.py'), '--baseline-binary', str(BASE_BINARY),
                '--candidate-binary', str(args.candidate_binary), '--baseline-source-commit', BASELINE,
                '--candidate-source-commit', commit, '--index', frozen['index']['path'], '--profile', profile,
                '--command', 'TOP_10', '--cpu-core', '4', '--warmup-seconds', '40', '--iterations', '256',
                '--output', str(output)]
            if reverse:
                command.append('--candidate-first')
            write(args.output / (name + '.started.json'), {'command': command, 'cwd': str(REPO)})
            started = time.monotonic()
            with (args.output / (name + '.stdout')).open('x') as stdout, (args.output / (name + '.stderr')).open('x') as stderr:
                process = subprocess.Popen(command, cwd=REPO, stdout=stdout, stderr=stderr, start_new_session=True)
                try:
                    rc = process.wait(timeout=300)
                except BaseException:
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    process.wait(timeout=5)
                    raise
            write(args.output / (name + '.command.json'), {'command': command, 'returncode': rc,
                  'seconds': time.monotonic() - started})
            assert rc == 0
            result = json.loads(output.read_text())
            assert result['completed'] and result['provenance_before'] == result['provenance_after']
            assert result['provenance_before']['index'] == frozen['index']
            ratios = []
            assert len(result['queries']) == 20
            for query in result['queries']:
                for label in ('baseline', 'candidate'):
                    samples = result['samples_us'][label][query]
                    assert len(samples) == 256 and all(x > 0 and math.isfinite(x) for x in samples)
                    assert statistics.median(samples) == result['medians_us'][label][query]
                ratios.append(result['medians_us']['candidate'][query] / result['medians_us']['baseline'][query])
            ratio = math.exp(sum(map(math.log, ratios)) / 20)
            assert ratio == result['geomean_candidate_baseline_ratio']
            summaries[name] = {'candidate_baseline_ratio': ratio, 'lower_queries': sum(x < 1 for x in ratios),
                               'raw_result_sha256': sha(output)}
            print('DONE', name, ratio, flush=True)
    assert {p: sha(Path(p)) for p in identity} == identity
    assert subprocess.check_output(['git', '-C', str(args.candidate_worktree), 'rev-parse', 'HEAD'], text=True).strip() == commit
    subprocess.run(['git', '-C', str(args.candidate_worktree), 'diff', '--quiet', 'HEAD'], check=True)
    write(args.output / 'summary.json', {'completed': True, 'screening_only': True, 'runs': summaries,
          'identities_unchanged': True, 'profiles': ['DEFAULT TOP_10', '0.9/0.4 TOP_10'],
          'scope': 'Not a complete acceptance gate or fresh Lucene comparison; counts/other profiles require later checks.'})

if __name__ == '__main__':
    main()
