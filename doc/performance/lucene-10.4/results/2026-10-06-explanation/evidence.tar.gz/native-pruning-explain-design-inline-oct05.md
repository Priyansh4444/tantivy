# B: inline typed lazy IDF metadata

Design only; source, builds, tests, and timings untouched. Baseline is the brief's pushed fork `41b10df91`, core `b50e2aef3`. Throughput checkpoint: n/a, read-only investigation.

Workflow investigation todos:
1. Trace the relevant source, configuration, and runtime path. For motivation questions, inspect the change history and rationale. — completed for the specified BM25, explanation, term, and phrase paths; history beyond the supplied brief is outside this isolated design.
2. Throughput checkpoint stays one line: `throughput checkpoint: n/a, read-only investigation`. — above.
3. Produce an evidence-backed explanation (Overview / Key Concepts / How It Works / Where Things Live / Gotchas), or a recommendation with a tradeoffs table if the request is a decision between alternatives. — this package.
4. Apply a plain-writing pass to the reply. — completed.

## Caller-first contract

Keep every existing caller and public signature. `TermWeight::specialized_scorer` still calls `boost_by(boost)` after opening postings and fieldnorms (`term_weight.rs:203`). Phrase scorer construction still maps the optional weight through the same boost method before loading postings (`phrase_weight.rs:69`). Their ordinary scoring and pruning continue to use the existing weight/cache/scoring fields without reading metadata. `TermScorer::explain` and phrase explanation still obtain an owned `Explanation` through the existing BM25 explanation methods.

`boost_by(1.0)` retains the current exact early return through `Clone`. Other boosts multiply only the existing weight, in the existing expression; the original unboosted IDF value and metadata survive all clones and boosts. Do not recover IDF by dividing weight, multiply metadata by boost, or add a boost node. Return trees remain independently mutable.

## Types and signatures

All new types are private to `src/query/bm25.rs`:

```rust
#[derive(Clone, Copy)]
struct IdfTermStatistics {
    value: Score,     // original rounded IDF, computed exactly once
    doc_freq: Score,  // original u64 -> f32 cast
    doc_count: Score, // original u64 -> f32 cast
}

#[derive(Clone)]
enum IdfExplanation {
    None,
    Single(IdfTermStatistics),
    NativeSum {
        value: Score, // original native f64 sum rounded once to f32
        terms: Arc<[IdfTermStatistics]>,
    },
    ClassicScalar(Score),
    Explicit(Arc<Explanation>),
}

impl IdfExplanation {
    fn materialize(&self, scoring: Bm25Scoring) -> Option<Explanation>;
}

fn single_idf_explanation(
    statistics: IdfTermStatistics,
    scoring: Bm25Scoring,
) -> Explanation;

// Existing build; only its private metadata argument changes type.
fn build(
    idf: Score,
    idf_explain: IdfExplanation,
    average_fieldnorm: Score,
    scoring: Bm25Scoring,
    parameters: Bm25Parameters,
) -> Self;
```

Replace only `Bm25Weight.idf_explain: Option<Explanation>` with `IdfExplanation`. Keep the separate explicit `idf` build argument: `None` intentionally lacks a scalar, and no-explain score construction must retain it. `build` must retain its existing weight calculation and TF cache construction verbatim. No generic representation trait, public constructor, score-path indirection, query-flow change, or cache-sharing change is needed.

The existing `Bm25Scoring` is the single policy discriminator. `Single` shares one record and renderer; the policy chooses only the `N` description: native `N, number of docs with this field`, classic `N, total number of docs`. `NativeSum` can arise only in the native branch; each child is rendered with `NativeLucene`. `ClassicScalar` reproduces the historical multi-term leaf `idf`. Thus no per-record native flag or pair of nearly identical single variants is necessary. Keep `doc_count` in every native term record despite its repeated value: three f32s remain compact and this preserves every original per-term cast in exactly its old position. Hoisting the cast or shrinking the record to two scalars is unnecessary for this hypothesis.

## Construction and owned reconstruction

Preserve field validation and `statistics.field_statistics(field)?` placement. Preserve its default provider behavior (`total_num_tokens`, then `total_num_docs`) and each sequential `doc_freq(term)?` call, including duplicates and failure short-circuiting.

* Native single: call `doc_freq` once, call `native_idf` once, cast `n` then `N` to f32 as the current `native_idf_explanation` does, create inline `Single`, and pass the cached IDF to the unchanged native build path. Do not allocate an explanation or Arc for this case.
* Native multi-term: retain `sum = 0.0f64` and the source term order. Each iteration calls `doc_freq`, computes `native_idf` once, performs the same two f32 casts, then adds `f64::from(record.value)` to the sum and pushes the record. Cast the final sum to `Score` exactly once. Freeze the records using `Arc::from(records)` only after all calls succeed. Duplicates remain distinct ordered children. This replaces the old temporary vector of owned trees with a vector of three-f32 records, then a shared slice.
* Classic single / public `for_one_term`: keep `idf` once and the same `n`/`N` casts, store `Single`, and build with that exact value. Classic multi-term retains the original `Score` accumulator and `idf_sum += idf(...)` loop; it stores only `ClassicScalar(idf_sum)`.
* `new`, `new_with_parameters`, `new_native`, and `new_native_with_parameters` accept arbitrary owned explanations exactly as today. Extract `.value()` before moving into `Arc::new`, and store `Explicit`. Those paths preserve descriptions, owned strings, child order, contexts, missing versus present optional vectors, and arbitrary tree depth. Native production construction switches to metadata without passing through these explicit-tree helpers.
* `new_without_explain`, `for_one_term_without_explain`, and `for_native_block_bounds` store `None`. No placeholder IDF appears in their trees.

`materialize` is called only where `explain_with_frequency` currently clones the optional IDF. `None` returns `None`; `Single` creates the exact existing IDF description and the exact two constants in `n`, `N` order using cached values; `NativeSum` creates `idf, sum of:` with its cached value and materializes the ordered single children; `ClassicScalar` creates `idf`; `Explicit` deep-clones the underlying explanation at this boundary. There is no provider access, IDF math, summation, cast, or score arithmetic in materialization. Leave all root, `(K1+1)`, TF, frequency, and phrase/context production unchanged, including existing evaluation order. Repeated explanations reconstruct independent trees; immutable sharing cannot expose internal state.

## Module map and minimum diff

Production changes are confined to `bm25.rs`: private record/enum/renderer, metadata field, constructors, boost copying, and the IDF attachment in explain. Remove the now-unused eager `native_idf_explanation`; do not keep two renderers for the same standardized tree. `explanation.rs` stays unchanged: its public owned format is still the materialized boundary. Term, phrase, scorer, writer, bounds, index, and cache modules stay unchanged. Add focused BM25 tests to the existing private test module or one sibling test file; existing native integration tests remain regression gates.

This follows workflow's core-data-shape/minimum-layer rule: encode the five actual ownership cases directly, keep arithmetic policy in its existing field, and place reconstruction at the existing owned-tree boundary. Its `type-system-discipline` principle changes the choice from optional scalar/stats/tree fields to one exhaustive enum; `materialize` must match all variants without a catch-all so a later representation cannot silently omit an IDF node.

## Expected effects, not measurements

The baseline `Explanation` stores a Cow description and two optional Vecs (`explanation.rs:18`); standardized descriptions are borrowed literals, so the primary avoidable cost is child vectors and recursively cloned records, rather than allocated strings. Arbitrary explicit trees may also clone owned strings/context vectors today.

| Case | Construction change | Clone / boost change |
| --- | --- | --- |
| Single | Removes two-child explanation Vec; inline three-f32 record | Copies inline record, no metadata allocation or atomic refcount |
| Native phrase | Replaces per-term child vectors, temporary full-tree vector, and root detail vector with compact records plus immutable Arc slice | One Arc increment regardless of phrase length |
| Classic phrase | Replaces inline leaf Explanation with scalar variant; the old leaf itself had no heap allocation | Scalar copy |
| Explicit | Adds one Arc allocation to retain arbitrary tree | One Arc increment; full deep copy delayed until explain |
| None | No metadata heap allocation | Trivial variant copy |

Vec-to-Arc slice freezing can allocate again and copy records; do not claim a single total phrase allocation. The independent TF-cache Arc allocation remains exactly as before. Explanation requests still allocate the same owned tree shape; their allocation cost is intentionally moved to that boundary.

On a typical 64-bit Rust target, the largest payload is native sum (`f32` plus a fat Arc slice pointer); enum size is expected around 32 bytes, versus roughly 80 bytes for `Option<Explanation>`. This suggests `Bm25Weight` near 64 rather than the supplied baseline 112 bytes, and a corresponding reduction in the embedded `TermScorer` field. Rust layout is not guaranteed: these are estimates, not observations. Measure actual weight, enum, record, and scorer sizes/alignment in the selected isolated implementation. Hot methods never match this enum; a smaller embedded field may improve copying/locality, but the large decoder buffers remain dominant and no performance cause or win is established.

## Frozen gates before accepting an implementation

1. Freeze outputs from untouched baseline before editing: full term and phrase explanation trees, each node's f32 bits, optional-field presence, description, contexts, and ordered children. Cover native/classic single, native phrase with unequal IDFs and duplicates, classic multi-term, DEFAULT and k09/nondefault parameters, fractional phrase frequency, all no-explain paths, and explicit custom trees with owned descriptions/nested children/context. Use a test-only recursive snapshot inside `explanation.rs` if needed to retain nonfinite/signed-zero value bits; JSON alone can hide nonfinite values. Compare candidate directly to baseline fixtures, never to a second weight built through candidate code. Expected values must not be regenerated after the mutation.
2. Exact scalar fixture gates: score, max score, average, weight, every cache entry, and safe-bound/profile decisions retain bits or exact predicates. Include stats around `2^24`, near `u64::MAX`, zero populations/averages, unequal native IDFs that distinguish f64 accumulation from f32 accumulation, boosts `1`, `0`, `-0`, positive nonunit, and negative. Confirm original IDF tree values survive repeated boosts while root scores follow the existing arithmetic. Keep existing native raw-score/pruning gates passing.
3. Provider spy gates freeze ordered call traces, including the default field snapshot's token/docs order, one overridden field-statistics call, duplicate term calls, and failures at field statistics and a middle term. Assert explaining, cloning, and boosting add zero calls. Native field-statistics test construction may use private access; no new public API is required.
4. Ownership/cold evidence: single/classic-scalar/None clones are allocation-free; native-sum and explicit clones share their Arc pointer; separately returned explanations remain independently mutable. Use a narrowly scoped allocation counter or existing allocator harness to compare baseline/candidate construction and repeated boosts, isolating the unchanged TF-cache allocation. Record both allocations and bytes, including Arc freezing. Measure actual layouts without enforcing speculative sizes as correctness requirements.
5. Only after semantic and ownership gates pass, run the frozen native paired ruler for DEFAULT, small setup-sensitive cases, and k09 with identical profiles, counts, raw scores, and explanations. Preserve the larger all-query/all47 work as open; this proposal cannot close it. No timing or improvement claims belong to this design stage.

## 5 × 5 rubric (design assessment)

| Criterion | /5 | Basis |
| --- | ---: | --- |
| Exact contracts | 5 | Original scalar values/casts/sums/order retained; explicit owned trees preserved; no-explain remains absent |
| Cold clone/construction saving | 5 | Single construction and clone become inline; phrase trees deferred; arbitrary clones share |
| Hot layout / surface | 4 | Expected smaller embedded weight and unchanged hot functions; layout still unmeasured |
| Minimality | 3 | Five variants and materializer are more source work than an eager Arc, but stay in one module with shared single policy |
| Verifiable scope | 5 | Baseline tree bits, provider traces, score/profile gates, and ownership/allocation checks directly separate semantics from performance |

Assessment: 22/25. Select this shape when removing ordinary single-term construction allocations matters as well as clone cost. Its cost is added private constructor/rendering logic and a cold Arc allocation for arbitrary explicit input. Exact frozen gates and a narrow source diff are prerequisites; the expected layout and speed effects remain hypotheses.
