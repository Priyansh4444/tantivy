"""Durable root controller: serial timings of immutable uninstrumented artifacts."""
from pathlib import Path
import argparse, hashlib, json, math, statistics, subprocess, time

BASE=Path('/home/pronsh/Coding/playground/search')
BENCH=BASE/'bench'
REPO=BASE/'tantivy-pr2937'
CANDIDATE='b50e2aef3abd77a43fbad56dbaecf2f6c0540a50'
BASELINE='e13303b3aaa8c15815ab5ea951a3449111438e81'
ARTIFACTS=BENCH/'native-perf-adapter-oct03/artifacts'
HELPER=BENCH/'native-pruning-paired-harness-oct05'
OUT=BENCH/'native-pruning-finite-measurements-resume-oct05'
INDEX=BENCH/'wiki-1m-native-aligned-v11-oct05.idx'
ALIGNED=BENCH/'native-profile-aligned-oct05'

def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()

def write(path,value):
    with path.open('x') as f:
        f.write(json.dumps(value,indent=2,allow_nan=False)+'\n')

def verify_inputs():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==CANDIDATE
    subprocess.run(['git','diff','--quiet','HEAD'],cwd=REPO,check=True)
    gate=json.loads((BENCH/'native-pruning-finite-root-release-oct05/summary.json').read_text())
    assert gate['passed'] and gate['commit']==CANDIDATE
    counters=json.loads((BENCH/'native-pruning-finite-counters-oct05/summary.json').read_text())
    assert counters['completed'] and counters['untimed'] and counters['guards_equal'] and counters['candidate_commit']==CANDIDATE
    assert counters['binary_identity']['sha256']!=sha(ARTIFACTS/CANDIDATE/'do_query')
    frozen=json.loads((HELPER/'frozen-ruler.json').read_text())
    assert frozen['frozen']
    for path,digest in frozen['sources_sha256'].items():
        assert sha(path)==digest,path
    aligned=json.loads((ALIGNED/'frozen-ruler.json').read_text())
    for path,row in aligned['artifacts'].items():
        if '/native-classes/' in path:
            assert Path(path).stat().st_size==row['bytes'] and sha(path)==row['sha256'],path
    for commit in [CANDIDATE,BASELINE]:
        folder=ARTIFACTS/commit
        provenance=json.loads((folder/'provenance.json').read_text())
        assert provenance['commit']==commit and provenance['index_format']==11
        assert provenance['rust_flags']=='-C target-cpu=native'
        assert provenance['profile']=={'lto':True,'opt-level':3,'overflow-checks':False}
        for name,digest in provenance['binaries_sha256'].items():
            assert sha(folder/name)==digest,name
    return frozen

def run(name,argv):
    verify_inputs()
    started=time.monotonic()
    command=list(map(str,argv))
    write(OUT/(name+'.started.json'),{'command':command,'cwd':str(REPO),'candidate_commit':CANDIDATE,'baseline_commit':BASELINE})
    with (OUT/(name+'.stdout')).open('xb') as stdout, (OUT/(name+'.stderr')).open('xb') as stderr:
        result=subprocess.run(command,cwd=REPO,stdout=stdout,stderr=stderr)
    write(OUT/(name+'.command.json'),{'command':command,'cwd':str(REPO),'exit_code':result.returncode,'seconds':time.monotonic()-started,'candidate_commit':CANDIDATE,'baseline_commit':BASELINE})
    assert result.returncode==0,name
    row=json.loads((OUT/(name+'.json')).read_text())
    print('DONE '+name+' ratio='+str(row.get('geomean_candidate_baseline_ratio',row.get('geomean_ratio','memory'))),flush=True)
    return row

def calculate(row,labels,ratio_key):
    ratios=[]
    assert len(row['queries'])==20
    for query in row['queries']:
        for label in labels:
            samples=row['samples_us'][label][query]
            assert len(samples)==256 and all(value>0 and math.isfinite(value) for value in samples)
            assert statistics.median(samples)==row['medians_us'][label][query]
        ratios.append(row['medians_us'][labels[1]][query]/row['medians_us'][labels[0]][query])
    overall=math.exp(sum(map(math.log,ratios))/20)
    assert overall==row[ratio_key]
    return overall,sum(ratio<1 for ratio in ratios)

def paired():
    frozen=verify_inputs()
    OUT.mkdir()
    write(OUT/'frozen-paired-inputs.json',frozen)
    (OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
    write(OUT/'state.json',{'candidate_commit':CANDIDATE,'baseline_commit':BASELINE,'candidate_do_query_sha256':sha(ARTIFACTS/CANDIDATE/'do_query'),'controller_sha256':sha(Path(__file__)),'paired_ruler_sha256':sha(HELPER/'frozen-ruler.json'),'index':str(INDEX),'timing_source':'immutable uninstrumented native artifacts; user background load retained; owned CPU jobs idle','absolute_times':'supplemental paired ruler; do not transfer absolutes to original Tantivy/Lucene ruler'})
    summary={}
    for profile,mode in [('k09-b04','TOP_10'),('default','TOP_10'),('default','COUNT'),('k09-b04','COUNT'),('k25-b1','TOP_10'),('k25-b1','COUNT')]:
        for reverse in [False,True]:
            name='paired-'+profile+'-'+mode.lower()+('-candidate-first' if reverse else '-baseline-first')
            argv=['python',HELPER/'suite_paired.py','--baseline-binary',ARTIFACTS/BASELINE/'do_query','--candidate-binary',ARTIFACTS/CANDIDATE/'do_query','--baseline-source-commit',BASELINE,'--candidate-source-commit',CANDIDATE,'--index',INDEX,'--profile',profile,'--command',mode,'--cpu-core','4','--warmup-seconds','40','--iterations','256','--output',OUT/(name+'.json')]
            if reverse:
                argv.append('--candidate-first')
            row=run(name,argv)
            assert row['completed'] and row['provenance_before']==row['provenance_after']
            assert row['provenance_before']['index']==frozen['index']
            overall,wins=calculate(row,['baseline','candidate'],'geomean_candidate_baseline_ratio')
            summary[name]={'candidate_baseline_geomean':overall,'candidate_lower_median_queries':wins,'result_sha256':sha(OUT/(name+'.json'))}
    write(OUT/'paired-summary.json',summary)

def lucene():
    verify_inputs()
    assert (OUT/'paired-summary.json').exists()
    aligned=json.loads((ALIGNED/'frozen-ruler.json').read_text())
    for path,row in aligned['artifacts'].items():
        assert Path(path).stat().st_size==row['bytes'] and sha(path)==row['sha256'],path
    write(OUT/'lucene-frozen-inputs.json',aligned)
    summary={}
    for profile in ['default','k09-b04','k25-b1']:
        for mode in ['COUNT','TOP_10']:
            for reverse in [False,True]:
                suffix=mode.lower()+('-lucene-first' if reverse else '-tantivy-first')
                name='lucene-'+profile+'-'+suffix
                argv=json.loads((ALIGNED/(profile+'-'+suffix+'.command.json')).read_text())['command'][:]
                argv[argv.index('--tantivy-binary')+1]=str(ARTIFACTS/CANDIDATE/'do_query')
                argv[argv.index('--output')+1]=str(OUT/(name+'.json'))
                row=run(name,argv)
                overall,wins=calculate(row,['lucene','tantivy'],'geomean_ratio')
                summary[name]={'tantivy_lucene_geomean':overall,'tantivy_lower_median_queries':wins,'result_sha256':sha(OUT/(name+'.json'))}
        name='lucene-'+profile+'-memory'
        argv=json.loads((ALIGNED/(profile+'-memory.command.json')).read_text())['command'][:]
        argv[argv.index('--tantivy-binary')+1]=str(ARTIFACTS/CANDIDATE/'do_query')
        argv[argv.index('--output')+1]=str(OUT/(name+'.json'))
        run(name,argv)
        summary[name]={'result_sha256':sha(OUT/(name+'.json'))}
    guard=json.loads((BENCH/'native-pruning-finite-root-release-oct05/index-guard-before.json').read_text())
    for path,row in guard.items():
        assert Path(path).stat().st_size==row['bytes'] and sha(path)==row['sha256'],path
    retained=json.loads((BENCH/'native-profile-measurements-oct05/retained-artifacts-before-docorder.json').read_text())
    for path,row in retained.items():
        assert Path(path).stat().st_size==row['bytes'] and sha(path)==row['sha256'],path
    write(OUT/'inputs-after.json',{'indices_unchanged':True,'retained_artifact_files_unchanged':len(retained),'candidate_commit':CANDIDATE})
    write(OUT/'lucene-summary.json',summary)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('stage',choices=['paired','lucene'])
    stage=parser.parse_args().stage
    receipt=BENCH/('native-pruning-finite-'+stage+'-detached-result-oct05.json')
    assert not receipt.exists()
    started=time.monotonic()
    try:
        {'paired':paired,'lucene':lucene}[stage]()
    except BaseException as error:
        write(receipt,{'stage':stage,'completed':False,'error_type':type(error).__name__,'error':str(error),'seconds':time.monotonic()-started})
        raise
    write(receipt,{'stage':stage,'completed':True,'seconds':time.monotonic()-started,'runner_sha256':sha(Path(__file__))})
