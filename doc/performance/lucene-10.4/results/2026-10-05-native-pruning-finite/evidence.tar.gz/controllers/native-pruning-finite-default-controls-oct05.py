from pathlib import Path
import hashlib,json,math,statistics,subprocess,time
BASE=Path('/home/pronsh/Coding/playground/search');BENCH=BASE/'bench';REPO=BASE/'tantivy-pr2937';ALIGNED=BENCH/'native-profile-aligned-oct05'
OUT=BENCH/'native-pruning-finite-default-controls-oct05';ART=BENCH/'native-perf-adapter-oct03/artifacts'
COMMITS={'accepted':'e13303b3aaa8c15815ab5ea951a3449111438e81','candidate':'b50e2aef3abd77a43fbad56dbaecf2f6c0540a50'}
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(name,row):
 with (OUT/name).open('x') as f:f.write(json.dumps(row,indent=2)+'\n')
def guard():
 frozen=json.loads((ALIGNED/'frozen-ruler.json').read_text())
 for p,d in frozen['artifacts'].items():assert Path(p).stat().st_size==d['bytes'] and sha(p)==d['sha256'],p
 for commit in COMMITS.values():
  p=ART/commit;m=json.loads((p/'provenance.json').read_text());assert m['commit']==commit
  assert sha(p/'do_query')==m['binaries_sha256']['do_query']
 return frozen
OUT.mkdir();(OUT/'controller.py').write_bytes(Path(__file__).read_bytes());before=guard();write('before.json',before)
summary={}
for label in ['accepted','candidate']:
 for reverse in [False,True]:
  suffix='top_10-'+('lucene-first' if reverse else 'tantivy-first');name=label+'-'+suffix
  argv=json.loads((ALIGNED/('default-'+suffix+'.command.json')).read_text())['command'][:]
  argv[argv.index('--tantivy-binary')+1]=str(ART/COMMITS[label]/'do_query');argv[argv.index('--output')+1]=str(OUT/(name+'.json'))
  write(name+'.started.json',{'command':argv,'source_commit':COMMITS[label]});start=time.monotonic()
  with (OUT/(name+'.stdout')).open('xb') as so,(OUT/(name+'.stderr')).open('xb') as se:r=subprocess.run(argv,cwd=REPO,stdout=so,stderr=se)
  write(name+'.command.json',{'command':argv,'exit_code':r.returncode,'seconds':time.monotonic()-start});assert r.returncode==0
  d=json.loads((OUT/(name+'.json')).read_text());ratios=[]
  for q in d['queries']:
   for engine in ['tantivy','lucene']:
    values=d['samples_us'][engine][q];assert len(values)==256 and all(v>0 and math.isfinite(v) for v in values)
    assert statistics.median(values)==d['medians_us'][engine][q]
   ratios.append(d['medians_us']['tantivy'][q]/d['medians_us']['lucene'][q])
  gm=math.exp(sum(map(math.log,ratios))/20);assert gm==d['geomean_ratio']
  summary[name]={'source_commit':COMMITS[label],'geomean_ratio':gm,'tantivy_lower_median_queries':sum(x<1 for x in ratios),'losses':{q:x for q,x in zip(d['queries'],ratios) if x>=1},'result_sha256':sha(OUT/(name+'.json'))}
  print(name,json.dumps(summary[name]),flush=True)
after=guard();assert after==before;write('after.json',after);write('summary.json',summary);print('COMPLETED',flush=True)
