#!/usr/bin/env python3
"""Build isolated native binaries, preserving immutable revision artifacts."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
FORK = ROOT.parent.parent / "tantivy-pr2937"
TOOLS = FORK / "doc/performance/lucene-10.4"
BINS = ("do_query", "validate_index", "reencode_index", "payload_identity", "payload_fixtures",
        "build_index", "dump_termtotals", "dump_docmap")
SUPPORT = ("shared/bm25_profile.rs", "shared/wiki_physical.rs")
FLAGS = "-C target-cpu=native"


def command(*args):
    return subprocess.check_output(args, text=True, cwd=ROOT).strip()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", action="store_true", help="inspect settings without building")
    parser.add_argument("--expect-commit", help="required full or abbreviated integrated revision")
    parser.add_argument("--expect-format", type=int)
    parser.add_argument("--jobs", type=int, default=4)
    args = parser.parse_args()
    revision = command("git", "-C", str(FORK), "rev-parse", "HEAD")
    version = int(re.search(r"INDEX_FORMAT_VERSION: u32 = (\d+)", (FORK/"src/lib.rs").read_text()).group(1))
    argv = ["cargo", "build", "--manifest-path", str(ROOT/"Cargo.toml"),
            "--target-dir", str(ROOT/"target"), "--release", "--jobs", str(args.jobs)]
    for binary in BINS:
        argv += ["--bin", binary]
    artifact = ROOT / "artifacts" / revision
    if args.plan:
        print(json.dumps({"fork":str(FORK), "commit":revision, "index_format":version,
                          "rust_flags":FLAGS, "profile":{"lto":True,"opt-level":3,"overflow-checks":False},
                          "command":argv, "artifact_directory":str(artifact)}, indent=2))
        return
    if not args.expect_commit or not revision.startswith(args.expect_commit):
        parser.error("--expect-commit must identify the current integrated fork HEAD")
    if args.expect_format is not None and args.expect_format != version:
        parser.error("index format differs from --expect-format")
    if args.jobs < 1:
        parser.error("--jobs must be positive")
    if artifact.exists():
        parser.error("revision artifact directory already exists; retained binaries are immutable")
    subprocess.run(["git", "-C", str(FORK), "diff", "--quiet", "HEAD"], check=True)
    sources = {}
    for binary in BINS:
        source = TOOLS / (binary + ".rs")
        shutil.copy2(source, ROOT/"src/bin"/source.name)
        sources[source.name] = digest(source)
    for name in SUPPORT:
        source = TOOLS/name
        destination = ROOT/"src/bin"/name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        sources[name] = digest(source)
    local_sources = {name:digest(ROOT/"src/bin"/name) for name in sources}
    manifest_hash = digest(ROOT/"Cargo.toml")
    environment = os.environ.copy()
    environment["RUSTFLAGS"] = FLAGS
    subprocess.run(argv, env=environment, check=True, cwd=ROOT)
    if command("git", "-C", str(FORK), "rev-parse", "HEAD") != revision:
        raise RuntimeError("fork revision changed during build; binaries were not published")
    subprocess.run(["git", "-C", str(FORK), "diff", "--quiet", "HEAD"], check=True)
    if any(digest(TOOLS/name) != hash_value for name,hash_value in sources.items()):
        raise RuntimeError("adapter sources changed during build")
    if any(digest(ROOT/"src/bin"/name) != value for name,value in local_sources.items()) or digest(ROOT/"Cargo.toml") != manifest_hash:
        raise RuntimeError("local adapter sources or manifest changed during build")
    artifact.mkdir(parents=True)
    binaries = {}
    for binary in BINS:
        path = artifact/binary
        shutil.copy2(ROOT/"target/release"/binary, path)
        binaries[binary] = digest(path)
    retained = {}
    for name in ("do_query-final-unroll4-native-oct03", "do_query-final-combined-native-oct03",
                 "validate_index-final-unroll4-native-oct03", "reencode_index-frequency-pfor-v9-native-oct03"):
        path = ROOT.parent/name
        if path.exists():
            retained[str(path)] = digest(path)
    provenance = {"commit":revision, "index_format":version, "rust_flags":FLAGS,
                  "profile":{"lto":True,"opt-level":3,"overflow-checks":False},
                  "command":argv, "rustc":command("rustc", "-vV"),
                  "cargo":command("cargo", "-V"), "manifest_sha256":digest(ROOT/"Cargo.toml"),
                  "cargo_lock_sha256":digest(ROOT/"Cargo.lock"),
                  "sources_sha256":local_sources, "binaries_sha256":binaries,
                  "retained_baselines_sha256":retained,
                  "built_at_utc":datetime.now(timezone.utc).isoformat()}
    (artifact/"provenance.json").write_text(json.dumps(provenance,indent=2)+"\n")
    print(json.dumps({"artifact_directory":str(artifact),"binaries_sha256":binaries},indent=2))


if __name__ == "__main__":
    main()
