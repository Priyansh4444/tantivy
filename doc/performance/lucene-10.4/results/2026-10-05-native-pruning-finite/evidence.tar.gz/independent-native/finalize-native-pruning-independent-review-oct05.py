from pathlib import Path
import json, hashlib, re, os, shutil

base = Path('/home/pronsh/Coding/playground/search/bench')
out = base/'native-pruning-finite-independent-compiled-oct05'
target = base/'native-pruning-finite-independent-target-oct05'
summary_path = out/'summary.json'
summary = json.loads(summary_path.read_text())
assert summary['status'] == 'passed'
stdout = (out/'compiled-independent-release.stdout').read_text()
stderr = (out/'compiled-independent-release.stderr').read_text()
assert '3 passed; 0 failed;' in stdout
assert '245760 actual score comparisons; 16 b1 rejections' in stderr
match = re.search(r'Running unittests src/lib.rs \(([^\n]+)\)',stderr)
assert match
binary = Path(match[1])
assert binary.is_relative_to(target) and binary.is_file() and os.access(binary,os.X_OK)
summary['test_binaries'] = [{'path':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'bytes':binary.stat().st_size}]
summary['test_binary_discovery'] = 'Exact owned executable path printed by Cargo Running unittests; Cargo layout is release/build/tantivy/hash/out, not old release/deps. Initial empty deps glob receipt was corrected without rebuilding or rerunning tests.'
summary['integrated_candidate_commit'] = 'b50e2aef3abd77a43fbad56dbaecf2f6c0540a50'
summary['all_three_release_probe_tests_passed'] = True
summary['source_equality_receipt'] = 'final-source-review-identities.json'
summary_path.write_text(json.dumps(summary,indent=2)+'\n')
for name in ['run-native-pruning-independent-compiled-probe-oct05.py','verify-native-pruning-final-review-identities-oct05.py','native-pruning-independent-exact-audit-oct05.py','finalize-native-pruning-independent-review-oct05.py']:
    shutil.copyfile(Path('/tmp')/name,out/name)
files = {str(p.relative_to(out)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file() and p.name != 'manifest.json'}
(out/'manifest.json').write_text(json.dumps({'files':files,'complete':True,'candidate_source_commit':summary['candidate_commit'],'root_integrated_source_commit':summary['integrated_candidate_commit'],'production_artifact_changed':False},indent=2)+'\n')
print(json.dumps({'compiled_test_binary':summary['test_binaries'],'manifest_entries':len(files),'summary_sha256':hashlib.sha256(summary_path.read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest()},indent=2))
