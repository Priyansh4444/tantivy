"""Freeze one final candidate commit, attach independent private tests externally."""
from pathlib import Path
import subprocess, sys, os, json, hashlib, datetime, re, tomllib

base = Path('/home/pronsh/Coding/playground/search')
main = base / 'tantivy-pr2937'
worktree = base / 'tantivy-pruning-finite-independent-probe-oct05'
out = base / 'bench/native-pruning-finite-independent-compiled-oct05'
target = base / 'bench/native-pruning-finite-independent-target-oct05'
probe = base / 'bench/native-pruning-finite-independent-probe-oct05.rs'
vectors = base / 'bench/native-pruning-finite-exact-oracle-oct05/vectors.json'
assert len(sys.argv) == 2 and re.fullmatch('[0-9a-f]{40}', sys.argv[1])
commit = sys.argv[1]
assert not out.exists() and not worktree.exists(), 'refuse artifact/worktree overwrite'
out.mkdir()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def command(name, args, cwd, env=None):
    (out/(name+'.command.json')).write_text(json.dumps({'args':args,'cwd':str(cwd),'env_overrides':env or {}},indent=2)+'\n')
    with (out/(name+'.stdout')).open('w') as stdout, (out/(name+'.stderr')).open('w') as stderr:
        process = subprocess.run(args,cwd=cwd,env={**os.environ,**(env or {})},stdout=stdout,stderr=stderr)
    (out/(name+'.result.json')).write_text(json.dumps({'exit_code':process.returncode},indent=2)+'\n')
    if process.returncode:
        raise RuntimeError(f'{name}: exit {process.returncode}')
    return (out/(name+'.stdout')).read_text().strip()

candidate = command('candidate-commit',['git','rev-parse',commit],main)
assert candidate == commit
command('create-detached-worktree',['git','worktree','add','--detach',str(worktree),commit],main)
assert command('initial-state',['git','status','--porcelain'],worktree) == ''
command('candidate-stat',['git','show','--stat','--oneline',commit],worktree)
command('candidate-diff',['git','show','--format=fuller',commit],worktree)
command('rustc-version',['rustc','-vV'],worktree)
command('cargo-version',['cargo','-V'],worktree)
frozen_probe = out / 'private-probe.rs'
frozen_probe.write_bytes(probe.read_bytes())
original_probe_sha = sha(probe)
vector_sha = sha(vectors)
bm25 = worktree/'src/query/bm25.rs'
before_bm25_sha = sha(bm25)
with bm25.open('a') as stream:
    stream.write('\n#[cfg(test)]\n#[path = "'+str(frozen_probe)+'"]\nmod independent_finite_probe;\n')
command('probe-only-diff',['git','diff','--','src/query/bm25.rs'],worktree)
environment = {'CARGO_TARGET_DIR':str(target),'CARGO_BUILD_JOBS':'4','RUSTFLAGS':'-C target-cpu=native','CARGO_PROFILE_RELEASE_LTO':'true','CARGO_PROFILE_RELEASE_OPT_LEVEL':'3','CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS':'false'}
command('compiled-independent-release',['cargo','test','--release','--lib','query::bm25::independent_finite_probe::','--','--nocapture'],worktree,environment)
assert sha(vectors) == vector_sha and sha(probe) == original_probe_sha
test_binaries = sorted((target/'release').rglob('tantivy-*'))
test_binaries = [p for p in test_binaries if p.is_file() and os.access(p,os.X_OK)]
assert len(test_binaries) == 1, 'require exactly one owned compiled test executable'
summary = {'status':'passed','candidate_commit':commit,'candidate_core_tree':command('candidate-tree',['git','rev-parse',commit+'^{tree}'],worktree),'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'native_release_flags':environment,'manifest_release_policy':tomllib.loads((worktree/'Cargo.toml').read_text())['profile']['release'],'candidate_manifest_sha256':sha(worktree/'Cargo.toml'),'candidate_lock_sha256':sha(worktree/'Cargo.lock'),'candidate_bm25_before_probe_sha256':before_bm25_sha,'probe_modified_bm25_sha256':sha(bm25),'vectors_sha256':vector_sha,'external_probe_sha256':original_probe_sha,'compiled_private_probe_sha256':sha(frozen_probe),'score_coverage_comparisons':245760,'vector_blocks':384,'b1_rejection_configurations':16,'test_binaries':[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in test_binaries],'production_artifact_modified':False,'timings_run':False}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
