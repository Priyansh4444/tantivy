// Attach only as a child of query::bm25 in an isolated probe checkout.
// Never include this in an immutable native measurement artifact.
use super::{Bm25Scoring, Bm25Weight, NativeInputEnvelope};
use crate::index::field_statistics::BlockMaxSelection;
use crate::query::{Bm25Parameters, Explanation};
use std::num::NonZeroU32;
use std::sync::Arc;

fn float_bits(value: &serde_json::Value, key: &str) -> f32 {
    f32::from_bits(u32::from_str_radix(value[key].as_str().unwrap(), 16).unwrap())
}

fn native(weight: f32, average: f32, parameters: Bm25Parameters) -> Bm25Weight {
    Bm25Weight::new_native_with_parameters(Explanation::new("independent probe", weight), average, parameters)
}

#[test]
fn independent_finite_oracle_all_vector_bits_and_scores() {
    let data: serde_json::Value = serde_json::from_str(include_str!("/home/pronsh/Coding/playground/search/bench/native-pruning-finite-exact-oracle-oct05/vectors.json")).unwrap();
    let mut score_comparisons = 0;
    for (index, vector) in data["vectors"].as_array().unwrap().iter().enumerate() {
        let parameters = Bm25Parameters::new(float_bits(vector, "k1_bits"), float_bits(vector, "b_bits")).unwrap();
        let query = native(1.0, float_bits(vector, "query_average_bits"), parameters);
        let context = query.native_selection_context(float_bits(vector, "selection_average_bits"), BlockMaxSelection::NativeSaturationInput).unwrap();
        let envelope = query.native_input_envelope(context).unwrap();
        let norm = vector["selected_norm"].as_u64().unwrap() as u8;
        let tf = NonZeroU32::new(vector["selected_tf_ceiling"].as_u64().unwrap() as u32).unwrap();
        let maximum = tf.get() as f32 * envelope.selection_inverse[norm as usize];
        assert_eq!(maximum.to_bits(), float_bits(vector, "old_max_bits").to_bits(), "M vector{index}");
        assert_eq!(envelope.ratio_up.to_bits(), u64::from_str_radix(vector["ratio_up_bits"].as_str().unwrap(), 16).unwrap(), "R vector{index}");
        let input = envelope.input_upper(norm, tf).unwrap();
        assert_eq!(input.to_bits(), float_bits(vector, "input_upper_bits").to_bits(), "C vector{index}");
        for (weight_bits, bound_bits) in vector["weights_bits"].as_array().unwrap().iter().zip(vector["bound_bits"].as_array().unwrap()) {
            let weight = f32::from_bits(u32::from_str_radix(weight_bits.as_str().unwrap(), 16).unwrap());
            let weight = native(weight, float_bits(vector, "query_average_bits"), parameters);
            let expected = u32::from_str_radix(bound_bits.as_str().unwrap(), 16).unwrap();
            let bound = weight.score_from_native_input_upper(input);
            assert_eq!(bound.to_bits(), expected, "bound vector{index}");
            for doc in vector["docs"].as_array().unwrap() {
                let score = weight.score(doc["norm"].as_u64().unwrap() as u8, doc["tf"].as_u64().unwrap() as u32);
                assert!(score <= bound, "coverage vector{index}");
                score_comparisons += 1;
            }
        }
    }
    assert_eq!(score_comparisons, 245_760);
    for rejected in data["rejections"].as_array().unwrap() {
        let query = native(1.0, float_bits(rejected, "query_avg_bits"), Bm25Parameters::new(2.5, 1.0).unwrap());
        let context = query.native_selection_context(float_bits(rejected, "old_avg_bits"), BlockMaxSelection::NativeSaturationInput).unwrap();
        assert!(query.native_input_envelope(context).is_none());
    }
    eprintln!("INDEPENDENT_EXACT_PROBE 384 vector bits; 245760 actual score comparisons; 16 b1 rejections");
}

#[test]
fn independent_finite_predicate_and_arithmetic_boundaries() {
    let parameters = Bm25Parameters::new(0.9, 0.4).unwrap();
    let query = native(1.0, 3.0, parameters);
    let selection = BlockMaxSelection::NativeSaturationInput;
    assert!(query.native_selection_context(3.0, BlockMaxSelection::LegacyTfFactor).is_none());
    let classic = Bm25Weight::for_one_term(1, 2, 3.0);
    assert_eq!(classic.scoring, Bm25Scoring::LegacyClassic);
    assert!(classic.native_selection_context(3.0, selection).is_none());
    for average in [0.0, -0.0, -1.0, f32::INFINITY, f32::NEG_INFINITY, f32::NAN] {
        assert!(query.native_selection_context(average, selection).is_none());
        assert!(native(1.0, average, parameters).native_selection_context(3.0, selection).is_none());
    }
    for weight in [0.0, -0.0, -1.0, f32::INFINITY, f32::NEG_INFINITY, f32::NAN] {
        assert!(native(weight, 3.0, parameters).native_selection_context(3.0, selection).is_none());
    }
    for k1 in [0.0, -0.0] {
        assert!(native(1.0, 3.0, Bm25Parameters::new(k1, 0.4).unwrap()).native_selection_context(3.0, selection).is_none());
    }
    let default = native(1.0, 3.0, Bm25Parameters::DEFAULT);
    assert!(default.native_selection_context(3.0, selection).is_none());
    assert!(default.native_selection_context(4.0, selection).is_none());
    for selection_average in [f32::from_bits(1), f32::MIN_POSITIVE] {
        let context = query.native_selection_context(selection_average, selection).unwrap();
        assert!(query.native_input_envelope(context).is_none(), "old inverse zero from overflow");
    }
    let subnormal_query = native(1.0, 3.0, Bm25Parameters::new(f32::MAX, 0.0).unwrap());
    let context = subnormal_query.native_selection_context(1.0e-29, selection).unwrap();
    let envelope = subnormal_query.native_input_envelope(context).unwrap();
    assert!(envelope.selection_inverse.iter().any(|x| x.is_subnormal()));
    assert!(subnormal_query.cache.iter().all(|x| x.is_subnormal() && *x > 0.0));
    assert!(envelope.input_upper(255, NonZeroU32::new(1).unwrap()).is_some());

    // Synthetic private cache corruption exercises validation, not normal writer data.
    for invalid in [-0.0, -1.0, f32::INFINITY, f32::NEG_INFINITY, f32::NAN] {
        let mut synthetic = query.clone();
        Arc::make_mut(&mut synthetic.cache)[255] = invalid;
        let context = synthetic.native_selection_context(3.0, selection).unwrap();
        assert!(synthetic.native_input_envelope(context).is_none());
    }
    let mut zero_cache = query.clone();
    zero_cache.cache = Arc::new([0.0; 256]);
    let context = zero_cache.native_selection_context(3.0, selection).unwrap();
    let envelope = zero_cache.native_input_envelope(context).unwrap();
    assert_eq!(envelope.ratio_up.to_bits(), 0);
    assert_eq!(envelope.input_upper(0, NonZeroU32::new(1).unwrap()).unwrap().to_bits(), 0);
    // Synthetic envelopes exercise impossible-under-current-DEFAULT arithmetic guards.
    for old in [0.0, f32::MAX, f32::INFINITY] {
        let envelope = NativeInputEnvelope { selection_inverse: Arc::new([old; 256]), ratio_up: 1.0 };
        assert!(envelope.input_upper(0, NonZeroU32::new(1).unwrap()).is_none());
    }
    let overflow = NativeInputEnvelope { selection_inverse: Arc::new([1.0; 256]), ratio_up: f64::from(f32::MAX) };
    assert_eq!(overflow.input_upper(0, NonZeroU32::new(u32::MAX).unwrap()).unwrap(), f32::INFINITY);
    assert_eq!(query.score_from_native_input_upper(f32::INFINITY).to_bits(), query.max_score().to_bits());
}

#[test]
fn independent_selection_average_binding_counterexample() {
    let parameters = Bm25Parameters::new(0.9, 0.4).unwrap();
    let query = native(1.0, f32::from_bits(0x4f000000), parameters);
    let selection = BlockMaxSelection::NativeSaturationInput;
    let correct = query.native_input_envelope(query.native_selection_context(3.0, selection).unwrap()).unwrap();
    let wrong = query.native_input_envelope(query.native_selection_context(f32::from_bits(0x4f000000), selection).unwrap()).unwrap();
    let tf = NonZeroU32::new(1).unwrap();
    let correct_bound = query.score_from_native_input_upper(correct.input_upper(0, tf).unwrap());
    let wrong_bound = query.score_from_native_input_upper(wrong.input_upper(0, tf).unwrap());
    let actual = query.score(255, 100);
    assert_eq!(wrong_bound.to_bits(), 0x3f501a34);
    assert_eq!(actual.to_bits(), 0x3f7dc5ed);
    assert!(wrong_bound < actual && actual <= correct_bound);
}
