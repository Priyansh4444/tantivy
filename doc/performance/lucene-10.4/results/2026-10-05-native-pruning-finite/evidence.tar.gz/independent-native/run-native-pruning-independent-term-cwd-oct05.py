from pathlib import Path
import json, hashlib, subprocess, shutil

root = Path('/home/pronsh/Coding/playground/search')
out = root/'bench/native-pruning-finite-independent-compiled-oct05'
cwd = root/'tantivy-pruning-finite-independent-probe-oct05'
summary = json.loads((out/'summary.json').read_text())
identity = summary['test_binaries'][0]
binary = Path(identity['path'])
assert hashlib.sha256(binary.read_bytes()).hexdigest() == identity['sha256']
name = 'native-release-term-scorer-correct-cwd'
args = [str(binary),'query::term_query::term_scorer::tests::','--nocapture']
command = {'args':args,'cwd':str(cwd),'exact_native_binary_sha256':identity['sha256'],'reason':'Earlier passing direct invocation warned source-parallel proptest persistence cannot find source from playground cwd. Preserve earlier logs and verify correct crate cwd.'}
with (out/(name+'.command.json')).open('x') as stream:
    stream.write(json.dumps(command,indent=2)+'\n')
with (out/(name+'.stdout')).open('x') as stdout,(out/(name+'.stderr')).open('x') as stderr:
    process = subprocess.run(args,cwd=cwd,stdout=stdout,stderr=stderr)
stdout = (out/(name+'.stdout')).read_text()
stderr = (out/(name+'.stderr')).read_text()
assert process.returncode == 0 and '16 passed; 0 failed; 1 ignored;' in stdout
assert 'Failed to find absolute path' not in stderr
assert hashlib.sha256(binary.read_bytes()).hexdigest() == identity['sha256']
result = {'exit_code':process.returncode,'passed':16,'ignored_existing':1,'source_path_warning_resolved':True,'test_binary_sha256':identity['sha256'],'no_source_changes':True,'no_rebuild':True}
(out/(name+'.result.json')).write_text(json.dumps(result,indent=2)+'\n')
shutil.copyfile(Path(__file__),out/Path(__file__).name)
files = {str(p.relative_to(out)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file() and p.name != 'manifest.json'}
(out/'manifest.json').write_text(json.dumps({'files':files,'complete':True,'candidate_source_commit':summary['candidate_commit'],'root_integrated_source_commit':summary['integrated_candidate_commit'],'production_artifact_changed':False},indent=2)+'\n')
print(json.dumps({'result':result,'manifest_entries':len(files),'manifest_sha256':hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest()},indent=2))
