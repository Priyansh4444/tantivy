"""Adversarial exact IEEE audit. Read retained vectors; never rewrite them."""
from pathlib import Path
from fractions import Fraction
from functools import lru_cache
import hashlib, json, math, re, struct

ROOT = Path('/home/pronsh/Coding/playground/search')
OUT = ROOT / 'bench/native-pruning-finite-independent-exact-audit-oct05.json'
INPUT = ROOT / 'bench/native-pruning-finite-exact-oracle-oct05/vectors.json'
SOURCE = ROOT / 'tantivy-pr2937/src/fieldnorm/code.rs'
norms = [int(x.replace('_', '')) for x in re.findall(r'\b[0-9][0-9_]*\b', SOURCE.read_text().split('= [', 1)[1].split('];', 1)[0])]
assert len(norms) == 256

@lru_cache(None)
def exact(bits, width=32):
    precision, ebits, bias = (24, 8, 127) if width == 32 else (53, 11, 1023)
    mantissa = bits & ((1 << (precision-1))-1)
    exponent = (bits >> (precision-1)) & ((1 << ebits)-1)
    if exponent == (1 << ebits)-1:
        return None
    if exponent:
        mantissa += 1 << (precision-1)
        exponent -= bias + precision-1
    else:
        exponent = 1-bias-(precision-1)
    result = Fraction(mantissa) * (Fraction(2) ** exponent)
    return -result if bits >> (width-1) else result

def rounded(value, width=32):
    """Quantize a rational by exact integer divmod and explicit even tie."""
    precision, ebits, bias = (24, 8, 127) if width == 32 else (53, 11, 1023)
    sign = 1 << (width-1) if value < 0 else 0
    value = abs(value)
    if not value:
        return sign
    # Find containing power-of-two binade without a floating estimate.
    exponent = value.numerator.bit_length()-value.denominator.bit_length()
    while value < Fraction(2) ** exponent:
        exponent -= 1
    while value >= Fraction(2) ** (exponent+1):
        exponent += 1
    quantum_exponent = max(exponent-(precision-1), 1-bias-(precision-1))
    scaled = value / (Fraction(2) ** quantum_exponent)
    integer, remainder = divmod(scaled.numerator, scaled.denominator)
    if remainder * 2 > scaled.denominator or (remainder * 2 == scaled.denominator and integer & 1):
        integer += 1
    represented = integer * (Fraction(2) ** quantum_exponent)
    if not represented:
        return sign
    if represented >= Fraction(2) ** (bias+1):
        return sign | (((1 << ebits)-1) << (precision-1))
    if represented < Fraction(2) ** (1-bias):
        return sign | integer
    if integer == 1 << precision:
        integer >>= 1
        quantum_exponent += 1
    return sign | ((quantum_exponent+(precision-1)+bias) << (precision-1)) | (integer-(1 << (precision-1)))

INF = 0x7f800000
ONE = 0x3f800000
def product(a, b):
    if a == INF or b == INF:
        assert a != 0 and b != 0
        return INF
    return rounded(exact(a) * exact(b))

@lru_cache(None)
def cache(avg, k, b):
    result = []
    for n in norms:
        dl = rounded(Fraction(n))
        bd = product(b, dl)
        quotient = rounded(exact(bd) / exact(avg))
        complement = rounded(exact(ONE)-exact(b))
        total = rounded(exact(complement)+exact(quotient))
        comp = product(k, total)
        result.append(INF if comp == 0 else rounded(1 / exact(comp)))
    return tuple(result)

def up(bits, width=32):
    inf = INF if width == 32 else 0x7ff0000000000000
    assert 0 <= bits <= inf
    return min(bits+1, inf)

@lru_cache(None)
def envelope(old, query):
    ratios = [0 if q == 0 else up(rounded(exact(q) / exact(a), 64), 64) for a, q in zip(old, query)]
    for a, q, r in zip(old, query, ratios):
        assert exact(r, 64) >= exact(q)/exact(a)
    return max(ratios)

def upper(old, query, norm, tf):
    m = product(rounded(Fraction(tf)), old[norm])
    assert 0 < m < 0x7f7fffff
    r = envelope(old, query)
    if r == 0:
        return m, r, 0
    u = exact(up(m))
    v = up(rounded(u * exact(r, 64), 64), 64)
    assert exact(v, 64) >= u * exact(r, 64)
    c = up(rounded(exact(v, 64)))
    assert c == INF or exact(c) >= exact(v, 64)
    return m, r, c

@lru_cache(None)
def score(w, x):
    if x == INF:
        return w
    d = rounded(exact(ONE)+exact(x))
    quotient = 0 if d == INF else rounded(exact(w)/exact(d))
    return rounded(exact(w)-exact(quotient))

data = json.loads(INPUT.read_text())
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == data['norm_table_source_sha256']
checks = 0
for vector in data['vectors']:
    old = cache(int(vector['selection_average_bits'],16),0x3f99999a,0x3f400000)
    q = cache(int(vector['query_average_bits'],16),int(vector['k1_bits'],16),int(vector['b_bits'],16))
    m,r,c = upper(old,q,vector['selected_norm'],vector['selected_tf_ceiling'])
    assert f'{m:08x}' == vector['old_max_bits']
    assert f'{r:016x}' == vector['ratio_up_bits']
    assert f'{c:08x}' == vector['input_upper_bits']
    actual = [product(rounded(Fraction(d['tf'])),q[d['norm']]) for d in vector['docs']]
    assert all(product(rounded(Fraction(d['tf'])),old[d['norm']]) <= m for d in vector['docs'])
    assert all(x <= c for x in actual)
    for wb,bb in zip(vector['weights_bits'],vector['bound_bits']):
        w,bound = int(wb,16),int(bb,16)
        assert score(w,c) == bound
        assert all(score(w,x) <= bound <= w for x in actual)
        checks += len(actual)

# Local inequality witnesses; a failed local step need not break the final bound.
witnesses = []
a = 0x3f800001
m = product(rounded(Fraction(5)),a)
assert exact(a)*5 > exact(m)
witnesses.append({'kind':'rounded-M-is-not-exact-product','a_bits':f'{a:08x}','tf':5,'m_bits':f'{m:08x}','excess':str(exact(a)*5-exact(m))})
r = rounded(Fraction(1,3),64)
assert exact(r,64) < Fraction(1,3)
witnesses.append({'kind':'nearest-ratio-not-outward','ratio_bits':f'{r:016x}','deficit':str(Fraction(1,3)-exact(r,64))})
u = Fraction(1)+Fraction(1,1<<23)
r = exact(0x3ff0000000000001,64)
v = rounded(u*r,64)
assert exact(v,64) < u*r
witnesses.append({'kind':'nearest-product-not-outward','deficit':str(u*r-exact(v,64))})
v = Fraction(1)+Fraction(1,1<<25)
assert exact(rounded(v)) < v
witnesses.append({'kind':'nearest-cast-not-outward','deficit':str(v-exact(rounded(v)))})

# Exact quantizer boundary probes independent of the retained oracle's sanity checks.
quantization = [
    (32,Fraction(1,1<<150),0),
    (32,Fraction(3,1<<150),2),
    (32,Fraction(2)**-126-Fraction(2)**-150,0x00800000),
    (32,Fraction(2)**128-Fraction(2)**103,INF),
    (32,Fraction((1<<32)-1),0x4f800000),
    (64,Fraction(1)+Fraction(1,1<<53),0x3ff0000000000000),
    (64,Fraction(1)+Fraction(3,1<<53),0x3ff0000000000002),
    (64,Fraction(1,1<<1075),0),
    (64,Fraction(3,1<<1075),2),
]
for width,value,expected in quantization:
    assert rounded(value,width) == expected,(width,value,hex(rounded(value,width)),hex(expected))

# Source-cache scalar counterexample to reconstructing selection at query average.
selection_average, query_average = 0x40400000, 0x4f000000
old = cache(selection_average,0x3f99999a,0x3f400000)
q = cache(query_average,0x3f666666,0x3ecccccd)
docs = [(0,1),(255,100)]
selected = max(docs,key=lambda d:product(rounded(Fraction(d[1])),old[d[0]]))
assert selected == (0,1)
_,_,correct_c = upper(old,q,*selected)
wrong_old = cache(query_average,0x3f99999a,0x3f400000)
_,_,wrong_c = upper(wrong_old,q,*selected)
actual_x = product(rounded(Fraction(100)),q[255])
assert score(ONE,wrong_c) < score(ONE,actual_x) <= score(ONE,correct_c)
witnesses.append({'kind':'query-average-cannot-reconstruct-selection-cache','selection_average_bits':f'{selection_average:08x}','query_average_bits':f'{query_average:08x}','profile_k1_bits':'3f666666','profile_b_bits':'3ecccccd','docs':[{'norm':n,'tf':t} for n,t in docs],'selected_norm':selected[0],'selected_tf_ceiling':selected[1],'correct_input_upper_bits':f'{correct_c:08x}','incorrect_input_upper_bits':f'{wrong_c:08x}','incorrect_score_bound_bits':f'{score(ONE,wrong_c):08x}','actual_score_bits':f'{score(ONE,actual_x):08x}'})

summary = {'review':'independent-exact-RNE32-and-RNE64-v1','input_sha256':hashlib.sha256(INPUT.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'finite_blocks':len(data['vectors']),'score_coverage_comparisons':checks,'exact_RNE64_ratio_and_product_match':True,'quantization_boundary_probes':len(quantization),'local_step_counterexamples':witnesses,'compiled_production_helper_checked':False,'exceptional_runtime_rejections_checked':False}
OUT.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
