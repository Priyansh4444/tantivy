from pathlib import Path
import subprocess, hashlib, json

base = Path('/home/pronsh/Coding/playground/search')
worker = base/'tantivy-pruning-finite-oct05'
main = base/'tantivy-pr2937'
out = base/'bench/native-pruning-finite-independent-compiled-oct05'
receipt = json.loads((base/'bench/native-pruning-finite-attempt-oct05/b1-final-worker-receipt.json').read_text())
source = '86e5609f5047cc41435124f23b928304ce72e897'
integrated = 'b50e2aef3abd77a43fbad56dbaecf2f6c0540a50'
assert receipt['candidate_commit'] == source
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=worker,text=True).strip() == source
assert subprocess.check_output(['git','status','--porcelain'],cwd=worker,text=True).strip() == ''
verified = {}
for name, expected in receipt['source_sha256'].items():
    actual = hashlib.sha256((worker/name).read_bytes()).hexdigest()
    integrated_blob = subprocess.check_output(['git','show',integrated+':'+name],cwd=main)
    integrated_sha = hashlib.sha256(integrated_blob).hexdigest()
    assert actual == expected == integrated_sha, name
    verified[name] = actual
command = ['git','diff','--exit-code',source,integrated,'--','src','Cargo.toml','Cargo.lock','.cargo']
result = subprocess.run(command,cwd=main,capture_output=True,text=True)
assert result.returncode == 0 and result.stdout == '' and result.stderr == ''
patch = base/'bench/native-pruning-finite-attempt-oct05/b1-final-worker.patch'
assert hashlib.sha256(patch.read_bytes()).hexdigest() == receipt['patch_sha256']
summary = {'reviewed_worker_commit':source,'integrated_candidate_commit':integrated,'worker_clean':True,'source_sha256':verified,'whole_src_manifests_cargo_config_equality':{'command':command,'exit_code':result.returncode},'reviewed_retained_patch_sha256':receipt['patch_sha256'],'full_diff_reviewed':True,'implementation_math_objections':[],'contract_limit':'Private selection binding is construction-only in production; no mutable reader/weight rebinding safety claim. No performance acceptance.'}
(out/'final-source-review-identities.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
