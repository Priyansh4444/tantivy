from pathlib import Path
import hashlib, json, subprocess, shutil

out = Path('/home/pronsh/Coding/playground/search/bench/native-pruning-finite-independent-compiled-oct05')
summary = json.loads((out/'summary.json').read_text())
identity = summary['test_binaries'][0]
binary = Path(identity['path'])
assert hashlib.sha256(binary.read_bytes()).hexdigest() == identity['sha256']
checks = [
    ('native-release-real-serializer','postings::serializer::native_transform_tests::',[],3,0),
    ('native-release-term-scorer','query::term_query::term_scorer::tests::',[],16,1),
    ('native-release-bm25','query::bm25::',['--skip','query::bm25::independent_finite_probe::'],22,0),
]
results = []
for name, prefix, extra, count, ignored in checks:
    args = [str(binary),prefix,*extra,'--nocapture']
    (out/(name+'.command.json')).write_text(json.dumps({'args':args,'exact_native_binary_sha256':identity['sha256']},indent=2)+'\n')
    with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
        process = subprocess.run(args,stdout=stdout,stderr=stderr)
    text = (out/(name+'.stdout')).read_text()
    expected = f'{count} passed; 0 failed; {ignored} ignored;'
    result = {'name':name,'exit_code':process.returncode,'expected_summary':expected,'summary_observed':expected in text,'test_binary_sha256':identity['sha256']}
    (out/(name+'.result.json')).write_text(json.dumps(result,indent=2)+'\n')
    assert process.returncode == 0 and expected in text, result
    results.append(result)
assert hashlib.sha256(binary.read_bytes()).hexdigest() == identity['sha256']
(out/'native-fixture-checks.json').write_text(json.dumps({'status':'passed','checks':results,'native_release_opt3_lto_true':True,'no_recompile':True,'production_artifact_modified':False,'timings_run':False},indent=2)+'\n')
shutil.copyfile(Path(__file__),out/Path(__file__).name)
files = {str(p.relative_to(out)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file() and p.name != 'manifest.json'}
(out/'manifest.json').write_text(json.dumps({'files':files,'complete':True,'candidate_source_commit':summary['candidate_commit'],'root_integrated_source_commit':summary['integrated_candidate_commit'],'production_artifact_changed':False},indent=2)+'\n')
print(json.dumps({'checks':results,'manifest_entries':len(files),'manifest_sha256':hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest()},indent=2))
