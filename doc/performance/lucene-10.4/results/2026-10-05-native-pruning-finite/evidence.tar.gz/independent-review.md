# Independent B1 finite-transform review — October 5

Status: arithmetic/oracle, full frozen implementation review and independent
native release helper probe PASS. Root's complete release serialized/exhaustive/
cross-engine gates, pruning counters and performance acceptance remain pending.
Worker commit86e5609f5047cc41435124f23b928304ce72e897 is the reviewed target;
its source equals integrated candidateb50e2aef3abd77a43fbad56dbaecf2f6c0540a50.
I changed only external evidence and a separate detached probe checkout. No main,
worker core, index, retained input, native adapter or timing artifact was changed.

throughput checkpoint: n/a, read-only investigation

## Evidence and judgment

I read the complete selected synthesis, Candidate B, fresh arena judge, original
transform proof and adversarial review. I traced the main checkout's actual
native cache/score arithmetic, selection-statistics tag and average rounding,
serializer comparator/TF encoding, and post-boost TermWeight binding. I also read
the root Fraction oracle and every vector through a separate exact arithmetic
audit. The preliminary worker diff was read while edits were still in progress;
it is not a frozen review target.

The finite-only analytic chain is conservative under binary32/binary64 nearest
ties-to-even, gradual underflow and the unchanged literal operation order. I
found no arithmetic defect in that domain. This is a narrow judgment: it neither
proves the implementation follows the chain nor establishes a speed win.

Independent audit: `/tmp/native-pruning-independent-exact-audit-oct05.py`, receipt
`native-pruning-finite-independent-exact-audit-oct05.json`. Its separately written
generic rational quantizer computes BOTH binary32 and binary64 rounding; it does
not import or execute the root oracle. All 384 retained blocks agree exactly on
M/R/C/bound bits; all 245,760 literal-score coverage comparisons pass. Nine extra
binary32/binary64 halfway, normal/subnormal, overflow and u32 conversion probes
pass. Input vectors SHA256 is
`a7ff81ae15d54b9f904a2b6da90577497577c9871ea461cc5884899da1c8b4b7`.
The receipt records the independent script digest and explicit false flags for
compiled-helper and exceptional-runtime validation. No sampling claim replaces
the argument below.

## Analytic chain

The actual writer maximizes RN32(F(t)*a[n]), where a is the DEFAULT native cache
at the physical selection average and F is u32-to-f32 conversion. Positive
finite a makes every comparison ordered, including positive overflow. The
decoded selected TF ceiling only increases that selected product. Thus every
actual rounded old input is <=M, even if ties select the other posting and even
if another posting has larger TF. TF code255 converts its u32::MAX ceiling to
binary32 2^32; using the exact integer 4294967295 as a binary64 operand is a
different calculation and would not match the scorer.

For 0<M<f32::MAX, RN32(p)<=M implies p<nextup32(M). This uses monotonic rounding
and representable endpoints rather than a relative epsilon; subnormal rounding
cells are covered. Zero, maximum-finite and infinite M are outside the cheap
transform and must fall back. An old inverse zero/infinity/NaN/negative is
rejected before accepting its max-selection certificate.

Exact promotion of positive finite binary32 q and a to binary64 loses no bits.
The possible positive q/a range lies safely inside normal binary64. One next-up
after nearest binary64 division encloses the exact ratio, and the maximum over
ALL256 actual entries encloses every posting's ratio. +0 q contributes exact
zero; -0, negative, infinity and NaN q are rejected in B1. R=0 therefore proves
all q are +0 and C=0. For positive R, the represented U*R range likewise fits
binary64; one next-up after the product encloses it. One next-up after the
nearest binary32 cast encloses V, including cast underflow/overflow. C=+infinity
is safe but supplies only the existing global contribution bound.

For fixed finite w>=0 and x>=0, RN32(1+x) is positive/nondecreasing; its rounded
quotient w/D is nonnegative/nonincreasing; rounded w-Q is nondecreasing. Thus
the unchanged literal score at C covers every actual literal score. No separate
upward score epsilon is required. Clamping to zero and taking the minimum with
the independently certified global w are safe. Negative/nonfinite weights and
unsafe normalization retain their existing fallback; either zero weight avoids
cold setup. The subtraction must use the actual post-boost w, with no second
frequency product or unboosted-score multiplication.

## Concrete adversarial witnesses

The receipt independently reproduces the four earlier local inequalities:
M is below the real old product for a bits3f800001/TF5 by 1/8388608;
nearest64(1/3) is below 1/3 by 1/54043195528445952; nearest64 multiplication of
(1+2^-23)*nextup64(1) is below its exact product; nearest32(1+2^-25) is 1.
Deleting an outward step is therefore not justified by nearest rounding alone.
These are local-step counterexamples, not claims that each individually defeats
the final bound after the remaining inflation steps.

A new scalar binding witness demonstrates why reconstruction MUST use the
selection average. DEFAULT selection average bits40400000 (3), query average
bits4f000000 (2^31), query k1 bits3f666666/b bits3ecccccd, and postings
(norm0,TF1)/(norm255,TF100) select the norm0 posting under the true old cache.
Reconstructing the old cache at the query average instead gives input ceiling
bits408b0808 and score bound bits3f501a34, below the norm255 posting's actual
score bits3f7dc5ed at w=1. Correct reconstruction gives safe input ceiling
bits4f08c08d. This is a scalar source-cache witness; no serialized segment or
Wiki corpus occurrence is claimed. Repeat either pair to fill a native block
to test actual selected-pair authority when a fixture permits those norms.

B1 MUST reject every b1 infinity cache. In particular, the retained avg3
norm0/TF1 and norm1/TF2 old-input tie (bits40555555) defeats any later B2
`M<=H` exclusion: norm0's query score is w. B2 is not part of this review or
implementation acceptance. Fractional phrase frequencies invalidate its F>=1
exclusion argument; keep this transform on integer term-postings routes.

## Provenance and lifecycle boundaries

Only the actual reader's native selection tag AND original selection average
bind the persisted pair. Exact field totals alone do not confer native
comparator provenance. Public serializer/legacy-tag paths remain untrusted.
Public TermScorer::new with arbitrary norms/weight cannot confer a certificate.
The actual production TermWeight route obtains the same field's postings,
selection statistics and fieldnorm reader, applies boost, then installs the
private policy. No selection-from-query-average shortcut is valid.

NativeLucene scoring is not synonymous with provider identity: a custom public
statistics provider can forward Searcher.field_statistics(), including a native
snapshot. Ordinary Bm25FieldStatistics::new and public classic weight constructors
stay classic. A forwarded native snapshot is mathematically eligible if the
actual cache/context predicates hold; avoid an inaccurate claim that the enum
alone excludes all custom providers. Any narrower provider-identity restriction
needs a separate marker or explicit implementation contract.

Immutable envelope state must remain with its fixed query cache/actual boosted
weight and reader/norm selection binding. Movement/reset invalidates only the
numeric block cache as today. Clone can share the immutable Arc and copy its
current fixed-owner cache because weight/norm binding is identical; subsequent
movement must diverge safely. Public weight/reader-taking cursor evaluation must
neither read nor populate that cache. The independently shipped cache fix is
the necessary foundation, not B1 performance evidence.

Preliminary observation to resolve at final review: the private selection
binding method takes self by value and can technically be invoked twice on an
already cached scorer. Current production calls it only immediately after new.
If the accepted contract includes private binding replacement/reset safety,
clear the numeric cache on rebinding; otherwise state and verify its
construction-only caller contract rather than claiming untested replacement
safety. The actual reader/field pairing still depends on that internal caller
contract; a tag enum alone cannot attest arbitrary injected readers.

## Required compiled/runtime acceptance

The root oracle covers 384 positive finite blocks and 16 b1 cache rejections.
It does NOT itself test signed zero, negative/NaN values, invalid averages,
invalid post-boost weight, zero/maxfinite M, codec metadata absence, or lifecycle.
Do not describe those as covered merely because the analytic argument names them.

After the worker's frozen final commit, create a separate detached probe
worktree and append a private bm25 test module only there. The probe should read
the immutable 384 vectors, construct actual native weights with the recorded
k1/b/query average/weight bits, issue contexts at the recorded selection average,
and execute production native_input_envelope/input_upper/score helper methods.
Compare every M/R/C/bound bit and all 245,760 actual score comparisons. Check all
16 recorded rejection configurations. No release benchmark binary may contain
that module, and builds must wait until root ends the paired timing window.

Separately probe actual predicate/runtime fallbacks: legacy tag/scoring,
DEFAULT including mismatched averages, ±0 k1, ±0/negative/nonfinite weight,
zero/negative/subnormal/infinite/NaN average, old inverse zero from normalization
overflow, positive subnormal old/query entries, query +0/-0/negative/infinite/NaN,
R0, zero/maxfinite/infinite M, and f32 cast overflow. Mutating a private test
cache can exercise a branch that ordinary public constructors cannot generate;
label such probes as synthetic, not normal writer occurrences.

Actual native serializer dense and FOR fixtures must confirm selected norm/TF
code255 expansion, old rounded ties, unloaded useful bound coverage, loaded and
unloaded tails, absent metadata, public changed weights/norms, clone and every
movement invalidator. Literal document score bits remain unchanged. Preserve
unchanged native/legacy/exhaustive suites, frozen330, and all three Wiki20 strict
gates/all1913 common score-bit comparisons before clean release timings.

The preceding arithmetic phase supplied no implementation or performance verdict;
the final frozen review and compiled results follow below.

## Final frozen implementation and compiled result

I read the complete final nine-file change at
`86e5609f5047cc41435124f23b928304ce72e897`, including both new test modules and
the final serializer certificate assertions. Its production arithmetic follows
the reviewed chain. Query-cache classification precedes cold DEFAULT cache
allocation; all256 old entries are then validated, all256 ratios enclosed, and
the recorded selected ceiling supplies M. DEFAULT policy stays first. Native
pending state is lazy on the first complete nonzero metadata request; ineligible
cache state resolves permanently to Global. Finite complete transformed bounds
are cached only for the fixed owner; absent metadata, infinity enclosure and
tails retain the specified fallback. Existing public uncached evaluation and
all movement invalidators are unchanged. No score/codec/writer changes occur.

The previously noted test-helper reassignment issue is corrected to explicitly
set Global on mismatch. Production selection binding remains construction-only;
I verified the actual post-boost TermWeight caller and issue no mutable-rebinding
safety claim. The forwarded-native-statistics observation is a scope distinction,
not an arithmetic defect. There are no unresolved correctness objections in this
contract. A 16-byte TermScorer growth (2088→2104) is an explicit measured layout
cost in the worker's generic debug configuration, not an exact-native baseline
comparison or an accepted efficiency win. The independent native release binary
reports TermScorer2128/BlockSegmentPostings1184/Bm25Weight112/FieldNormReader32;
profile/target-dependent layouts must not be compared across those configurations.

I verified all nine final source hashes against the worker receipt and the
integrated candidate's git blobs, the retained full patch digest, clean worker
state, and zero whole-tree difference for src/Cargo.toml/Cargo.lock/.cargo between
worker86e5609 and integratedb50e2ae. Durable receipt:
`native-pruning-finite-independent-compiled-oct05/final-source-review-identities.json`.

The detached probe checkout is
`../tantivy-pruning-finite-independent-probe-oct05`, based exactly on worker86e5609.
Only a four-line cfg(test) module hook was appended there. External private probe
SHA256 is `ef2e5ddf188463ad26eb5fc3706a9f86529e9f81069dcf432389b34c057b1250`.
It directly calls actual production private helpers and actual Bm25Weight.score;
its expected M/R/C/bound bits come from immutable independent vectors, not the
candidate's helper. Release invocation uses target-cpu=native, opt-level3,
LTO=true and overflow-checks=false, with standard release debug assertions off.
The existing test assertions remain active. Full manifest policy, override env,
toolchain, candidate Cargo hashes, commands and stdout/stderr are retained.

All THREE independent native release tests pass: exact384 M/R/C/bound vector
matches;245760 actual score coverage comparisons;16 b1 rejection configurations;
and predicate/actual subnormal old and query cache, synthetic invalid cache/-0,
zeroR, arithmetic guards/cast overflow, and selection-average counterexample
checks. No failing result was repaired by changing the oracle or production.
No benchmark was run and no production artifact contains this test module.

Compiled executable SHA256:
`66c99b66e00abef5fd3ce49f03f97d57f9dbe909a816478687865c4715145e8c`,
28,609,496 bytes. The initial receipt's old release/deps glob found no binary
under the new Cargo layout; discovery was corrected from Cargo's exact Running
unittests path under release/build/tantivy/hash/out, without rebuilding or
rerunning. This receipt-only correction is explicitly recorded.

Completed artifact directory `native-pruning-finite-independent-compiled-oct05`
has66 manifest entries, all commands/logs/probe/driver scripts/source-equality
receipt and summary. Summary SHA256:
`489f91dbebd6f43aa3f3fdc6bdae1b4ced413a85010afdeb79c121a4a0701a2f`;
manifest SHA256:
`4c9006eae1d08a91c0ebbfa96eaddd2287d84521afdebba57d955c2423458b41`.

The final native serializer fixtures explicitly inspect Dense AND FOR selected
pair presence, selected norm membership, TF255→u32::MAX expansion and old rounded
input coverage on first loaded and second unloaded blocks. They also cover the
new-profile changed maximizer, useful synthetic finite bounds, tails, public
weight changes and clone ownership. On root's follow-up instruction I executed
the ALREADY compiled exact-native/LTO test binary without recompilation: all3
serializer fixtures,16 TermScorer tests (one existing long test ignored), and22
existing BM25 tests pass. The BM25 command explicitly skips the independent
probe namespace because its3 tests were already recorded separately. Binary
hash stayed unchanged before/after; separate commands/logs/results are retained
under native-release-* and native-fixture-checks.json. The initial TermScorer
direct invocation passed but warned that source-parallel proptest persistence
could not find source from playground cwd. I preserved those original logs and
reran only that group with the exact crate cwd:16pass/1existingignored, no source
warning, same binary hash, no source change or rebuild. Corrected command and
logs are named native-release-term-scorer-correct-cwd.*. These now close actual
codec and fixed-state witnesses under exact native flags, beyond worker debug
passes. Root must still complete its full required acceptance gates before
timings. This review clears the arithmetic/core-helper correctness
checkpoint only. It supplies no pruning-reach, speed, overall efficiency or full
Lucene-parity acceptance.
