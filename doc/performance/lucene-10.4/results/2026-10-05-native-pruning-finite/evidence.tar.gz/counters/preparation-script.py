from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

BASE = Path('/home/pronsh/Coding/playground/search')
REPO = BASE / 'tantivy-pr2937'
COMMIT = 'b50e2aef3abd77a43fbad56dbaecf2f6c0540a50'
WT = BASE / 'tantivy-pruning-finite-counters-oct05'
OUT = BASE / 'bench/native-pruning-finite-counters-oct05'
OLD = BASE / 'bench/native-profile-pruning-counters-oct05'
OLD_WT = BASE / 'tantivy-pruning-counters-oct05'
FILES = ['src/lib.rs', 'src/postings/block_segment_postings.rs', 'src/query/bm25.rs',
         'src/query/term_query/term_scorer.rs', 'src/query/boolean_query/block_wand_union.rs',
         'src/query/boolean_query/block_wand_intersection.rs']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(args, **kwargs):
    return subprocess.run(args, capture_output=True, text=True, check=True, **kwargs)


def retained():
    paths = [OLD / 'core-instrumentation.patch', OLD / 'counter-map.json', OLD / 'do_query-counters',
             OLD / 'summary.json', OLD / 'adapter/Cargo.toml', OLD / 'adapter/Cargo.lock',
             OLD_WT / 'src/pruning_counters.rs']
    paths += [OLD_WT / rel for rel in FILES]
    return {str(path): sha(path) for path in paths}


assert not os.path.lexists(WT) and not os.path.lexists(OUT), 'destinations must be absent'
assert run(['git', '-C', str(REPO), 'rev-parse', COMMIT]).stdout.strip() == COMMIT
old_before = retained()
OUT.mkdir()
(OUT / 'preparation-script.py').write_bytes(Path(__file__).read_bytes())
run(['git', '-C', str(REPO), 'worktree', 'add', '--detach', str(WT), COMMIT])
assert run(['git', '-C', str(WT), 'rev-parse', 'HEAD']).stdout.strip() == COMMIT
assert not run(['git', '-C', str(WT), 'status', '--porcelain']).stdout
(OUT / 'retained-before.json').write_text(json.dumps(old_before, indent=2) + '\n')
(OUT / 'baseline-source-sha256.json').write_text(json.dumps({rel:sha(WT/rel) for rel in FILES}, indent=2)+'\n')
for rel in FILES:
    snapshot = OUT / 'baseline-source' / rel
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(WT / rel, snapshot)

names = json.loads((OLD / 'counter-map.json').read_text()) + [
    'transform_request_loaded','transform_request_unloaded','transform_cache_hit',
    'transform_evaluation_loaded','transform_evaluation_unloaded','transform_useful_loaded',
    'transform_useful_unloaded','transform_equal_global_loaded','transform_equal_global_unloaded',
    'transform_fallback_loaded','transform_fallback_unloaded','transform_setup_attempt',
    'transform_setup_accept','transform_setup_reject']
assert len(names) == 33 and len(set(names)) == 33
(WT / 'src/pruning_counters.rs').write_text('''use std::sync::atomic::{AtomicU64, Ordering};
pub static COUNTERS: [AtomicU64; 33] = [const { AtomicU64::new(0) }; 33];
pub fn hit(index: usize) { COUNTERS[index].fetch_add(1, Ordering::Relaxed); }
pub fn reset() { for counter in &COUNTERS { counter.store(0, Ordering::Relaxed); } }
pub fn snapshot() -> Vec<u64> { COUNTERS.iter().map(|counter| counter.load(Ordering::Relaxed)).collect() }
pub fn transform_outcome(loaded: bool, score: f32, global: f32) {
    assert!(score.is_finite() && score >= 0.0 && score <= global, "invalid transformed bound");
    hit(if score < global { if loaded { 24 } else { 25 } } else if loaded { 26 } else { 27 });
}
''')
p = WT / 'src/lib.rs'
p.write_text(p.read_text()+'\n#[doc(hidden)]\npub mod pruning_counters;\n')


def replace(rel, old, new):
    path = WT / rel
    text = path.read_text()
    assert text.count(old) == 1, (rel, old, text.count(old))
    path.write_text(text.replace(old, new))


def scope(rel, start, end, transformations):
    path = WT / rel
    text = path.read_text()
    begin = text.index(start)
    stop = text.index(end, begin)
    section = text[begin:stop]
    for old, new in transformations:
        assert section.count(old) == 1, (rel, start, old, section.count(old))
        section = section.replace(old, new)
    path.write_text(text[:begin]+section+text[stop:])


replace('src/query/bm25.rs', 'pub fn score(&self, fieldnorm_id: u8, term_freq: u32) -> Score {',
        'pub fn score(&self, fieldnorm_id: u8, term_freq: u32) -> Score {\n        crate::pruning_counters::hit(0);')
replace('src/query/term_query/term_scorer.rs', 'fn score(&mut self) -> Score {',
        'fn score(&mut self) -> Score {\n        crate::pruning_counters::hit(1);')
rel = 'src/query/term_query/term_scorer.rs'
scope(rel, 'pub fn block_max_score(&mut self)', 'pub fn term_freq(', [
    ('if !self.similarity_weight.has_safe_score_bounds() {', 'if !self.similarity_weight.has_safe_score_bounds() {\n            crate::pruning_counters::hit(10);'),
    ('if let TermBlockBounds::PendingNative(context) = self.block_bounds {',
     'if let TermBlockBounds::PendingNative(context) = self.block_bounds {\n                crate::pruning_counters::hit(30);'),
    ('.unwrap_or(TermBlockBounds::Global);', '.unwrap_or(TermBlockBounds::Global);\n                crate::pruning_counters::hit(if matches!(self.block_bounds, TermBlockBounds::NativeTransform(_)) { 31 } else { 32 });'),
])
rel = 'src/postings/block_segment_postings.rs'
scope(rel, 'pub(crate) fn block_max_score_with_stored_max(', 'pub(crate) fn block_max_score_with_native_envelope(', [
    ('if !bm25_weight.has_safe_score_bounds() {', 'if !bm25_weight.has_safe_score_bounds() {\n            crate::pruning_counters::hit(10);'),
    ('if !use_stored_max && self.skip_reader.last_doc_in_block() != TERMINATED {',
     'if !use_stored_max && self.skip_reader.last_doc_in_block() != TERMINATED {\n            crate::pruning_counters::hit(if self.block_is_loaded() { 5 } else { 6 });'),
    ('if let Some(score) = self.block_max_score_cache {', 'if let Some(score) = self.block_max_score_cache {\n            crate::pruning_counters::hit(9);'),
    ('if let Some(skip_reader_max_score) = self.skip_reader.block_max_score(bm25_weight) {',
     'if let Some(skip_reader_max_score) = self.skip_reader.block_max_score(bm25_weight) {\n                crate::pruning_counters::hit(7);'),
])
scope(rel, 'pub(crate) fn block_max_score_with_native_envelope(', '// Callers check score-bound safety', [
    ('if !bm25_weight.has_safe_score_bounds() {', 'if !bm25_weight.has_safe_score_bounds() {\n            crate::pruning_counters::hit(10);'),
    ('if let Some(score) = self.block_max_score_cache {',
     'let counter_loaded = self.block_is_loaded();\n        crate::pruning_counters::hit(if counter_loaded { 19 } else { 20 });\n        if let Some(score) = self.block_max_score_cache {\n            crate::pruning_counters::hit(9);\n            crate::pruning_counters::hit(21);\n            crate::pruning_counters::transform_outcome(counter_loaded, score, bm25_weight.max_score());'),
    ('let bound = bm25_weight.score_from_native_input_upper(upper);',
     'let bound = bm25_weight.score_from_native_input_upper(upper);\n                    crate::pruning_counters::hit(if counter_loaded { 22 } else { 23 });\n                    crate::pruning_counters::transform_outcome(counter_loaded, bound, bm25_weight.max_score());'),
    ('bm25_weight.max_score()\n    }', 'crate::pruning_counters::hit(if counter_loaded { 28 } else { 29 });\n        bm25_weight.max_score()\n    }'),
])
scope(rel, 'fn loaded_block_max_score(', 'pub(crate) fn freq_reading_option(', [
    ('let docs = self.doc_decoder.output_array().iter().copied();',
     'crate::pruning_counters::hit(8);\n        let docs = self.doc_decoder.output_array().iter().copied();'),
])
for name, index in [('decode_bitpacked_block',2), ('decode_dense_block',3), ('decode_vint_block',4)]:
    replace(rel, name+'(\n                    &mut self.doc_decoder,',
            f'crate::pruning_counters::hit({index});\n                '+name+'(\n                    &mut self.doc_decoder,')
rel = 'src/query/boolean_query/block_wand_union.rs'
for name, index in [('two_term_or_maxscore',18), ('block_wand',12), ('block_wand_single_scorer',11)]:
    path = WT / rel
    text = path.read_text()
    begin = text.index('fn '+name+'(')
    body = text.index(') {', begin)+3
    path.write_text(text[:body]+f'\n    crate::pruning_counters::hit({index});'+text[body:])
replace(rel, 'while scorer.block_max_score() <= threshold {', 'while scorer.block_max_score() <= threshold {\n            crate::pruning_counters::hit(15);')
replace(rel, 'if upper_bound.score(block_max_score_sum) <= threshold {', 'if upper_bound.score(block_max_score_sum) <= threshold {\n            crate::pruning_counters::hit(16);')
rel = 'src/query/boolean_query/block_wand_intersection.rs'
for name, index in [('sparse_dense_intersection',14), ('block_wand_intersection',13)]:
    path = WT / rel
    text = path.read_text()
    begin = text.index('fn '+name+'(')
    body = text.index(') {', begin)+3
    path.write_text(text[:body]+f'\n    crate::pruning_counters::hit({index});'+text[body:])
replace(rel, 'if upper_bound.score(f64::from(leader_block_max) + secondary_block_max_sum) <= threshold {',
        'if upper_bound.score(f64::from(leader_block_max) + secondary_block_max_sum) <= threshold {\n            crate::pruning_counters::hit(17);')

adapter = OUT / 'adapter'
(adapter / 'src/bin/shared').mkdir(parents=True)
source = WT / 'doc/performance/lucene-10.4'
shutil.copyfile(source / 'shared/bm25_profile.rs', adapter / 'src/bin/shared/bm25_profile.rs')
query = (source / 'do_query.rs').read_text()
assert query.count('let query = query_parser.parse_query(fields[1])?;') == 1
assert query.count('println!("{}", count);') == 1
query = query.replace('let query = query_parser.parse_query(fields[1])?;',
                      'tantivy::pruning_counters::reset();\n        let query = query_parser.parse_query(fields[1])?;')
query = query.replace('println!("{}", count);',
                      'eprintln!("COUNTERS\\t{}\\t{}\\t{:?}",command,fields[1],tantivy::pruning_counters::snapshot());\n        println!("{}", count);')
(adapter / 'src/bin/do_query.rs').write_text(query)
manifest = (OLD / 'adapter/Cargo.toml').read_text().replace(str(OLD_WT), str(WT))
assert str(WT) in manifest and str(OLD_WT) not in manifest and 'serde_json' in manifest
(adapter / 'Cargo.toml').write_text(manifest)
shutil.copyfile(OLD / 'adapter/Cargo.lock', adapter / 'Cargo.lock')
command = ['cargo','build','--manifest-path',str(adapter/'Cargo.toml'),'--target-dir',str(OUT/'target'),
           '--locked','--release','--jobs','4','--bin','do_query']
(OUT / 'build-command.json').write_text(json.dumps(command,indent=2)+'\n')
(OUT / 'build-environment.json').write_text(json.dumps({'RUSTFLAGS':'-C target-cpu=native','status':'not run; root review and CPU clearance required'},indent=2)+'\n')
compiler = {name: run([name,'--version']).stdout.strip() for name in ['rustc','cargo']}
compiler['rustc_verbose'] = run(['rustc','-Vv']).stdout
(OUT / 'compiler.json').write_text(json.dumps(compiler,indent=2)+'\n')
(OUT / 'counter-map.json').write_text(json.dumps(names,indent=2)+'\n')
patch = run(['git','-C',str(WT),'diff','--no-ext-diff']).stdout
module_diff = subprocess.run(['git','diff','--no-index','--no-ext-diff','--','/dev/null',str(WT/'src/pruning_counters.rs')],capture_output=True,text=True)
assert module_diff.returncode == 1
(OUT / 'core-instrumentation.patch').write_text(patch + module_diff.stdout)
for rel in FILES + ['src/pruning_counters.rs']:
    snapshot = OUT / 'instrumented-source' / rel
    snapshot.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(WT / rel,snapshot)
paths = [WT/rel for rel in FILES+['src/pruning_counters.rs']]
paths += [adapter/'Cargo.toml',adapter/'Cargo.lock',adapter/'src/bin/do_query.rs',adapter/'src/bin/shared/bm25_profile.rs']
(OUT / 'instrumentation-source-sha256.json').write_text(json.dumps({str(path):sha(path) for path in paths},indent=2)+'\n')
assert retained() == old_before, 'retained baseline changed during preparation'
(OUT / 'retained-after-preparation.json').write_text(json.dumps(retained(),indent=2)+'\n')
(OUT / 'preparation-receipt.json').write_text(json.dumps({'candidate_commit':COMMIT,'instrumented_worktree':str(WT),
    'build_status':'not started; root full review and clearance required','counter_count':len(names),
    'core_patch_sha256':sha(OUT/'core-instrumentation.patch'),'module_sha256':sha(WT/'src/pruning_counters.rs'),
    'retained_checked_files_unchanged':len(old_before),'git_status':run(['git','-C',str(WT),'status','--porcelain']).stdout},indent=2)+'\n')
print('Prepared instrumented source only; build NOT run.')
