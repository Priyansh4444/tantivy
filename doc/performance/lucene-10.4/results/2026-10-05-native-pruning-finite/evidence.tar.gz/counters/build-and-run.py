#!/usr/bin/env python3
"""Build and execute isolated atomic instrumentation; never a timing ruler."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys

OUT = Path(__file__).resolve().parent
BASE = OUT.parent.parent
WT = BASE / 'tantivy-pruning-finite-counters-oct05'
OLD = BASE / 'bench/native-profile-pruning-counters-oct05'
INDEX = BASE / 'bench/wiki-1m-native-aligned-v11-oct05.idx'
COMMIT = 'b50e2aef3abd77a43fbad56dbaecf2f6c0540a50'
QUERY_SHA = '47feb065c35e50ef465beab072ae8549ffef9dd23e20e708c458139adcfccfc5'
TOOLS = WT / 'doc/performance/lucene-10.4'
sys.path.insert(0, str(TOOLS))
from lucene_mode import NativeProfile, PROFILES, validate_receipt
PROFILES = {'default':NativeProfile('default','1.2','.75','3f99999a','3f400000'), **PROFILES}


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def write(name, value):
    with (OUT/name).open('x') as stream:
        stream.write(json.dumps(value,indent=2,allow_nan=False)+'\n')


def guards():
    sources = json.loads((OUT/'instrumentation-source-sha256.json').read_text())
    for rel in ('queries-wiki.jsonl','lucene_mode.py','tantivy_statistics.py','provenance.py','do_query.rs','shared/bm25_profile.rs'):
        path = TOOLS/rel
        sources[str(path)] = sha(path)
    sources[str(Path(__file__).resolve())] = sha(Path(__file__).resolve())
    sources[str(OUT/'counter-map.json')] = sha(OUT/'counter-map.json')
    sources[str(OUT/'core-instrumentation.patch')] = sha(OUT/'core-instrumentation.patch')
    for path,digest in json.loads((OUT/'instrumentation-source-sha256.json').read_text()).items():
        assert sha(Path(path)) == digest, ('approved instrumentation changed',path)
    source_values = {path:sha(Path(path)) for path in sources}
    retained = json.loads((OUT/'retained-before.json').read_text())
    for path in OLD.iterdir():
        if path.is_file():
            retained[str(path)] = sha(path)
    retained_values = {path:sha(Path(path)) for path in retained}
    expected_retained = json.loads((OUT/'retained-before.json').read_text())
    assert all(retained_values[path] == digest for path,digest in expected_retained.items())
    ruler = BASE/'bench/native-profile-aligned-oct05/frozen-ruler.json'
    frozen = json.loads(ruler.read_text())
    index = {}
    for path in sorted(INDEX.rglob('*')):
        assert not path.is_symlink(), ('index symlink',str(path))
        if path.is_file():
            index[str(path)] = {'bytes':path.stat().st_size,'sha256':sha(path)}
    expected_index = {path:row for path,row in frozen['artifacts'].items() if Path(path).parent == INDEX}
    assert index == expected_index, 'aligned index differs from frozen ruler'
    head = subprocess.check_output(['git','-C',str(WT),'rev-parse','HEAD'],text=True).strip()
    assert head == COMMIT
    return {'candidate_commit':head,'sources_sha256':source_values,'index':index,
            'retained_sha256':retained_values,'frozen_ruler_sha256':sha(ruler)}



def bounded(command, timeout, *, payload=None, stdout=None, stderr=None, env=None):
    process = subprocess.Popen(command, stdin=subprocess.PIPE if payload is not None else subprocess.DEVNULL,
        stdout=stdout if stdout is not None else subprocess.PIPE,
        stderr=stderr if stderr is not None else subprocess.PIPE,
        text=True, env=env, start_new_session=True)
    timed_out = False
    try:
        output, errors = process.communicate(payload, timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        output, errors = process.communicate(timeout=5)
    except BaseException:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait(timeout=5)
        raise
    return subprocess.CompletedProcess(command,process.returncode,output,errors), timed_out


def accounting(entry):
    c = entry['counters']
    request = c['transform_request_loaded']+c['transform_request_unloaded']
    evaluation = c['transform_evaluation_loaded']+c['transform_evaluation_unloaded']
    fallback = c['transform_fallback_loaded']+c['transform_fallback_unloaded']
    outcomes = sum(c[name] for name in ('transform_useful_loaded','transform_useful_unloaded',
                                       'transform_equal_global_loaded','transform_equal_global_unloaded'))
    assert request == c['transform_cache_hit']+evaluation+fallback, entry
    assert evaluation+c['transform_cache_hit'] == outcomes, entry
    assert c['transform_setup_attempt'] == c['transform_setup_accept']+c['transform_setup_reject'], entry
    if entry['mode'] == 'COUNT':
        assert all(c[name] == 0 for name in c if name.startswith('transform_')), entry


def main():
    assert not (OUT/'execution-started.json').exists(), 'execution already attempted; preserve previous evidence'
    write('execution-started.json',{'utc':datetime.now(timezone.utc).isoformat(),'scope':'untimed atomic counter execution only'})
    before = guards()
    write('guards-before.json',before)
    names = json.loads((OUT/'counter-map.json').read_text())
    old_names = json.loads((OLD/'counter-map.json').read_text())
    assert names[:19] == old_names and len(names) == 33
    suite = TOOLS/'queries-wiki.jsonl'
    assert sha(suite) == QUERY_SHA
    queries = [json.loads(line)['query'] for line in suite.read_text().splitlines()]
    assert len(queries) == 20 and len(set(queries)) == 20
    command = json.loads((OUT/'build-command.json').read_text())
    env = os.environ.copy()
    env['RUSTFLAGS'] = '-C target-cpu=native'
    with (OUT/'build.stdout').open('x') as stdout, (OUT/'build.stderr').open('x') as stderr:
        result, timed_out = bounded(command,1800,env=env,stdout=stdout,stderr=stderr)
    write('build-result.json',{'returncode':result.returncode,'timed_out':timed_out,'command':command,'RUSTFLAGS':env['RUSTFLAGS']})
    assert result.returncode == 0, 'build failed; inspect retained stdout/stderr'
    assert guards() == before, 'guard inputs changed during build'
    binary = OUT/'do_query-counters'
    assert not binary.exists()
    shutil.copyfile(OUT/'target/release/do_query',binary)
    binary.chmod(0o755)
    binary_identity = {'sha256':sha(binary),'bytes':binary.stat().st_size,'candidate_commit':COMMIT}
    write('binary-identity.json',binary_identity)
    previous = json.loads((OLD/'summary.json').read_text())['profiles']
    summary = {}
    for name,profile in PROFILES.items():
        argv = [str(binary),str(INDEX)] + profile.arguments()
        requests = ['BM25_CONFIG\t'] + ['TOP_10\t'+query for _ in range(2) for query in queries]
        requests += ['COUNT\t'+query for query in queries]+['VALIDATE_TOP_10\t'+query for query in queries]
        payload = '\n'.join(requests)+'\n'
        write(name+'.command.json',argv)
        with (OUT/(name+'.stdin')).open('x') as stream:
            stream.write(payload)
        result, timed_out = bounded(argv,600,payload=payload)
        for suffix,data in [('stdout',result.stdout),('stderr',result.stderr)]:
            with (OUT/(name+'.'+suffix)).open('x') as stream:
                stream.write(data)
        write(name+'.process-result.json',{'returncode':result.returncode,'timed_out':timed_out})
        assert result.returncode == 0, (name,'process failed')
        lines = result.stdout.splitlines()
        assert len(lines) == 81, (name,len(lines))
        receipt = validate_receipt(profile,'tantivy',lines[0])
        assert receipt['observed']['doc_count'] == 917578
        assert receipt['observed']['sum_total_term_freq'] == 294827020
        old_lines = (OLD/(name+'.stdout')).read_text().splitlines()
        assert len(old_lines) == 81
        assert all(line == '1' for line in lines[1:41])
        assert lines[41:61] == old_lines[41:61], (name,'COUNT mismatch against preserved baseline')
        assert all(line == '1' for line in lines[61:]), (name,'exhaustive validator failed')
        entries = []
        for line in result.stderr.splitlines():
            if line.startswith('COUNTERS\t'):
                _,mode,query,raw = line.split('\t')
                values = json.loads(raw)
                assert len(values) == len(names) and all(type(value) is int and value >= 0 for value in values)
                entries.append({'mode':mode,'query':query,'counters':dict(zip(names,values,strict=True))})
        assert len(entries) == 80, (name,len(entries))
        assert [(entry['mode'],entry['query']) for entry in entries] == [tuple(request.split('\t')) for request in requests[1:]]
        assert entries[:20] == entries[20:40], (name,'repeated TOP counters differ')
        for entry in entries:
            accounting(entry)
        comparison = []
        for group,start in [('top10',0),('count',40)]:
            for candidate,baseline in zip(entries[start:start+20],previous[name][group],strict=True):
                assert candidate['query'] == baseline['query'] and candidate['mode'] == baseline['mode']
                comparison.append({'mode':candidate['mode'],'query':candidate['query'],
                    'baseline_counters':baseline['counters'],
                    'candidate_old_counter_delta':{key:candidate['counters'][key]-baseline['counters'][key] for key in old_names},
                    'candidate_transform_counters':{key:candidate['counters'][key] for key in names[19:]}})
        summary[name] = {'command':argv,'receipt':receipt,'entries':entries,'count_responses':lines[41:61],
                         'repeats_identical':True,'validation_passed':True,'accounting_passed':True,'comparison':comparison}
        write(name+'.json',summary[name])
    after = guards()
    write('guards-after.json',after)
    assert after == before, 'final source/index/retained guard changed'
    assert sha(binary) == binary_identity['sha256']
    inventory = {str(path.relative_to(OUT)):sha(path) for path in OUT.rglob('*')
                 if path.is_file() and 'target' not in path.relative_to(OUT).parts}
    write('summary.json',{'untimed':True,'completed':True,'candidate_commit':COMMIT,
        'binary_identity':binary_identity,'profiles':summary,'query_sha256':QUERY_SHA,
        'guards_equal':True,'artifact_sha256':inventory,
        'scope':'atomic execution mechanism only; no latency or RSS claim'})
    print(json.dumps({'completed':True,'profiles':len(summary),'counter_rows':sum(len(row['entries']) for row in summary.values()),
                      'summary_sha256':sha(OUT/'summary.json')}),flush=True)


if __name__ == '__main__':
    main()
