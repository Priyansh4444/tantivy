# B2 feasible-norm suffix envelope — design only, October 5

## Caller usage first

Existing native TermQuery and Boolean top-K callers retain their APIs:

```rust
// Existing production construction, after boost. Pseudocode, not implemented.
let mut scorer = TermScorer::new(postings, norms, actual_boosted_weight)
    .with_stored_block_max_selection(reader_selection_average,
                                    reader_selection_provenance);

scorer.seek_block(target);         // metadata-only movement for a later block
let upper = scorer.block_max_score();
// Existing WAND compares its conservative score sum with the collector threshold.
// A losing complete block can be advanced past before doc/TF decoding.
```

This hypothesis extends the private native bound policy to actual query caches
containing positive infinity, including b=1. The complete block's existing
selected DEFAULT pair yields a rounded old-input ceiling M. Only norms whose
actual rounded old inverse is <=M can occur in that block. The proposed suffix
table answers the ratio maximum over exactly that feasible set. An infinite
query inverse contributes an infinite table entry until **old_a[n]>M** excludes
it. Equality retains it and returns the global contribution bound.

Keep DEFAULT as the first branch, its mismatched-average fallback unchanged,
and keep B1's constant all-norm ratio for already eligible finite caches. Thus
this is one b=1-capable exclusion hypothesis, not a simultaneous replacement of
B1's finite-profile hot path. No-bound calls never construct a table. VInt tails
retain the present loaded-literal/unloaded-global policy. Public
`cursor.block_max_score(&other_norms, &other_weight)` remains uncached and cannot
receive this certificate.

The integration baseline is conditional on root's B1 keep/revert verdict. If B1
is accepted, add B2 as a separate extension measured against accepted B1. If B1
is reverted, implement only the same lazy feasible path for infinity-containing
caches against e133, leaving finite nondefault caches Global in that experiment.
Do not quietly reintroduce unaccepted B1 as part of B2. This package implements
nothing and asserts no speed win or full Lucene API parity.

throughput checkpoint: n/a, read-only investigation

## Working record and source grounding

Workflow investigation steps applied:

1. Trace the relevant source, configuration, and runtime path. For motivation questions, inspect the change history and rationale.
2. Throughput checkpoint stays one line: `throughput checkpoint: n/a, read-only investigation`. The four-item version is for code-shaped work.
3. Produce an evidence-backed explanation (Overview / Key Concepts / How It Works / Where Things Live / Gotchas), or a recommendation with a tradeoffs table if the request is a decision between alternatives.
4. Apply a plain-writing pass to the reply.

Architecture phases: Ground and Sketch completed for this arena candidate;
Agree belongs to root's synthesis; Implement and Scrap are deferred by the
read-only brief. The parent arena supplies the competing agent designs; this
candidate also compares full and compressed representations without running a
second agent. Model-the-domain changes the choice to a fixed immutable suffix
envelope rather than exceptional-norm booleans scattered through callers.
Exhaust-the-design-space changes the choice to compare two actual storage and
lookup shapes before recommending the simplest reference implementation.

The [brief](native-pruning-b2-arena-brief-oct05.md) was read in full. Grounding
also used the existing [Candidate B](native-profile-pruning-design-b-oct05.md)
and [independent B1 review](native-pruning-finite-independent-review-oct05.md),
with current source reads and both added B1 test modules. This is source/design
evidence only: no implementation, worktree, build, test, hash, profile or timing
job was run. Only this assigned external design file was written.

| Contract | Source and implication |
|---|---|
| Exact cache arithmetic | [bm25.rs:176](../tantivy-pr2937/src/query/bm25.rs#L176) and [bm25.rs:201](../tantivy-pr2937/src/query/bm25.rs#L201): reconstruct the actual DEFAULT cache with its original rounded operation order; use the existing query cache, not a symbolic normalization. |
| Native physical provenance | [field_statistics.rs:17](../tantivy-pr2937/src/index/field_statistics.rs#L17), [field_statistics.rs:59](../tantivy-pr2937/src/index/field_statistics.rs#L59), [field_statistics.rs:116](../tantivy-pr2937/src/index/field_statistics.rs#L116): native average uses f64 total/population division followed by f32 cast; native selection tag is independent of exact totals. |
| Actual post-boost owner | [term_weight.rs:203](../tantivy-pr2937/src/query/term_query/term_weight.rs#L203): the same field's reader/postings/norms are bound after boost. |
| One actual maximizing pair | [serializer.rs:545](../tantivy-pr2937/src/postings/serializer.rs#L545): native writer maximizes rounded `F(tf)*old_a[n]`; `partial_cmp` ties do not preserve the identity of every maximizer. Positive finite old entries prevent NaN comparison ambiguity. |
| Selected TF ceiling only | [skip.rs:62](../tantivy-pr2937/src/postings/skip.rs#L62), [skip.rs:163](../tantivy-pr2937/src/postings/skip.rs#L163), [skip.rs:176](../tantivy-pr2937/src/postings/skip.rs#L176): byte255 expands to u32::MAX; full Dense and BitPacked/FOR blocks expose a nonzero selected pair; VInt tails do not. |
| Fixed-owner bound dispatch | [term_scorer.rs:126](../tantivy-pr2937/src/query/term_query/term_scorer.rs#L126), [block_segment_postings.rs:220](../tantivy-pr2937/src/postings/block_segment_postings.rs#L220): current B1 is lazy on an actual complete-pair request and never requires full-block decode. |
| Public ownership barrier | [block_segment_postings.rs:165](../tantivy-pr2937/src/postings/block_segment_postings.rs#L165): public differing-weight/norm evaluation neither reads nor writes the fixed-owner numeric cache. Retain this accepted fix. |
| Current executable fixture specification | [bm25_native_bound_tests.rs](../tantivy-pr2937/src/query/bm25_native_bound_tests.rs), [serializer_native_transform_tests.rs](../tantivy-pr2937/src/postings/serializer_native_transform_tests.rs): finite B1 arithmetic, strict norm0 tie, actual Dense/FOR selected pairs, saturation, changed maximizer, tails and owner behavior are present in source; B2 needs new acceptance beyond their B1 infinity rejection. |

## Types, signatures and ownership

The smallest permanent change is one new immutable envelope type and one
additional private TermBlockBounds variant. Avoid increasing the existing B1
allocation to the size of the B2 table or nesting a persistent tagged envelope
inside another enum. Signatures below are sketches with not-implemented bodies.

```rust
// Existing context issuance remains construction-only and crate-private.
struct NativeSelectionContext { average_fieldnorm: f32 }

// Existing B1 type and finite arithmetic stay intact if B1 is accepted.
struct NativeInputEnvelope {
    selection_inverse: Arc<[f32; 256]>,
    ratio_up: f64,
}

// New B2 type, private to native term-postings bounds.
struct NativeFeasibleInputEnvelope {
    selection_inverse: Arc<[f32; 256]>, // validated positive finite, descending
    suffix_ratio_up: [f64; 256],       // finite >=0 or +infinity; never NaN
}

// Transient construction result only; each heap payload has its own exact size.
enum NativeBoundBuild {
    Finite(Arc<NativeInputEnvelope>),
    Feasible(Arc<NativeFeasibleInputEnvelope>),
}

enum TermBlockBounds {
    Global,
    StoredDefault,
    PendingNative(NativeSelectionContext),
    NativeTransform(Arc<NativeInputEnvelope>),
    NativeFeasible(Arc<NativeFeasibleInputEnvelope>),
}

impl Bm25Weight {
    fn native_input_bounds(&self, c: NativeSelectionContext)
        -> Option<NativeBoundBuild> { /* not implemented */ }
    // Classify query cache once, then dispatch to finite B1 or feasible B2.
    // No-infinity caches do not pay suffix construction/lookup cost.
    // A standalone B2 experiment returns None for those finite caches.
}
impl NativeFeasibleInputEnvelope {
    fn input_upper(&self, norm: u8, selected_tf_ceiling: NonZeroU32)
        -> Option<f32> { /* not implemented */ }
    // None means existing global fallback; never a guessed scalar bound.
}
impl BlockSegmentPostings {
    fn block_max_score_with_feasible_envelope(
        &mut self, norms: &FieldNormReader, w: &Bm25Weight,
        e: &NativeFeasibleInputEnvelope,
    ) -> Score { /* not implemented */ }
    // Same fixed-owner safety/tail/cache semantics as existing B1 private entry.
}
```

No new public certificate, parameter flag, generalized bound trait, query cache
registry or planner API. The private cursor entry may share a small literal
score/cache tail with B1 if that removes duplication without exposing ratio or
threshold internals. An abstract envelope trait or callback in this hot path is
unnecessary for two private cases; keep binary search and all rounding in
bm25.rs. SkipReader continues to expose only the stored pair, not score policy.

Pending construction result maps once to Global, NativeTransform, or
NativeFeasible. Rejection is permanent for that immutable scorer binding;
per-block infinity/large-M rejection is not permanent because a later block can
exclude those entries. Do not collapse an envelope to Global after one M>=H
block. Preserve the existing numeric bound cache for finite successful results
only; failed/global enclosures can remain uncached as today. A repeated
noncompetitive block request may therefore repeat its binary search; count it.

The scorer owns the actual query cache, actual boosted weight, postings reader,
norm reader and selection context. Its clone shares the immutable Arc and copies
the numeric block cache only with the identical owner binding; later cursor
movement clears each clone's cache independently. The current production
selection binding is construction-only. This design makes no mutable-rebinding
safety claim: adding that feature later must replace the envelope and clear the
numeric cache together. Ordinary cursor reset changes postings and clears the
numeric cache; a reset crossing fields/segments must not preserve an old trusted
owner binding. Check actual reset callers rather than assuming a reset of raw
postings certifies new provenance.

Public differing-weight/norm calls ignore the fixed cache even if populated and
must not populate it even for a loaded tail. They do not see the envelope. A
custom statistics provider forwarding a native snapshot can be mathematically
eligible under the actual reader/cache contract; the native enum is not proof
of provider identity. Arbitrary public TermScorer construction, legacy selection
and untagged statistics cannot confer this private certificate.

## Build and lookup pseudocode

```text
native_input_bounds(actual fixed owner):
  enforce existing native_selection_context gates, including actual boosted w
  classify ALL256 q entries:
    +0 -> exact ratio zero
    positive finite (normal or subnormal) -> finite-ratio candidate
    +infinity -> retain a +infinity ratio sentinel
    -0 / negative / -infinity / NaN -> reject entire build
  if no +infinity: use unchanged B1 finite build, or Global in standalone B2
  reconstruct ALL256 old_a at ORIGINAL reader selection average
  reject any old_a that is nonfinite or <=0
  verify old_a[0] >= old_a[1] >= ... >= old_a[255]
  reject on any reversal; never binary-search a presumed ordering
  running = 0
  for n from 255 down to 0:
    r = 0 if q[n] is +0
        +infinity if q[n] is +infinity
        nextup64(RN64(exact_promote(q[n]) / exact_promote(old_a[n]))) otherwise
    validate finite-ratio result positive finite
    running = max(running, r)  // values already validated, no NaN discard
    suffix_ratio_up[n] = running
  publish immutable feasible envelope

input_upper(selected pair):
  M = RN32(F(selected_tf_ceiling) * old_a[selected_norm])
  reject M<=0, NaN, +infinity or f32::MAX
  i = lower_bound over descending old_a for FIRST old_a[i] <= M
      // search predicate old_a[mid] > M, never >= M
  if i == 256: reject as inconsistent metadata
  R = suffix_ratio_up[i]
  if R == +infinity: global for this block, retain envelope for later blocks
  if R == 0: C = +0
  else:
    U = exact_f64(nextup32(M))
    V = nextup64(RN64(U * R))
    C = nextup32(RN32(V))
    reject nonfinite V / invalid result; C=+infinity means global
  return C

private block bound:
  keep StoredDefault first and unchanged
  safety-check weight/normalization before metadata or numeric cache
  retain unloaded/global and loaded/literal VInt policy
  build pending only on full nonzero selected-pair request
  for NativeFeasible, consult fixed numeric cache, then input_upper(pair)
  finite C -> min(global_w, max(0, literal w-w/(1+C))), cache and return
  otherwise complete-block global fallback without decoding
```

The selected norm itself must satisfy old_a[selected_norm]<=M because its
decoded TF ceiling is >=1. Thus an empty feasible set is impossible for a valid
positive certificate. Treat it as a conservative runtime rejection, with a
diagnostic assertion in tests, rather than returning zero.

## Proof obligations and exceptional domains

Use IEEE binary32/binary64 nearest ties-to-even with gradual underflow and the
unchanged literal operation order. This design does not authorize FTZ/DAZ,
fast-math reassociation, approximate reciprocals, a different cache formula or
using exact integer TF as an f64 operand. Let F(t) be the actual u32-to-f32
conversion. All query and old entries are their stored rounded f32 values.

**Serializer certificate.** For every actual posting `(n,t)` in the complete
block, let `A(n,t)=RN32(F(t)*old_a[n])`. Positive finite old entries and t>=1
make all writer comparisons ordered, including +infinity from overflow. The
native comparator selects a maximal A. The pair carries that selected norm and
TF; byte255 ceilings only that selected TF with u32::MAX. Monotone u32-to-f32
conversion, multiplication and rounding give
`A(n,t)<=A(selected,actual_tf)<=M` for every posting. No independent TF maximum
or norm minimum is present or required. If selected actual input overflowed,
the decoded ceiling also produces infinity and the cheap path rejects M.

F(u32::MAX)=2^32 as binary32. F(2^24+1) can equal F(2^24), but conversion is
nondecreasing; it need not be strict. TF255 never supplies an upper bound on
another posting's TF. Repeat coverage for TF1/254/255/256/2^24±1/u32::MAX. The
proof applies to integer term frequencies >=1, not fractional phrase frequency,
TF0, arbitrary impact streams or synthetic expressions with changed operation
order. Generic serializer fixtures may have TF exceeding fieldnorm or norm0;
there is no no-overlap/TF<=length assumption.
`PostingsSerializer::write_doc` itself accepts a u32 without proving every
supplied TF positive. A nonzero selected-pair TF proves only that pair's TF,
not every fixture input's TF. Eligibility therefore retains the production
term-postings positive-frequency contract already stated by safe score bounds;
the future serializer gate must inspect all actual fixture frequencies and
reject unsupported TF0 experiments, not mistake the accessor for that proof.

**Feasible norms.** F(t)>=1, so exact F(t)*old_a[n]>=old_a[n]. Monotone RN32 and
the representability of old_a[n] imply A(n,t)>=old_a[n], even at positive
subnormal old entries. Combining with A(n,t)<=M yields old_a[n]<=M. This uses
rounded M directly for feasibility, not inflated U. Exclusion is valid only
for old_a[n]>M. Using U in the lookup is conservative but can unnecessarily
retain additional infinities; using a next-down M is unsound.

The concrete required witness is selection average3: norm0/TF1 and norm1/TF2
tie at old input bits40555555. With query2.5/1, norm0 has q=+infinity and score
global w. The selected pair can be norm1/TF2. Here M=old_a[0], so the entire
equal threshold group, including norm0, is feasible. The search must choose the
first equal entry. Neither selected_norm!=0 nor M<=old_a[0] excludes norm0.

**Actual old ordering and duplicates.** Fieldnorm's decoded integer table is
nondecreasing. Its f32 conversion is nondecreasing. For DEFAULT and a positive
finite selection average, the literal normalization uses fixed positive
constants and monotone rounded multiplication/division/addition, so its positive
denominator is nondecreasing and reciprocal is nonincreasing. Overflow can
produce old_a=+0, which is outside this candidate's domain. f32 rounding can
produce many equal old entries even where decoded norms differ; do not infer
strict order. Validate every actual positive finite old entry and every adjacent
descending relation at build time. This cheap check makes binary-search order a
property of the published envelope rather than a future-maintainer assumption.
The full table stores duplicates as-is; first-<= search includes all equals.
If ordering changes in a future cache implementation, fall back instead of
silently sorting/reinterpreting provenance in this experiment.

**Finite ratio enclosure.** For finite q>0 and old_a>0, exact promotion loses
no bits. `nextup64(RN64(q/old_a))` bounds the exact ratio. Ratios of positive
binary32 values lie between about 2^-277 and 2^277, safely inside normal f64.
q=+0 contributes exact zero. `R=suffix[i]` bounds every feasible posting's ratio,
regardless of whether q ratios or score maxima are monotone with norm ID.

For finite 0<M<f32::MAX, RN32(p)<=M implies exact p<nextup32(M), including
subnormal rounding cells. Consequently each feasible exact query product
F(t)*q[n]=(F(t)*old_a[n])*(q[n]/old_a[n])<U*R for R>0. One outward next-up after
the f64 multiplication bounds the represented product; its conservative full
binary32 range is safely within f64 normal exponent limits (roughly
2^-426..2^405). One outward next-up after the binary32 cast bounds V and hence
the actual rounded query input. Cast overflow gives +infinity/global, never a
finite underestimate. R=0 proves all feasible q are +0 and gives exact C=0.
Retain M0/maxfinite/infinity rejection to reuse the independently reviewed B1
rounding chain; expanding those domains is a separate hypothesis.

**Infinite query entries.** r[n]=+infinity requires no division. Its infinity
propagates into every suffix including n, and disappears only when n lies before
the first eligible index. With several infinity entries every one must be
strictly excluded. Equivalently a finite answer requires
`M < H=min(old_a[n] where q[n]=+infinity)`; the full suffix table encodes this
condition without a separate H guard or hardcoded norm0. If all q entries are
infinite, every valid selected pair leaves at least its norm feasible, so no
finite bound is possible. It is safe to reject that cache before allocating.
q infinity means an actual positive integer TF has infinite native input and
literal score w; allowing a finite bound while such a norm is feasible fails.

**Exceptional classification.** Reject old +0/-0/negative/infinity/NaN anywhere
before trusting the writer maximum or dividing. An old zero cannot simply be
discarded: its rounded product may be zero for arbitrary TF while q>0. Reject
query NaN/negative/-infinity/-0 globally rather than trying to rescue infeasible
exceptional norms. Negative zero could admit a separate constant-input proof,
but this extension preserves the finite B1 contract. Positive subnormal old/q
entries are valid if actual old reconstruction/order and arithmetic checks pass.
Query +0 and finite caches generated by normalization overflow retain their
explicit meanings; old normalization overflow rejects this build. Positive
finite averages alone do not prove every old entry positive. Invalid averages,
nonpositive k1, negative/zero/nonfinite actual boosted weights, unsafe scoring,
legacy provenance and DEFAULT use the existing policy and avoid B2 setup.
This rejects unsupported arithmetic rather than changing document scoring.

**Score enclosure.** For fixed finite w>=0 and x>=0, RN32(1+x) is positive and
nondecreasing; RN32(w/denominator) is nonnegative and nonincreasing; rounded
subtraction w-quotient is nondecreasing. Thus the literal native score at C
covers every literal score at the actual input. Use the actual post-boost w;
no tf factor reassociation, second frequency multiplication or second boost.
Clamping to zero and capping by independently valid global w are safe. A loaded
NaN domain retains existing infinity handling rather than relying on f32 max
discarding NaN. This entire chain requires an independent exact final-score
gate; local algebra alone is not runtime acceptance.

## Full table versus compressed dominance breakpoints

Recommend the full256 table as the reference implementation and initial B2
candidate. The cold builder is linear, lookup has at most nine comparisons over
256 entries, and it exposes a simple all-code oracle contract. Do not add both
representations or an adaptive strategy to production in the first hypothesis.

| Representation | Build | Hot query for a new complete block | Retained numeric payload, excluding owner/allocator overhead |
|---|---|---|---|
| Full256 descending old + suffix | 256 old reconstructions, 256 classifications, <=256 finite f64 divisions, adjacent-order check, one reverse max pass; no sorting | First old_a<=M binary search, then one suffix load; infinity returns global before further rounding/score work | Existing old cache1024 bytes + suffix2048 bytes =3072 bytes |
| Compressed dominance breakpoints | Same validation/ratio work, then equality grouping and reverse traversal/prefix maxima; monotonic old order avoids sorting | Last threshold<=M among K rows; zero when below first stored positive transition; +infinity is an ordinary dominating transition | Existing old cache1024 + K*(4+8)=12K numeric bytes; typical `{f32,f64}` row padding makes16K bytes |

A compressed table stores R(M), not just every changed ratio in norm order.
Traverse old indices from255 toward0 (thresholds ascending), group every equal
f32 old threshold first, and add that group's maximum ratio to the running
maximum. Emit a row `(threshold, running)` only when the running maximum strictly
increases; +infinity emits one transition and dominates all larger thresholds.
All-zero groups may be omitted with a base value0. Last emitted threshold<=M
then produces exactly the full table's R for every possible M. If a duplicate
group contains both finite and infinite entries, the group must emit infinity
at that same threshold; dropping rows before grouping can hide the infinity at
equality. Never lower a threshold, approximate a ratio, or compare epsilon
differences to decide dominance.

For infinity-containing monotone caches there may be few dominant transitions,
but no claim of small K follows from a cache profile name. Tiny k1 can yield
several infinite entries; arbitrary eligible finite entries can yield K=256.
With ordinary padded rows, K=256 costs4096 table bytes, twice the full suffix
array. Two packed numeric arrays cost3072 bytes at K=256, still larger than the
2048 suffix, require lengths/offsets and more complicated construction. A
temporary 256-row Vec later truncated retains its initial capacity; counting
logical rows understates allocation. `shrink_to_fit` may reallocate/copy and is
not a guaranteed exact-size allocation. A two-pass construction can count K then
allocate exact rows, at the price of another pass and perhaps retained temporary
ratios. These are concrete costs to measure before proposing compression.

Dominance compression is a separate representation trial after full B2 proves
useful. Its independent oracle must demonstrate identical R/C/bound bits at all
distinct old thresholds and immediate f32 neighbors, including every equality
group. It can reduce cache footprint and binary-search probes for small K, but
may add branch/load costs and worsen cold allocation. A scalar threshold H plus
one constant finite R is cheaper and safe with strict M<H, yet loses exclusion
of finite low-norm ratios; retain it as an offline diagnostic comparison, not
a simultaneous production policy. A 256-entry linear per-block ratio scan is a
sound oracle but puts cold O(256) work on the hot path. Adding independent TF/norm
extrema or index bytes is outside this same-format hypothesis.

## Runtime reach and honest cost controls

The initial BlockSegmentPostings open loads its first block
([block_segment_postings.rs:156](../tantivy-pr2937/src/postings/block_segment_postings.rs#L156)).
B2 cannot retrospectively save that decode. Later
[seek_block](../tantivy-pr2937/src/postings/block_segment_postings.rs#L415) and
[advance_skip_only](../tantivy-pr2937/src/postings/block_segment_postings.rs#L526)
advance skip metadata and clear the numeric cache without loading postings.
The proposed lookup uses only that metadata plus immutable arrays.

Single-term TOP enters
[block_wand_single_scorer](../tantivy-pr2937/src/query/boolean_query/block_wand_union.rs#L297)
through [TermWeight pruning](../tantivy-pr2937/src/query/term_query/term_weight.rs#L118),
checking the bound before seek loads a retained block. Union WAND performs
[seek_block then block_max_score](../tantivy-pr2937/src/query/boolean_query/block_wand_union.rs#L242)
before alignment/decode. Block-WAND intersection performs
[window-bound checks](../tantivy-pr2937/src/query/boolean_query/block_wand_intersection.rs#L93)
before loading the leader and can also use tighter secondary bounds in its
candidate filtering. Preserve current score-sum upper arithmetic and strict
collector comparisons; this design changes only per-term certificate values.
Small direct intersections and two-term fast routes can bypass block-bound
calls; their lack of setup is a runtime gate, not an inferred universal claim.

Every successful finite new-block B2 lookup adds a selected-pair read, f32 TF
conversion/product, <=9 binary-search comparisons/probes, suffix load, outward
rounding operations, one f64 multiply and native add/divide/subtract. It saves
decoding/scoring only if that smaller bound rejects work at the actual collector
threshold. Repeated successful requests on one block hit the existing numeric
cache. Ineligible full blocks can repeat the search if global is left uncached;
measure this rather than hiding it. No per-posting lookup or ratio division is
introduced.

Cold B2 work is O(256) per activated scorer/segment, with old f32 normalization
division/reciprocal work plus <=256 f64 ratio divisions and reverse maxima.
Without sharing, many terms/segments duplicate it. There is no global mutable
interning cache in this hypothesis. Clones share an already-built envelope;
clones of PendingNative can independently build if each activates later.
All-infinite or invalid queries can fail before old allocation. For a first
valid pair that already retains infinity, building the full table still costs
work; do not promise lazy setup fixes small bound-using queries.

On a conventional64-bit target, retaining existing `Arc<[f32;256]>` construction
costs one old-cache allocation with1024 numeric bytes plus Arc header; the new
envelope Arc holds an8-byte old-cache pointer and2048-byte suffix, plus its header.
Illustrative total requested storage is about 3112 bytes (1040+2072), before
allocator rounding and metadata, versus about 1072 for B1's old-cache plus
16-byte payload envelope. These are layout estimates, not measurements. No
additional suffix heap allocation is required when suffix is inline inside the
new envelope Arc. The temporary builder may use roughly2KiB stack scratch;
compiler placement/copies must be inspected, not asserted allocation-free from
pseudocode. Record actual sizes, allocations, allocated capacity and peak RSS on
the chosen release target after timing exclusivity ends.

Adding a single Arc variant should preserve the current compact enum/scorer
shape, but Rust layout is not guaranteed; verify actual release sizes rather
than importing debug-layout numbers from the B1 review. DEFAULT performs no
old-cache/suffix construction, but branch layout, code size, enum discriminants
and instruction-cache placement can still regress it. COUNT, exhaustive scoring
and routes that do not request complete-block bounds should show zero B2 builds,
zero lookups and zero extra index reads; they remain measured controls.

No writer/codec/format change, new metadata or index bytes. The immutable
format11 aligned pair is reused. Read-memory and query CPU costs count toward
efficiency even with identical index size. Brief observations include k09
small-query6–11% regressions and DEFAULT regressions despite identical counters;
they prohibit claims of regression-free behavior based on counter equality.
The k25 B1 TOP ratios near1 and its b1 rejection provide no B2 speed evidence.
Root's fresh report during this design adds unchanged-Lucene k09 TOP
Tantivy/Lucene1.000555 in the first order: aggregate parity, not a demonstrated
win. DEFAULT TOP reports .480675/.490635 in both orders. The finite candidate's
paired-target improvement is about29.5%, with about2.2–2.4% DEFAULT cost. These
are root-reported ongoing ruler observations, not measurements by this design
worker or final acceptance. B2's future b1 result cannot erase the remaining
finite-profile/per-query efficiency gaps or establish the user's all-API goal.

## Concrete independent and runtime gates

The next implementation proceeds only after root's current serialized timings
end. Freeze its exact source/binary configuration before acceptance; none of
these gates was executed for this design.

1. **Independent exact arithmetic.** Separately written rational IEEE32/IEEE64
   quantization oracle must derive actual old/query caches, writer maximum,
   selected TF ceiling, M, all feasible norms, R, U/V/C and literal bound. It
   must scan all256 norms directly for expected R rather than reuse candidate
   suffix, search or compression helpers. A second independent review must
   check the rounding chain and quantizer, not merely call the same helper.
   Require exact bit comparisons for accepted arithmetic and score<=bound for
   every actual posting; explicitly record rejected unsupported cases.
   Then a separate compiled probe of the frozen production private builder,
   `input_upper`, and actual `Bm25Weight::score` must match retained independent
   M/R/C/bound bits and coverage. Use root's exact native release configuration,
   including target-cpu=native, its LTO/optimization/overflow policy and ordinary
   release debug assertions; keep test assertions active and probe code out of
   timed binaries. Debug-only arithmetic or an oracle calling its own helper
   cannot replace this compiled gate. Builds/probes wait for timing exclusivity
   to end.
2. **Threshold exhaustiveness.** For each cache pair, query all distinct old_a
   thresholds, next-down/next-up neighbors, and the selected M values. Cover
   first/last eligible index, singleton/full/empty synthetic sets, duplicate
   groups straddling a hypothetical wrong index, infinity at every norm ID,
   several separated infinities and all-infinite arrays. The key witness is
   avg3 norm0/TF1 + norm1/TF2 tie bits40555555, with the maximizing selected norm
   not0; M=H returns global and immediate M<H excludes the exceptional group.
   Classify synthetic cache mutation probes as synthetic, not normal corpus
   occurrences. Actual constructors must also produce b1 and inverse-overflow
   configurations with all256 entries accounted for.
3. **Arithmetic extremities.** TF1/254/255/256/2^24±1/u32::MAX; selected TF255
   expansion; changed selection/query averages and changed query maximizer;
   +0/subnormal q, positive subnormal old, old zero from overflow; q -0/negative/
   infinities/NaN at every ID; reversed old order rejection; q cache plateaus;
   M0/maxfinite/infinity; f32 cast overflow; ±0/nonpositive k1; invalid averages;
   actual boost0/-0/negative/subnormal/huge/infinite/NaN. Retain local downward
   witnesses for old product (a bits3f800001, TF5), f64 ratio1/3, f64 multiply
   `(1+2^-23)*nextup64(1)`, and f32 cast of `1+2^-25`; local witnesses motivate
   outward steps but are not substitutes for end-to-end coverage.
4. **Real serializer witness.** Use native `PostingsSerializer` with controlled
   norms/TFs, both Dense and FOR, two complete128-posting blocks plus a tail.
   Inspect actual pair membership, selected norm, TF ceiling and actual old
   rounded maximum before trusting coverage. Test a strict-excluded fixture
   with only higher norm IDs at TF1 so q infinities are excluded and a finite
   bound is useful; separately test norm0 present, equality tie, multiple
   inverse-overflow norms, selected byte255, unrelated larger TF on another
   posting and changed maximizer. Do not assume text writer prohibits norm0 or
   enforce TF<=fieldnorm in the generic fixture. Check loaded first block and
   shallow-selected unloaded second block; asserting scalar helper coverage
   alone does not prove pre-decode reach.
5. **Actual pruning and ownership.** Choose a threshold strictly between a
   useful B2 bound and w, verify later full block is skipped with zero decode
   and zero actual term score calls, then compare exhaustive results. Check
   bound before/after load, same-block repeated request, seek-block/seek/advance/
   skip-only/reset invalidation, clone divergence, tails, absent metadata and
   legacy tags. Have a high-weight owner populate its bound, call public low
   weight/different norms, then request owner again; coverage and owner bits
   remain intact. Repeat in reverse order on a loaded tail, where foreign
   public reduction must never populate the owner cache. Ensure one global
   infinity-containing block does not disable a later useful feasible block.
6. **Full behavioral and runtime controls.** Preserve required native/legacy
   suites, frozen330, integrated normal fixtures, all three Wiki20 strict gates
   and all1913 common raw-score bit comparisons. Scores, counts, top-ten sets,
   ties and collector comparisons are unchanged. In a separate instrumented
   untimed executable record per-profile/per-query/per-route builds, lookup
   calls/cache hits, eligible-index histogram, feasible infinity/global counts,
   finite R/C/bound distributions, complete-block decode counts, actual term
   score counts and allocations. DEFAULT/COUNT/no-bound routes must show no B2
   arithmetic activation. Do not instrument timed executables.
7. **Serialized efficiency acceptance.** With root's exact unchanged Lucene
   ruler, compare the frozen baseline and B2 serially in both execution orders,
   existing CPU/warmup/sample policy, same immutable inputs and user background
   load, and no concurrent own CPU jobs. Verify artifact identities outside the
   timing window. Report all per-query results plus aggregate TOP/COUNT,
   DEFAULT, k09 and k25, setup/allocation costs and memory. Accept only a k25
   improvement beyond measured noise with required controls preserved; an
   aggregate win cannot hide the stated per-query efficiency target. More
   skipped blocks alone is insufficient. If few blocks strictly exclude
   infinities, bounds saturate, or table cost exceeds decode savings, reject
   this mechanism rather than weaken the proof or silently change the ruler.

## Module map, alternatives and complete revert

| Module | Narrow proposed change |
|---|---|
| query/bm25.rs | Add private feasible-envelope build/validation/search and use existing score-at-input helper. Preserve B1 finite arithmetic where accepted. |
| query/term_query/term_scorer.rs | One private Arc variant and one lazy dispatch branch; owner contract remains construction-only. |
| postings/block_segment_postings.rs | Private fixed-owner feasible entry, preserving existing safety, full/global and tail/cache rules. |
| Existing bound/serializer test modules | B2 arithmetic, actual codec and runtime/owner witnesses after design acceptance. |
| postings/skip.rs, serializer.rs, term_weight.rs, Boolean WAND | Existing production pair/access/provenance/callers should require no behavior or format changes. |

Rejected shapes: rescoring the selected old pair under query parameters; TF255
as an independent block maximum; corpus-derived exclusion of norm0; assuming
query average equals physical selection average; strict-monotone old thresholds;
binary search choosing a later equal entry; pruning infinities with M<=H; ratio
max over only finite entries without excluding every infinity; nearest-only
rounding; q formula recomputation; phrase/fractional frequency generalization;
query-wide/global cache interning; added index bytes; using DEFAULT counter
equality as proof of unchanged latency. Each either violates a proven contract,
broadens this hypothesis or introduces unmeasured lifetime/CPU costs.

Synthesis decision: full256 actual descending old cache + suffix ratio array,
including infinity sentinels, is the reference shape. It has linear cold setup,
bounded transparent binary lookup, no sorting and an exact direct-scan oracle.
Compression is the optional later memory/lookup trial, not the basis for claiming
initial speed. Preserve finite B1 constant-R dispatch and DEFAULT first branch;
the new arithmetic policy reaches only the currently rejected infinity cache
domain. Root remains free to prefer another arena design if its complete cost
and proof are better.

Ship as one independently reversible B2 change after baseline selection. Revert
the new private envelope/build branch/variant/cursor entry and B2-only fixture
hooks together to return precisely to the chosen baseline. No index migration,
reindexing, byte changes or cleanup of shared caches is required. Retain the
accepted public fixed-owner cache fix and independent evidence artifacts. If
B1 was reverted, the standalone B2 revert restores e133 behavior rather than
leaving unaccepted finite transforms behind. This package is a complete design
hypothesis; implementation, correctness and performance verdicts remain future
work under root's serialized acceptance plan.
