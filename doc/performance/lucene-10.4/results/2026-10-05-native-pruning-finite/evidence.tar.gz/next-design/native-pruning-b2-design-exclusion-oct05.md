# B2 candidate: strict exceptional-norm exclusion, one scalar gate

Design only, October 5, 2026. Repository: `/home/pronsh/Coding/playground/search/tantivy-pr2937`. Grounded in the complete [arena brief](native-pruning-b2-arena-brief-oct05.md), current b50 source, its bound/serializer fixtures, and the prior finite-transform design and independent review. No implementation, builds, tests, hashes, worktree operations, profiling, or timing jobs were performed. Only this assigned package was written. Workflow investigation and caller-first architect guidance were used inside the parent's design arena. Ground and sketch are complete; implementation is deferred by the explicit read-only contract.

throughput checkpoint: n/a, read-only investigation

## Caller usage first

```rust
// Existing production caller; sketch only, not implemented here.
let mut scorer = TermScorer::new(postings, fieldnorms, query_weight.boost_by(boost))
    .with_stored_block_max_selection(reader_selection_average, reader_selection_tag);

scorer.seek_block(target);             // may leave this complete block unloaded
let bound = scorer.block_max_score();  // existing WAND/TOP caller signature
// Existing collector decides whether bound is competitive.
```

No caller learns which norm is exceptional, provides a guessed TF maximum, or changes scores. Trusted nondefault native scorers lazily build one immutable envelope on their first complete-block bound request with nonzero selected-pair metadata. A b=1 block may use the existing finite-input arithmetic only after proving `M < H`. Otherwise it receives the existing global bound. Tails keep the existing loaded literal reduction/unloaded global policy. DEFAULT stays the first dispatch branch. No bound request means no old-cache construction, ratio divisions, or envelope allocation.

The public `cursor.block_max_score(&other_norms, &other_weight)` remains uncached and untrusted. It cannot consume or publish the owning scorer's numeric block cache. Public `TermScorer::new` alone does not confer selection provenance. Phrase/fractional-frequency scoring does not receive this certificate.

## Judgment and the independently measurable hypothesis

**Recommend this as the smallest conditional next probe, not as a promised b=1 performance solution.** The strict exclusion proof is sound and adds only one scalar comparison to B1's hot transform. It deliberately uses a global ratio over finite query entries, including finite norms that this particular block cannot contain. That can be very loose for b=1. Integration is conditional on the parent's unchanged Lucene ruler and the finite B1 keep/revert decision. If the gate rarely succeeds, or successful gates still round to global/never reject competitive blocks, reject this candidate rather than treating finite bounds as a speed win.

The single hypothesis is: *among actual b=1 complete-block requests, enough stored DEFAULT maxima lie below every exceptional norm's minimum possible old input, and the remaining global finite ratio is tight enough to save more decoding/scoring than its lazy setup and per-block check cost.* No format change, corpus-specific norm assumption, richer table, score rewrite, collector change, or unrelated optimization belongs to this probe.

If B1 is retained, compare B2 directly against retained B1 and separately show its relation to e133. If B1 is reverted, do not describe the scaffolding/setup/layout costs as inherited or free: the B2-only experiment must include them versus e133, retain finite profiles' prior policy, and still pass DEFAULT/COUNT controls. Do not silently reintroduce the rejected finite-profile mechanism under a b=1 label.

## Source grounding and runtime reach

| Constraint | Actual source evidence |
|---|---|
| DEFAULT normalization is literal f32 `k1 * (1-b + b*fieldnorm/average)` and native cache is its rounded reciprocal. | [bm25.rs:169](../tantivy-pr2937/src/query/bm25.rs#L169), [bm25.rs:196](../tantivy-pr2937/src/query/bm25.rs#L196) |
| Writer chooses a real pair maximizing rounded `F(TF)*old_a[n]`; it may resolve rounded ties to either maximizer. It chooses after either Dense or FOR document encoding. | [serializer.rs:528](../tantivy-pr2937/src/postings/serializer.rs#L528), [bm25.rs:676](../tantivy-pr2937/src/query/bm25.rs#L676) |
| Native selection tag and original physical selection average are explicit; native average uses f64 division followed by f32 cast. | [field_statistics.rs:17](../tantivy-pr2937/src/index/field_statistics.rs#L17), [field_statistics.rs:93](../tantivy-pr2937/src/index/field_statistics.rs#L93), [serializer.rs:126](../tantivy-pr2937/src/postings/serializer.rs#L126) |
| TF255 decodes to u32::MAX. The ceiling covers the selected posting only. Dense and BitPacked expose pairs; VInt tails and zero TF do not. | [skip.rs:67](../tantivy-pr2937/src/postings/skip.rs#L67), [skip.rs:163](../tantivy-pr2937/src/postings/skip.rs#L163), [skip.rs:178](../tantivy-pr2937/src/postings/skip.rs#L178) |
| The same field's reader/postings/norms bind the actual post-boost weight before installing private policy. | [term_weight.rs:180](../tantivy-pr2937/src/query/term_query/term_weight.rs#L180) |
| Lazy envelope activation reads skip metadata without decompression. The private complete-block envelope path never calls load_block; failed enclosure returns global. | [term_scorer.rs:126](../tantivy-pr2937/src/query/term_query/term_scorer.rs#L126), [block_segment_postings.rs:220](../tantivy-pr2937/src/postings/block_segment_postings.rs#L220) |
| Public changing-weight evaluation does not read/populate fixed-owner cache; seek/reset/advance/skip-only advancement invalidate numeric results. | [block_segment_postings.rs:165](../tantivy-pr2937/src/postings/block_segment_postings.rs#L165), [block_segment_postings.rs:277](../tantivy-pr2937/src/postings/block_segment_postings.rs#L277), [block_segment_postings.rs:414](../tantivy-pr2937/src/postings/block_segment_postings.rs#L414), [block_segment_postings.rs:526](../tantivy-pr2937/src/postings/block_segment_postings.rs#L526) |

Actual B1 rejects any nonfinite query cache before reconstructing old inverses, so ordinary b=1 currently pays no old-cache/ratio allocation. B2 changes that rejection. Its useful reach is the existing shallow/unloaded complete-block path, not an exact maximum calculated after decoding. Initial open currently loads the first block; a second or later block reached through `seek_block` is the decisive pre-decode witness. Merely showing a smaller bound on the already loaded first block does not establish reach.

The native serializer fixtures already distinguish real Dense/FOR encodings, inspect selected pairs and TF255 expansion, and check an unloaded second block; their b=1 expectations currently remain global. Those are extension points, not evidence that B2 has run.

## Private data shape, signatures, and module map

No new module or exported API is needed. Extend the existing deep envelope in `query/bm25.rs`; retain scorer policy and cursor dispatch boundaries. The sole new persistent field is an exceptional old-input floor. Exceptional membership is cold transient state, not a per-scorer bitmap.

```rust
// Sketch only: signatures/pseudocode; no implemented bodies.
struct NativeInputEnvelope {
    selection_inverse: Arc<[Score; 256]>, // actual DEFAULT cache, all >0 finite
    ratio_up: f64,                      // max outward q/a among finite q
    exceptional_floor: Score,           // H; +inf means no exceptional q
}

impl Bm25Weight {
    pub(crate) fn native_input_envelope(
        &self,
        context: NativeSelectionContext,
    ) -> Option<NativeInputEnvelope> {
        // not implemented: preserve existing eligibility; classify all actual q;
        // reject NaN, -0, negatives/-inf; admit +inf as exceptional;
        // reconstruct/validate all old inverses at context's selection average;
        // fold H=min old[n] for q[n]=+inf;
        // fold R=max nextup64(q[n]/old[n]) for finite q[n]>0; +0 contributes 0;
        // no finite entries => Global is sufficient, do not retain an envelope.
        todo!("design only")
    }
}

impl NativeInputEnvelope {
    pub(crate) fn input_upper(
        &self,
        norm: u8,
        selected_tf_ceiling: NonZeroU32,
    ) -> Option<Score> {
        // not implemented: M = RN32(F(ceiling)*old[norm]);
        // reject M<=0, M==MAX, nonfinite M; reject unless M<H;
        // only now run unchanged B1 outward U/R/V/C enclosure.
        todo!("design only")
    }
}
```

`NativeSelectionContext`, `SelectedInputPair`, `TermBlockBounds` and all public signatures stay as currently shaped. `bm25.rs` owns cold validation and IEEE arithmetic. `term_scorer.rs` owns the immutable query/reader binding and lazy transition. `block_segment_postings.rs` owns per-block cache/fallback; `skip.rs` owns only codec pair decoding. Serializer/index metadata remain untouched. Tests belong in existing native bound, serializer transform, and term scorer fixture files if the parent selects implementation later.

Keep `Global/StoredDefault/PendingNative/NativeTransform` as exhaustive states. A failed cold build resolves permanently to Global for that fixed scorer; a failed per-block `M<H` test does **not** resolve the scorer permanently to Global because later blocks may qualify. Do not cache a global failure in a way that changes existing tail behavior. Successful numeric bounds remain per cursor/block. Calling the private binding setter twice is outside the verified construction-only caller contract; if that contract is broadened later, explicitly clear/reconstruct both policy and numeric state.

## Supported domain and exact proof

Write `a[n]` for the actual DEFAULT native reciprocal cache at the reader's selection average, `q[n]` for the actual immutable query cache, and `F(t)` for the actual u32-to-f32 conversion. RN32/RN64 are nearest ties-to-even with gradual underflow and the current literal operation order. No real-valued surrogate normalization, approximate reciprocal, reassociation, or FTZ/DAZ is allowed.

Existing context eligibility remains: native nondefault scoring, actual native input-selection tag, k1 strictly positive, both averages finite/positive, existing safe-score predicate true, and actual boosted weight finite/positive. Positive subnormal weight qualifies; ±0, negative/nonfinite weights and ±0 k1 retain existing fallback. DEFAULT, including average mismatch, retains existing policy. A forwarded native field-statistics snapshot may satisfy mathematical native eligibility; ordinary public classic constructors do not. Eligibility is not a claim about provider identity.

All 256 old entries must be strictly positive and finite. An old zero caused by overflow at tiny selection averages makes reconstruction ineligible; this probe does not invent an exclusion proof for zero old denominators. All 256 actual query entries are classified: finite nonnegative (+0/subnormal included), or exceptional **+infinity**. NaN, -0, negative values and -infinity reject the entire transform, rather than attempting local exclusion behind the existing unsafe-score guard. The E set is every +infinite query entry, including any nonzero norm codes whose literal normalization underflows. This is not a norm0-only special case.

1. The serializer selects `(n*,t*)` maximizing `RN32(F(t)*a[n])` over the complete block. Its decoded TF ceiling `c>=t*` gives `M=RN32(F(c)*a[n*])` at least that maximum by monotonicity. TF255's ceiling conversion is f32 **2^32**, not a f64 use of the exact integer 4294967295. An unrelated posting may have greater TF; no bound on that posting's TF is inferred from c.
2. Every actual matching integer TF has `t>=1`, hence `F(t)>=1`. Positive finite a and monotone RN32 imply `RN32(F(t)*a[n]) >= RN32(1*a[n]) = a[n]`. Therefore every norm actually present satisfies **a[n] <= M**. This is a rounded-input comparison; no epsilon or next-up belongs in its exclusion gate.
3. Define `H=min(a[n] : n in E)`; if E is empty, use +infinity. If **M<H**, each exceptional n has a[n]>=H>M and cannot occur. Equality cannot exclude it. Conversely failure of the strict gate proves no useful exclusion certificate, not actual exceptional presence; return global conservatively.
4. For all finite q define `r[n]=0` when q[n]=+0, otherwise `nextup64(RN64(f64(q[n])/f64(a[n])))`. Let R be their maximum. With exceptions proved absent, this global finite R covers all present norms. If R=0, all possible q are +0 and C=0 is safe.
5. For `0<M<MAX`, let `U=f64(nextup32(M))`. Any exact old product whose rounding is <=M is strictly below nextup32(M), so U encloses it. Let `V=nextup64(RN64(U*R))` and `C=nextup32(RN32(V))`. These enclose every actual rounded query input. f32 promotion is exact; finite f32 numerator/positive denominator ratios and the relevant products fit normal f64 range. +inf C yields global fallback. Retain all B1 M/overflow guards even if a synthetic scalar might admit a more complicated proof.
6. For fixed finite positive w, the literal function `S_w(x)=RN32(w-RN32(w/RN32(1+x)))` is nondecreasing for x>=0. Therefore `S_w(C)` bounds every actual literal native score. Clamp as the existing helper does and cap by independently certified global w. No algebraic TF-factor rewrite or extra frequency multiplication is allowed.

At ordinary b=1, norm0's literal normalization is +0, q[0]=+inf, and DEFAULT's a[0] is independent of the selection average because its zero norm contributes no length term. For k1=2.5 and normal caches, E={0}, so H=a[0]. Extremely small positive k1/exceptional caches can enlarge E; scan rather than assuming this set. If all entries are exceptional, every valid posting has old input>=H, so no actual block can satisfy M<H; resolve Global without retaining a transform.

The concrete equality counterexample is mandatory: selection average 3, norm0/TF1 and norm1/TF2 both have old input bits `0x40555555`. Here H equals M and b=1 norm0 scores exactly w. The selected pair can be norm1/TF2 after tie resolution; it does not prove norm0 absent. `M<=H`, `selected_norm!=0`, fieldnorm-positive corpus folklore, TF<=fieldnorm, or an assumption about token overlaps would each lose the certificate. Likewise fractional phrase frequency below one invalidates step 2; do not route phrase scoring through it.

## Usability compared with per-block feasible ratios

The H gate alone answers whether *any exceptional norm could be present*. It does not remove impossible finite norms from R. For b=1, the shortest positive fieldnorm commonly supplies the largest finite q/a. Blocks with `M<a[1]` rule that norm out too, but this candidate still uses its ratio. With large query average, that ratio can turn a small old M into a very large C, yielding a score close to w or identical to w after f32 subtraction. A finite score strictly below w may also be above every operative collector threshold and save no work.

For intuition only, disregarding rounding, b=1 gives `q(L)=Aq/(kq*L)` and DEFAULT gives `a(L)=1/(ko*(.25+.75*L/As))`. Their ratio is `(ko/kq)*(.25*Aq/L+.75*Aq/As)`. Its short-length term demonstrates why a ratio taken over all positive lengths can be much larger than the ratio over lengths a low-M block permits. This is not the eligibility proof, an actual cache result, or a performance measurement; every implementation ratio still comes from actual entries.

| Whole shape | Certificate and cost | Decision |
|---|---|---|
| Scalar H plus global finite R (this candidate) | Strict exceptions excluded; one M/H comparison, no search/table; can retain impossible short finite norms and be loose. | Conditional first probe, reject promptly if real competitive reach is poor. |
| H plus sorted old thresholds with prefix maximum finite ratios | For each M use `R(M)=max(r[n] : a[n]<=M)`; equal threshold keys must be grouped/included. Removes impossible finite norms with O(log 256) lookup. Cold sort/prefix scan; up to 256 steps. | Structurally stronger next hypothesis if H succeeds but scalar bounds saturate. Do not add it to this probe to rescue an unmeasured claim. |
| Per-bound scan of all 256 codes | Same feasible R(M), no persistent table. O(256) comparisons/ratio selection per fresh block. | Reject as the default hot path; it risks spending more than the decode being avoided. Can be a later diagnostic reference outside timed binaries. |
| Native writer/impact frontier or per-norm frequency metadata | Richer actual norm/TF feasibility; changes bytes, reader/writer contract and aligned artifacts. | Outside this same-format experiment. |

R(M) is never greater than global R, so the richer method offers demonstrably no looser input enclosures before rounding. Neither scheme can beat global on a genuinely present exceptional norm; H failure can still be false-positive because the stored pair is too coarse, particularly after TF255 expansion. The richer method does not repair lost information in the pair or saturated selected-TF ceiling.

## CPU, memory, allocation, and controls

Cold work is bounded by fixed 256-code loops: classify query cache, reconstruct literal old cache, validate old entries/fold H, and at most 256 outward f64 divisions/fold R. No sorting, index scan, document decoding, or query-time corpus statistics pass. Complexity O(256), once per qualifying scorer/reader binding. The first useless b=1 block may still trigger this cost. All-exception rejection should avoid retained allocation, but it is not a claim that every cold rejection is allocation-free. Existing old-cache constructor allocates its Arc; retain its actual provenance and account for temporary allocation on rejection.

On a 64-bit target, the current envelope's Arc pointer plus f64 is 16 payload bytes. Adding f32 H generally rounds that payload to 24 bytes: **8 extra heap payload bytes**, not 256 extra flags. One existing old-cache Arc holds 1,024 array bytes plus typically 16 bytes of Arc counters; one outer Arc holds envelope payload plus typically 16 bytes of counters. Expected retained allocations: two, around 1,080 bytes total for B2 versus 1,072 for B1, excluding allocator metadata/alignment. These are design accounting estimates, not measured layouts. `TermBlockBounds` still stores the same Arc pointer variant, so incremental B2 scorer inline size should be zero; verify target layout. Versus e133, B1's state already grew the scorer and was associated with DEFAULT regressions, so that baseline cannot be ignored.

Fresh successful hot bound: selected inverse lookup, f32 conversion/product, existing M guards, one extra f32 comparison, existing next-up/promote/f64 multiply/cast sequence, and literal score division/subtraction. O(1), no allocations or 256-code scan. Gate failure returns global before ratio multiplication and score division. A successful cached bound returns via the existing private cache. Compare cache-hit/gate-failure code generation too: a new cold field alone does not guarantee DEFAULT instruction/layout parity. Do not permanently disable a scorer after one gate failure.

For reference, 256 sorted richer steps laid out as `(f32,f64)` would commonly cost 4,096 extra payload bytes plus container/Arc allocation, with O(256 log 256) cold sorting and at most about nine boundary comparisons per lookup. A compact parallel-array representation could lower payload but changes ownership/interface complexity; neither is included here.

DEFAULT must perform no new classification, old-cache allocation, H test, or table lookup; exact DEFAULT dispatch stays first. COUNT/no-bound paths must allocate no envelope and perform no H/R work. Zero/negative weight domains keep existing fast fallbacks. These are runtime controls to verify, not promises of zero timing regressions. Prior B1 measurements show DEFAULT TOP ratios about 1.02 despite unchanged counters, and small k09 terms regress 6–11% from cold setup. A layout or cold-work change must be judged against those observations, not excused by unchanged document counts.

## Independent oracle and adversarial runtime gate plan

No checks below were executed for this design. Before performance acceptance, use an independent exact rational IEEE binary32/binary64 quantizer, not the envelope helper or a copy calling it. Construct actual caches with every literal rounded normalization operation and the actual query/selection average bits; independently derive E/H/R/M/C/bound. Required comparisons: every actual score<=bound, every present norm has a[n]<=M, and any finite b=1 transformed bound has M<H and no present exceptional code. Preserve exact document-score bits.

Concrete adversarial fixtures, using the real native serializer and actual Searcher-derived query weights where possible:

1. **Equality/tie:** repeat norm0/TF1 and norm1/TF2 at selection average 3 into 128/256-posting Dense and FOR blocks, varying order so tie-selected pair changes. Bound must remain w on loaded and unloaded complete blocks. Probe M's immediate representable neighbors around H in an independent scalar fixture; do not pretend every arbitrary M is writer-reachable.
2. **Positive b=1 reach:** proposed reuse of the existing [query_weight helper](../tantivy-pr2937/src/postings/serializer_native_transform_tests.rs#L11) with k1=2.5/b=1, selection average 3, and TF1 at the norm code obtained from fieldnorm 64; repeat into two complete blocks with Dense and FOR doc layouts. The helper's source writes two field-bearing documents containing respectively 321 `alpha` and 321 `beta` tokens, then constructs the weight from its Searcher. Source reasoning predicts physical field totals 642/2 and [native_average](../tantivy-pr2937/src/index/field_statistics.rs#L17) therefore produces exact f32 321, bits **0x43a08000**; this is a source-derived expectation, not a B2 execution receipt. The future fixture must assert the actual query average bits. Calculate expected rounded M/H/R/C independently rather than assuming length 64 round-trips exactly through the codec. Inspect the serializer's selected pair and old maximum directly. Seek to second complete block without loading it; require bound<w, unchanged unloaded state, and bound covering every literal score. Then load and re-request; bound/cache bits and score bits must remain valid. Separately cover other long norm codes and mismatched averages.
3. **Loose global R:** same long-norm blocks with a large query average, including query/selection mismatch. Show a feasible-norm diagnostic ratio smaller than scalar R, and record whether scalar bound rounds to w or stays above thresholds. This is the explicit reject/pivot witness; do not require this candidate to be tight on it.
4. **All 256 norms/TF extremes:** shifts across all codes; TF 1/254/255/256, 2^24-1/2^24/2^24+1, u32::MAX; include unrelated TF maximum versus selected posting, changed query maximizer, Dense/FOR and WithFreqs/WithFreqsAndPositions. TF255 must be observed expanding to u32::MAX and must not be treated as a block-wide TF bound. Keep positional-sum fixtures valid rather than accidentally overflowing their independent serializer sum contract.
5. **Exceptional cache classification:** ordinary norm0 +inf, multiple +inf due actual underflow, all +inf, finite +0/subnormals. Every code in turn with synthetic NaN/-0/negative/-inf must reject globally; label mutation-only probes as synthetic rather than normal writer occurrences. Tiny selection average with actual zero old inverse must reject. Both signs of zero k1, b endpoints, invalid averages, extreme finite weight/post-boost overflow, zero/negative/nonfinite boosts, M0/MAX/+inf and cast overflow preserve existing fallback. Exercise the all-finite E-empty branch with prior B1 vectors unchanged.
6. **Provenance/frequency boundary:** legacy/untagged/public serializer, missing fieldnorm metadata, zero pair TF, DEFAULT mismatch, ordinary classic custom provider, native-forwarded snapshot, and fractional-frequency scoring. Only trusted integer native term-posting routes activate; no on-disk bytes change. Matching-posting TF>=1 remains an explicit precondition, not a new promise about arbitrary zero-frequency public serializer input.
7. **Lifecycle/cache:** first loaded block, second shallow/unloaded block, seek across a failed H block to a succeeding block, advance/skip-only/reset, loaded/unloaded tail, clone before/after activation, alternate public weight and norm reader before/after private cache fill. A low-weight public call must not contaminate a later high-weight owning bound. Public calls ignore private cached values. Clones share immutable envelope only and invalidate their numeric cache independently on movement. Private binding remains construction-only.

Require actual complete-block pre-decode counters and strict optimized-versus-exhaustive TOP/count/tie results, unchanged normal/native/legacy gates, frozen330 and all three Wiki20/all common raw-score checks. Test M<H on real selected pairs; exact scalar arithmetic alone does not certify native codec/provenance reach.

## Runtime and performance acceptance, then complete revert

Parent owns serialized measurements; this agent launches none. After correctness and clean release gates, instrument a separate untimed build for each profile/query: complete-bound calls by loaded state/encoding, pending builds/rejections, retained/temporary allocation counts and bytes, H pass/fail, TF255 frequency, M/H bands, finite C versus saturated/global results, bound-to-w and bound-to-current-threshold bands, numeric cache hits, genuinely shallow skipped blocks, full decodes, actual term scores and WAND candidates. Distinguish *H passes*, *bound<w*, and *bound rejects current block*: only the last establishes competitive reach. One diagnostic feasible-norm scan can explain global-ratio looseness outside timed code.

Use the exact existing immutable aligned index/query pair, required release flags and unchanged Lucene ruler. Parent performs sequential paired baseline/candidate runs in both orders with the established warmup/sample/CPU/background policy, retains per-query results, and keeps other agent CPU jobs idle. No result is accepted by reusing old-layout timings. DEFAULT and COUNT are mandatory controls, including dense DEFAULT and small cold queries already known to regress. Include end-to-end cold query costs and allocated/read-RSS footprint; an aggregate b=1 win cannot hide violations of the user's all-query target. Repeat only when noise or an unresolved failure warrants it.

Reject this unit if H scarcely passes, scalar R mostly saturates/never competes, decoding/scoring reductions do not pay its setup, or required controls regress. If H passes but ratio looseness dominates, recommend the richer feasible-norm prefix envelope as a new independently measured hypothesis; do not quietly expand this unit. If selected-pair information itself dominates H failures, a richer same-format ratio cannot solve that and a format/impact design requires a separate ruler.

Revert completely by removing admission of +inf query entries, removing `exceptional_floor`, and removing the `M<H` gate; restore finite B1 cache classification and b=1-global fixture expectations. If the selected baseline is e133, revert all B2-owned pending/envelope scaffolding as well. No index rewrite, codec migration, metadata rollback, or score change is needed. Restore associated test/diagnostic additions and compare the retained baseline's unchanged counters/required gates. This scope offers one small private semantic change with a clear stop condition; it does not claim all Lucene API parity or a b=1 win without the ruler.
