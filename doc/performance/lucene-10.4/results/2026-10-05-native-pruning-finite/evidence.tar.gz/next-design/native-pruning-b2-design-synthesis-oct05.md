# B2 synthesis and next action — October5 local / October6 UTC

Root read all three complete packages and the complete fresh judge. Ground, Frame,
Fan out, Cross-judge and Pick are complete. Agree proceeds without a human gate.
There is no production B2 implementation to accept or scrap yet.

Root scores by the five brief criteria: exclusion5/4/4/5/4=22; feasible5/4/3/4/5=21;
TF-cap5/4/2/3/4=18. These agree with the judge. The smallest conditional base is
scalar strict exceptional-norm exclusion. It is not yet a warranted production
attempt: every design requires M<H, and one dense posting can make a whole block
fail that necessary certificate. No ratio/table/cap can overcome that lost
information. Root independently reached the same deferral from the source and
term-density mechanism; no empirical M/H distribution has yet been collected.

Graft from feasible: direct256-code expected-feasibility oracle, actual old-order
validation and equality grouping, independent compiled production-helper bit
checks, and explicit separation of finite B1 versus infinity-profile work. From
TF-cap: exact monotone integer-TF cap as an offline measure of the information
limit and explicit lookup/activation opportunity loss. Reject its16/64 production
heuristics until observed reach justifies their cost. Scalar's H/globalR can be
compared offline to feasibleR(M) first; choose a richer production base only if
it adds actual threshold-effective unloaded opportunities.

Next artifact is an observational diagnostic, not a production B2 policy.
Initially capture the eight actual Wiki single-term routes for k25 plus k09
controls: actual reader selection average/tag, actual query/old cache bits,
selected pair/TF255 ceiling, full-block loaded state, M/H and current exact live
collector threshold. Preserve original bound and predicate/control flow. Replay
H, scalarR and feasibleR over the same observed trajectory; do not call predicted
opportunities actual skips, or compare perterm bounds directly to Boolean sum
thresholds. This narrow diagnostic can reject B2 as a solution to costly dense
single-term losses without falsely asserting no rare/Boolean opportunity exists.
If singles show worthwhile reach, widen capture with the actual Boolean predicate
and all other contribution bounds before implementation. All probe code stays in
an isolated worktree/binary and never supplies timed or production bounds.

B1 final observed target improvement is about29.5% versus accepted e133 in both
orders. It also costs DEFAULT ranked2.2–2.4% and small k09 bound-using queries6–11%.
T/L main sequence: DEFAULT TOP.480675/.490635 with18/19 wins, k09 TOP1.000555/
1.034113 with10wins, k25 TOP1.368604/1.258441 with5/7wins. DEFAULT concern repeats:
accepted e13320/19wins, candidate b5020/20wins, so individual near-parity losses
vary with current user load; this does not erase paired DEFAULT cost. B1 is kept
as a bounded finite-profile improvement, never as completion of all-query/fullAPI
success. All three COUNT profiles20wins eachorder. Index bytes remain identical.

Verification remains conditional: observed input identities, root full diagnostic
source/runner review before build, untimed repeated protocol/counters/exhaustive
gates, independent arithmetic replay, and original-source branch unchanged.
After those facts choose production experiment or reject shared H mechanism.
No parameter/score/index/format/public API change belongs to the diagnostic.
