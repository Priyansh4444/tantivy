# B2 candidate: integer TF caps and a small query-input staircase

This is a design package, not an implementation or an accepted performance result. Its single hypothesis is that a **16-row, lazily activated integer-TF envelope** can restore useful pre-decode bounds for native 2.5/1 without paying a 256-norm scan on each block. It uses the existing format11 DEFAULT selected pair. It adds no index bytes and changes no literal document score. It deliberately returns GLOBAL on the first 63 distinct qualifying complete-block requests and constructs the table at request 64. That staging cost and table looseness may make this candidate lose; acceptance requires actual eligible-block distributions and the unchanged ruler.

The distinguishing operation is to infer an integer frequency ceiling separately for each feasible norm, then evaluate the actual rounded native query input at that frequency. It does not transform M by a maximum q/a ratio. The exact discrete maximum is the reference target; the production-shaped proposal uses conservative caps and upward breakpoint lookup.

## Caller usage first

```rust
// Sketch only; no bodies implemented.
let weight = query_weight.boost_by(actual_boost);
let mut scorer = TermScorer::new(postings, fieldnorm_reader, weight)
    .with_stored_block_max_selection(reader_selection_average,
                                     reader_selection_tag);

// Existing callers and score signatures are unchanged.
scorer.seek_block(target);             // can leave the complete block unloaded
let upper_score = scorer.block_max_score();
// upper_score can exclude this block before postings or norms are decoded.
```

DEFAULT stays the first existing dispatch branch. Tail-only, COUNT, MaxScore or direct routes that never request a complete bound do not build this table. Public `BlockSegmentPostings::block_max_score(reader, weight)` remains uncached, and never receives the trusted transform. A term scorer binds actual boosted weight, actual query cache, fieldnorm reader, native selection provenance and original selection average at construction. There is no mutable public certificate API.

Implementation is conditional on root's disposition of B1. If B1 survives, finite eligible caches keep B1's finite envelope; this candidate supplies only the previously rejected positive-infinity query-cache branch. If B1 is reverted, do not silently reinstate it: retain GLOBAL for finite nondefault caches and introduce this b=1 mechanism as an isolated candidate. Prefer an explicit native nondefault b=1 activation predicate for the first experiment; the proof also handles additional positive-infinity entries, but broadening accepted profiles is a separate decision.

## Workflow and evidence boundary

I used the workflow investigation playbook:

1. Trace the relevant source, configuration, and runtime path. For motivation questions, inspect the change history and rationale.
2. Throughput checkpoint stays one line: `throughput checkpoint: n/a, read-only investigation`. The four-item version is for code-shaped work.
3. Produce an evidence-backed explanation (Overview / Key Concepts / How It Works / Where Things Live / Gotchas), or a recommendation with a tradeoffs table if the request is a decision between alternatives.
4. Apply a plain-writing pass to the reply.

throughput checkpoint: n/a, read-only investigation

The source was read in the shared candidate checkout; there were no source edits, builds, tests, worktrees, hashes, timings or heavy CPU operations for this package. The foundational-thinking choice is to define the discrete admissible posting set before selecting an efficient enclosure. The subtract-before-you-add choice is to reject a hot per-norm solver and reuse the fixed-owner cache and selected-pair accessor.

Source grounding:

- [bm25.rs](../tantivy-pr2937/src/query/bm25.rs): actual f32 query cache, literal `w-w/(1+F(t)*q[n])`, native selection context, existing lazy finite input envelope and score-at-input helper.
- [term_scorer.rs](../tantivy-pr2937/src/query/term_query/term_scorer.rs): first DEFAULT branch, pending setup only for complete nonzero pair, immutable post-boost scorer ownership.
- [serializer.rs](../tantivy-pr2937/src/postings/serializer.rs): native max comparator after either Dense or FOR encoding; selects rounded DEFAULT input, then writes selected norm/TF only.
- [skip.rs](../tantivy-pr2937/src/postings/skip.rs): Dense/BitPacked complete metadata, VInt absence, TF255 expansion to u32::MAX and nonzero selected-pair accessor.
- [block_segment_postings.rs](../tantivy-pr2937/src/postings/block_segment_postings.rs): unloaded reach, fixed-owner numeric cache, public uncached evaluation, loaded-tail reduction and movement invalidation.
- [existing native serializer fixtures](../tantivy-pr2937/src/postings/serializer_native_transform_tests.rs) and [bound fixtures](../tantivy-pr2937/src/query/bm25_native_bound_tests.rs): existing certificate observations and arithmetic witnesses; their B1 b=1 rejection is not a B2 test.
- [independent finite review](native-pruning-finite-independent-review-oct05.md) and [candidate B](native-profile-pruning-design-b-oct05.md): prior evidence, strict-equality warning and immutable-owner boundary. Their passed finite oracle does not validate the new cap solver or staircase.

## Data and private signatures

```rust
const TF_CAP_ROWS: usize = 16;
const TF_CAP_WARMUP_BLOCKS: u8 = 64;

struct NativeTfCapWarmup {
    selection_inverse: Arc<[f32; 256]>, // actual DEFAULT selection-average cache
    infinite_min_old: f32,             // H = min a[n] over ALL q[n] == +inf
    min_old: f32,
    distinct_qualifying_blocks: u8,
    last_qualifying_last_doc: Option<DocId>,
}

#[derive(Clone, Copy)]
struct TfCapRow {
    old_upper: f32,                    // breakpoint B, includes equality
    query_input_upper: f32,            // max_n RN32(F(T_upper[n,B])*q[n])
}

struct NativeTfCapEnvelope {
    selection_inverse: Arc<[f32; 256]>,
    infinite_min_old: f32,
    min_old: f32,
    rows: [TfCapRow; TF_CAP_ROWS],
    row_count: u8,                     // duplicate breakpoints removed
}

// New private variants, preserving pointer-sized payloads if actual layout permits:
// TermBlockBounds::TfCapWarmup(Box<NativeTfCapWarmup>)
// TermBlockBounds::TfCapReady(Arc<NativeTfCapEnvelope>)

impl Bm25Weight {
    fn native_tf_cap_warmup(&self, context: NativeSelectionContext)
        -> Option<Box<NativeTfCapWarmup>>; // validate all caches, not implemented

    fn build_tf_cap_envelope(&self, warmup: NativeTfCapWarmup)
        -> Option<NativeTfCapEnvelope>;   // immutable table, actual q cache
}

impl NativeTfCapWarmup {
    fn observe_complete(&mut self, pair: SelectedInputPair, last_doc: DocId)
        -> CapObservation;               // Invalid / Global / Activate
}

impl NativeTfCapEnvelope {
    fn input_upper(&self, pair: SelectedInputPair) -> Option<f32>;
        // ceil-breakpoint lookup; None means existing GLOBAL
}

// Private pure helper; no profiler/codec dependencies.
fn conservative_integer_tf_cap(old_maximum: f32, old_inverse: f32)
    -> Option<NonZeroU32>;                // normative algorithm below

// Independent reference only, deliberately unsuitable for the block hot path.
fn exact_integer_tf_cap_reference(old_maximum: f32, old_inverse: f32)
    -> Option<NonZeroU32>;                // monotone binary search over 1..=u32MAX
```

Names and layout are provisional. There is no exported error type or generic enclosure framework. A failed domain becomes GLOBAL for the fixed scorer. A failed individual M or saturated row returns GLOBAL without poisoning tail reduction. `CapObservation` is a small local control enum, not persisted metadata.

The existing `score_from_native_input_upper` is reused unchanged: evaluate the actual boosted weight's literal expression, clamp contribution at zero and cap by the independently certified global bound. The table does not copy weight/IDF/boost or query cache; construction reads the owning weight's actual cache once.

## Exact discrete target and conservative cap proof

Let F(t) be the actual u32-to-f32 conversion, RN32/RN64 nearest ties-to-even with gradual underflow, a[n] the actual DEFAULT inverse reconstructed at the selection average, and q[n] the actual query inverse. Require every a[n] finite and strictly positive, every q[n] finite nonnegative or +infinity, and no negative-zero, negative, NaN or -infinity query entries. Require strictly positive k1, finite positive query/selection averages, native term scoring, native selection tag, positive finite actual boosted weight and safe score normalization. Reject both signs of zero k1; zero and negative weights need no setup. Unsupported domains keep existing fallback, including infinity where the existing global contract requires it.

The exact target is:

```
J(M) = { n : a[n] <= M }
T_exact(n,M) = max { t in [1,u32MAX] : RN32(F(t)*a[n]) <= M }
X_exact(M) = max over J(M) of RN32(F(T_exact(n,M))*q[n])
```

The selected posting's decoded ceiling defines
`M = RN32(F(selected_tf_ceiling)*a[selected_norm])`.
The actual serializer maximum plus monotonic ceiling expansion prove that every posting's old rounded input is <=M. Another posting's TF can exceed the selected TF. There is no independent block TF maximum in this certificate. Reject M=0, M=maxfinite, M=+inf, NaN and negative values; this narrow proposal also rejects M<min a as inconsistent.

For every actual integer t>=1, F(t)>=1 and `RN32(F(t)*a[n]) >= a[n]`. Thus every actual posting has **a[n]<=M**. Only strict `a[n]>M` exclusion is valid. This establishes existence of T_exact on J(M), independently of TF<=fieldnorm, overlap policy, norm0 absence or equality of selection/query averages.

For a feasible n, the proposed cap computes:

```
U = f64(nextup32(M))
P = nextup64(RN64(U / f64(a[n])))
if P >= 2^32: T_upper = u32MAX
else:
    Z = nextup32(RN32(P))
    if Z >= 2^32: T_upper = u32MAX
    else:
        N = f64(nextup32(Z))
        T_upper = ceil(N) - 1, converted through u64 and capped at u32MAX
```

The integer subtraction is done in u64 after checking feasibility, so there is no float-to-u32 saturation shortcut or underflow. A feasible norm must yield 1<=T_upper<=u32MAX; failure falls back. Do not use `floor(P)` as the cap: integer-to-f32 plateaus can round frequencies downward and invalidate that inference.

The proof is local and independent of approximate BM25 algebra:

1. RN32(p)<=M implies p<nextup32(M) for p=F(t)*a[n]. This includes rounded-down products, ties and subnormals. M is not a real-product upper bound.
2. Exact f32 promotions lose no bits. U/a lies well inside finite normal f64 for the permitted f32 operands. The outward f64 division gives P>=U/a>F(t). No f64 multiply or ratio-of-query-caches step is used.
3. The outward f32 cast gives Z>=P, including cast rounding; clipping at 2^32 uses the true `F(u32MAX)=2^32` endpoint.
4. If F(t)<=Z, then t<nextup32(Z). Otherwise monotonic real-to-f32 rounding and representability of nextup32(Z) would imply F(t)>=nextup32(Z)>Z. The largest integer strictly below N is ceil(N)-1. This proves T_upper>=t, including all u32 cast plateaus. Taking u32MAX when clipping occurs is trivially conservative.
5. F is nondecreasing, and multiplication by finite q>=0 followed by RN32 is nondecreasing. Therefore `X_n=RN32(F(T_upper)*q[n])` bounds each posting's actual rounded native input. For q=+0 this is exactly +0; overflow to +inf gives GLOBAL. No extra upward step is necessary after this literal multiplication: its operands already dominate the posting's operands.
6. The literal rounded score is nondecreasing in nonnegative input for fixed finite positive w: denominator is nondecreasing, nonnegative quotient is nonincreasing, subtraction is nondecreasing. Literal score at max X_n therefore covers every actual literal score. Do not multiply frequency again or rescale an unboosted score.

T_upper can be several integer/cast steps looser than T_exact. This proposal does not claim equality or a tightest bound. Its tightness must be measured against the independent exact cap target. The binary-search reference uses the literal old product predicate, hence directly handles ties, large plateaus and u32MAX; it is not dependent on the outward-cap formula.

## Infinity exclusion, equality and breakpoint construction

Classify ALL 256 query entries. Let I={n:q[n]=+inf} and H=min a[n] over I. Reject an empty finite-query subset and any unsafe old cache. The b=1 branch is useful only when **M<H**. Equality returns GLOBAL w even if the selected posting has a finite query inverse.

The mandatory witness remains selection average 3: norm0/TF1 and norm1/TF2 tie at old input bits `40555555`; native 2.5/1 norm0 scores w. `M<=H` would falsely exclude norm0. H is a certificate of exclusion, never evidence that an infinite-query norm actually occurs in a block. Multiple infinity entries caused by tiny query normalization are treated identically; no hardcoded ID0 assumption is allowed.

The table covers the representable interval `[L,H.next_down()]`, L=min a[n]. If L>H.next_down(), reject setup: no integer posting block can satisfy the required interval. Choose at most 16 sorted breakpoints by uniform spacing in **positive f32 bit order**:

```
lo = bits(L); hi = bits(H.next_down())
bits(B_i) = lo + ceil((hi-lo)*i / 15), i=0..15, using u64 arithmetic
```

Remove duplicates. Endpoints remain L and H.next_down(). The choice avoids float logarithms or interpolation rounding; bit spacing roughly distributes bins across exponents but may produce loose bins. It is a performance hypothesis, not a numerical proof requirement. For each B_i:

- exclude exactly the norms with a[n]>B_i;
- for every remaining finite q entry, compute T_upper(n,B_i) and its literal query input X_n;
- store C_i=max X_n; all rows have B_i<H, so all infinite q norms are excluded;
- reject malformed construction, but allow +inf C_i as a row that returns GLOBAL.

For a qualifying block, select the **first** row with B_i>=M. Since M<=B_i, every actual posting belongs to J(B_i), and the cap proof at B_i covers it. Thus C_i is safe without deriving caps on the hot path. Looking up the preceding/lower breakpoint is unsound. Check M<H before lookup, including after TF255 reconstruction. An exact H equality is never rounded into the table. Row maxima should be nondecreasing; optional prefix-max normalization is conservative, but a decreasing observed row is an audit failure to diagnose rather than silently celebrate.

## Staging and actual pre-decode path

On the first eligible complete metadata call, validate q and reconstruct/validate all a values; create warm state. It returns GLOBAL. For each distinct current complete block whose M is in `[L,H)`, count one qualifying request. Repeated calls for the same `last_doc_in_block` do not earn more credit. GLOBAL failures above H do not trigger table construction. At the 64th distinct qualifying request, build the table once, switch to immutable Ready and allow that request to use the table. Earlier qualifying requests deliberately remain GLOBAL.

The credit is a bounded heuristic for amortization, not a proof of profitability. `last_doc_in_block` is only a consecutive-duplicate guard, not a globally unique block ID; reset/reseek can revisit a block and earn a credit again after a different block. That changes when setup occurs and cannot affect the bound. Do not add a corpus-wide registry or query-wide interning cache to make this heuristic exact.

```text
TermScorer::block_max_score:
    existing StoredDefault first
    existing unsafe-weight/normalization fallback
    current complete nonzero pair? otherwise preserve existing tail/global path
    PendingNative:
        actual q cache has +inf and selected profile is b=1?
            validate and install TfCapWarmup, or Global on rejection
        otherwise use retained B1 finite policy, or Global if B1 was reverted
    TfCapWarmup:
        form M using actual selected ceiling and old cache
        reject block unless L<=M<H and safe finite M
        observe distinct qualifying block; below64 -> GLOBAL
        at64 build Ready table; arithmetic/setup failure -> GLOBAL permanently
    TfCapReady:
        reuse private fixed-owner numeric bound if current block cached
        recompute M, check L<=M<H, ceil-row lookup, C
        finite C -> literal score helper -> private current-block cache
        unsupported/inf -> complete GLOBAL, without publishing numeric cache
```

The actual source accessor reads Dense or BitPacked skip metadata without decoding. `seek_block` can position at an unloaded second full block; no norm reader scan, postings frequency decompression or selected document lookup is needed. The serializer performs the same rounded input maximization after either document encoding. A complete block's data are trusted only through the native reader tag/selection average and the production construction caller; decoded presence alone does not establish authority.

VInt tails never activate or query this table. Their existing unloaded GLOBAL and loaded literal reduction remain. TF byte0 is absent metadata. TF byte255 expands to u32MAX for the selected posting, often producing M>=H and consequently GLOBAL; do not discard that expansion to force eligibility. Record selected TF255 frequency and its exclusion effect.

Observed B1 counters in the brief establish many actual unloaded complete requests, including 5,927 in single-term `of`; they do not establish how many satisfy M<H or whether 64 qualifying requests are reached. B1's k09 decode/score savings do not transfer to b=1. Sparse/dense direct routes and two-term essential/MaxScore routes with zero bound calls remain outside this opportunity.

## Costs and rejection boundaries

| State or operation | Proposed cost and boundary |
|---|---|
| No complete-bound request | No old cache/table allocation; existing pending descriptor only. |
| First b=1 complete request | Query classification over256; DEFAULT reconstruction over256; old validation over256 and H/L reduction. No256 query/old ratio divisions. |
| Warm state | Old Arc about1KiB plus warm box roughly32 bytes, headers/alignment extra; two allocations if reusing existing Arc-returning cache constructor. Complete request adds M, L/H checks and duplicate/count check; warm useful blocks still decode/score. |
| Activation at64 | <=16×256 cap solves: <=4,096 f64 divisions/nextups/casts/integer-ceils and native input products; infeasible a>B short-circuit. One additional envelope Arc allocation; release warm box. |
| Ready memory | Old Arc1KiB plus <=128 row bytes and ~24 bytes fields/padding, Arc/allocation headers. Estimate roughly1.2KiB per scorer; record actual target layout and RSS. Query cache already exists and is shared by weight. |
| Ready uncached block | Pair read, TF->f32 and old product, domain checks, <=5 comparisons for16-row lower-bound lookup, one literal native add/divide/subtract. No per-block norm scan and no per-block f64 ratio division. |
| Ready cached block | Existing numeric-cache hit, with same safety/ownership checks. |
| Clone while warm | Clone box/counter and share old Arc: an extra small allocation. Clone when ready shares immutable table Arc. Numeric cache remains per cursor, invalidated independently. |

Using pointer payload variants may preserve the existing <=16-byte TermBlockBounds target. This must be checked on the actual benchmark target; it is not a measured assertion. If the enum/scorer grows or DEFAULT branch/code placement materially regresses, that is a rejection signal. Keeping warm state inline would likely enlarge every scorer; it is rejected until actual layout proves otherwise. Fusing the initial old cache/warm box allocation could reduce two cold allocations but requires refactoring the common cache constructor; do not enlarge this first experiment solely for that cleanup.

At64, 4,096 divisions amortize to about64 divisions per qualifying warmup block, before allocation and reconstruction costs; that crude division count is not latency. The first63 blocks lose the possible pruning they could have obtained from an eager table. Additional segments/terms each pay setup independently. A score that rounds to w at a loose ceiling row provides no pruning. Coarse bit-spaced rows can be substantially worse than exact per-block caps. Record these costs instead of inferring savings from fixed O(log16) hot work.

The brief reports k09 cold small-query losses of6–11%, DEFAULT dense losses despite unchanged counters, DEFAULT TOP ratios around1.02 and k25 near1.00. This candidate adds its own cold cost. The staging heuristic does not guarantee absence of those regressions. Small b=1 terms with fewer than64 qualifying requests receive no new pruning; this is an explicit supported-performance limit, not a claim of all-query parity or regression-free efficiency.

Root supplied a fresh unchanged-ruler checkpoint during this read-only design: first k09 TOP Tantivy/Lucene ratio 1.000555, aggregate parity despite roughly 29.5% paired improvement; DEFAULT TOP Tantivy/Lucene 0.480675/0.490635 with roughly 2.2–2.4% intrinsic paired cost. These are root-reported first checkpoints while measurement remains active, not this candidate's measurements or a final B1 verdict. They strengthen the requirement to preserve DEFAULT floors and report setup losses honestly. A large paired improvement over a slower candidate baseline is not automatically an external-ruler win.

Reject these alternatives for the first candidate:

| Alternative | Reason |
|---|---|
| Exact per-block 256-norm binary-search maximum | Up to8,192 literal old predicates plus256 native products per cache miss; worse than a128-posting decode/score opportunity before any real measurement. Keep only as oracle. |
| Conservative caps over256 norms per block | Up to256 f64 divisions and integer-ceils per bound. Potentially more work than128 document scores and no competitive cold/hot evidence. Not the proposed runtime path. |
| Exact table over every stored pair M | Up to65,280 pair values (256 norms×255 nonzero TF codes including saturation); huge setup/storage or millions of cap evaluations. |
| Only finite-norm max q/a | Cheap and a valid distinct hypothesis with M<H, but loses integer feasibility/TF plateau tightening; belongs to the other candidate rather than this one. |
| Small table built on every first bound | Pays4,096 cap divisions on terms that may request one block; observed cold setup losses argue against this eager form. |
| Forward ratio with q=+inf | Fails unless every such norm is strictly excluded; replacing infinity with a finite approximation is unsound. |
| Score selected pair under query parameters | Selected posting is only the DEFAULT rounded maximizer; profile change can change the maximizing posting. |
| TF<=norm, absent norm0, query avg=selection avg, TF255 as block TF max | None is an actual serializer certificate. |
| Threshold-aware refinement | Could skip table construction when GLOBAL already suffices, but requires propagating thresholds through current bound APIs and more caller changes. Defer it. |
| Global mutable memo/interner or added index frontier | Ownership complexity or changed artifacts; outside the single same-format hypothesis. |

## Module and ownership map

| Module | Narrow candidate change |
|---|---|
| query/bm25.rs | Private cap-domain validation, conservative integer-cap arithmetic, table builder and ceil lookup; reuse exact score-at-input. |
| query/term_query/term_scorer.rs | Warm/Ready pointer policy variants and fixed64 activation counter; preserve DEFAULT-first dispatch and conditional B1 finite disposition. |
| postings/block_segment_postings.rs | Private ready-envelope complete-bound path or a narrow generalization of the existing envelope input dispatch; keep numeric cache fixed-owner and public evaluation uncached. |
| postings/skip.rs | Existing selected-pair accessor suffices; no byte changes or broadened `supports_frequency_ceiling`. |
| postings/serializer.rs | No production changes. New tests use the real existing native serializer and inspect selected pair. |
| term_weight.rs | Existing post-boost selection binding suffices; no planner/public API change. |
| existing private bound/serializer test modules | Cap/table/source-cache and complete unloaded lifecycle fixtures. |

Keep cap arithmetic private in bm25.rs initially. Do not pass q/old arrays through Boolean scorers. The Ready table is tied to the actual fixed cache and selection average, and shares only under identical binding. Warm clone counters can diverge and alter activation timing; ready clones share immutable numerical rows. Movement/reset invalidates current-block numeric values as today.

Construction-only selection binding remains the existing production contract. Do not claim safe mutable rebinding: if a future caller permits replacement, it must atomically discard Warm/Ready state and numeric cache. Public changed-weight or changed-reader calls must neither consume nor populate private cached scores. Forwarded native statistics can be mathematically eligible when actual cache/context predicates hold; do not inaccurately classify every custom provider as legacy merely by identity.

## Independent exact audit and runtime certificates

Before any timed candidate, require an independent rational IEEE quantizer for binary32 and binary64 that never calls the cap helper. For each vector record selected pair, actual a/q bits for all256 norms, M, H/L, each exact T and conservative T_upper, every breakpoint/row input, lookup row, bound bits and literal score coverage. The exact T target is obtained by an independent monotone u32 search whose midpoint arithmetic uses u64 and whose old-product predicate is independently rounded.

Audit obligations:

1. For all256 norm codes and all eligible cache vectors, every actual posting's norm satisfies a<=M. No equality is discarded. For feasible norms, T_upper>=T_exact. For excluded norms, independently show no positive integer TF is feasible.
2. Compute F(t) and literal products independently at TF1,2,254,255,256,2^24-1/2^24/2^24+1, every transition neighborhood through powers2^24..2^32, and u32MAX. Include midpoint endpoints with both significand parities and the final u32-to-f32 plateau at2^32. Cover old products rounding up/down/ties and positive subnormal old inverses.
3. Check M values immediately below/equal/above every distinct a threshold and H. Preserve avg3 `40555555` strict tie witness. Add multiple +inf q values, all +inf, +0 q and invalid -0/negative/NaN/-inf query caches. Some exceptional cache probes need private synthetic injection; label them accordingly.
4. Keep the old rounded-down product witness a=`3f800001`,TF5,M=`40a00001`, and an independent nearest64 division-underestimate witness. Verify each outward endpoint independently. Include P just below/at/above2^32, cast to2^32, strict `ceil(N)-1` plateau boundaries, malformed feasible cap0 and maxfinite/infinite M rejection.
5. Verify first-row-above lookup at every row endpoint and its two adjacent f32 values; duplicate breakpoints; L/H interval with zero/one representable values; rows whose query product overflows or rounds score to w. The preceding-row lookup must have an explicit adversarial failing vector.
6. Use independently reconstructed actual selection averages versus different query averages. Retain the existing source-cache wrong-average witness. Test finite positive averages spanning ordinary, huge and subnormal domains, rejecting invalid actual old inverses.
7. Check zero/subnormal/negative/nonfinite boosts, ±0 k1, b endpoints and unsupported scoring/provenance. No fractional phrase frequency is admitted by the integer-term certificate.

Runtime fixtures must use the real native serializer and actual reader cache provenance, not fabricated scalar M alone:

- Fill full128-posting FOR and Dense blocks with unrelated norm/TF extremes; inspect selected norm membership, selected TF ceiling, old rounded input coverage and selected profile provenance. Include TF255/256/large/u32MAX expansion and absent metadata, no frequencies and VInt tails.
- Serialize the avg3 norm0/TF1 versus norm1/TF2 tie in both encoding paths. It must stay GLOBAL at M=H regardless of selected winner.
- Build qualifying low-M blocks at finite-query norms. At least65 distinct complete blocks are required to exercise warm count63/64, activation, ready cache and an unloaded block after activation. Repeated calls for one block must not activate early. Observe real `block_is_loaded=false` before the useful post-activation bound; demonstrate bound<w and actual shallow skip before decode in at least one fixture.
- Cover failure M>=H followed by qualifying blocks, duplicate/reseek calls, clone before activation and clone after activation, complete-to-tail movement, all existing cursor movement/reset invalidators and construction-only binding.
- Test public low/different weight and different norm reader before and after private caching, in full blocks and loaded tails. The owner score must still cover its actual high-weight postings, and public calls must ignore private cached values. Loaded NaN keeps infinity; absent union contribution keeps zero floor.
- Require literal document score bits unchanged and bound>=every actual finite literal score. Keep tie handling and optimized-versus-exhaustive TopDocs/COUNT/raw-score checks.

The runtime certificate report must distinguish: trusted pair available, warm query eligible, M finite/domain eligible, infinite-norm exclusion success, qualifying distinct credit, table activation, selected row, finite input, bound below w, threshold-effective bound, unloaded shallow skip, avoided decode and avoided actual score. A single scalar coverage result proves none of the later events.

## Frozen measurement and rollback

After root releases serialized timing ownership, freeze one candidate implementation and its independent oracle/runtime receipts. Preserve the existing same-format immutable aligned index/query pair and verify identity before/after. Run required release fixtures, all native/legacy suites, frozen330, all three Wiki20 optimized/exhaustive gates and all1,913 common raw-score bit comparisons before uninstrumented measurements. Use the unchanged Lucene ruler, root's toolchain/profile/CPU4 policy, serial candidate/baseline paired execution in both orders and existing40-second/256-sample procedure. Keep instrumentation out of timed binaries.

Counters per profile/query must include actual route, loaded/unloaded Dense/FOR/VInt bound calls, q classification failure, old cache failure, TF255, M<H pass/fail with equality distinguished, qualifying distinct credits, warmup count, setup/table allocation and construction cost, row distribution, exact-versus-conservative-versus-row input looseness bands, bound/w and bound/threshold bands, cache hits, shallow skips, decodes, actual document scores and WAND candidates. Record per-query latency, DEFAULT TOP and COUNT controls, no-bound controls, setup/read RSS and total index bytes. Sampling exact cap/row looseness belongs to untimed instrumentation only.

Reject if b=1 blocks rarely qualify, typical terms do not reach64, the table mostly yields w, setup overwhelms saved scores/decodes, DEFAULT/COUNT required floors regress, any required per-query target fails, or code/layout/allocation cost negates the hot savings. Do not average away cold small-query regressions. Do not change16/64 after seeing results and call the modified candidate the same hypothesis; retain each result and propose a separate bounded next experiment.

Rollback removes the two new policy variants, cap/table helpers and private ready dispatch, plus B2-specific tests/counters. Restore the prior B1 b=1 rejection or accepted-core GLOBAL policy according to root's B1 decision. No format rewrite, reader migration, index rebuild, query score rollback or public API change is necessary. This package makes no full-Lucene-parity or speed-win claim.
