# Untimed native pruning execution grounding — October 5

Instrumented isolated worktree tantivy-pruning-counters-oct05 starts at0eb1af15d;
main core and all frozen binaries/indices remain unchanged. The instrumentation
adds only relaxed atomic counts, reset before parsing each request, and counter
snapshots after execution. It measures execution counts, never latency. Root
read the entire resulting core patch. Counter module/adapter sources, Cargo
manifest/lock, binary hash, commands and raw stdin/stdout/stderr are retained in
native-profile-pruning-counters-oct05. Initial missing serde_json dependency build
failure and unsupported unconfigured DEFAULT acknowledgement attempt are retained.
Final build copies the frozen native adapter lock before resolving the new root;
final dependency/binary identities are recorded separately.

All20 TOP_10 execution counts repeat identically twice for each installed profile.
All20 optimized/exhaustive checks per profile pass. Explicit DEFAULT1.2/.75
receipts are installed; every80 counter line also matches the implicit DEFAULT
first run exactly. Actual getters acknowledge N917578 andTTF294827020.

| Query | Profile | Actual TermScorer score calls | Complete decoded blocks | Single-term skips |
|---|---|---:|---:|---:|
| the | default | 96506 | 753 | 5689 |
| the | k09-b04 | 824698 | 6442 | 0 |
| the | k25-b1 | 824698 | 6442 | 0 |
| of | default | 15491 | 121 | 5807 |
| of | k09-b04 | 758787 | 5928 | 0 |
| of | k25-b1 | 758787 | 5928 | 0 |
| american | default | 7033 | 54 | 875 |
| american | k09-b04 | 119033 | 929 | 0 |
| american | k25-b1 | 119033 | 929 | 0 |

For each nondefault single term, exactly one complete-block global request is
loaded (initially opened block); every later request is unloaded. For 'of',
5,927 unloaded complete-block global requests and zero stored/tail/cached-bound
requests occur. All758,787 postings are scored. Loaded-block-only bounds therefore
cannot remove the decoding/scoring of the remaining5,927 complete blocks under
the current single-term loop. This is now observed, not inferred only from source.

Dense '+the +of' takes block_wand_intersection in every profile. DEFAULT has11,145
window skips versus0 for both nondefault profiles. Integer Bm25Weight.score API
calls are86,772 versus761,838(.9/.4)/763,391(2.5/1); those include both stored-bound
score evaluation and actual leader batch scoring, not purely document scores.
'the of' starts two_term_or_maxscore and transitions to that same intersection.
'the american' stays two_term_or_maxscore without block-bound calls. Sparse
'+the +saxophone' takes sparse_dense_intersection with no block-bound calls.
Thus a bound fix targets observed single-term/dense-intersection losses, but
cannot be credited with improving specialized paths that never consult bounds.

Atomic instrumentation perturbs execution cost and is never used for performance
numbers. Profiles' native integer-score counts omit direct fractional phrase
score_with_frequency calls; raw source locations/map define each counter exactly.
No production optimization, new-format index, or performance win is claimed.
