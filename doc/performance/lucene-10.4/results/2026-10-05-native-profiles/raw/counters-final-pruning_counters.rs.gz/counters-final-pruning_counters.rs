use std::sync::atomic::{AtomicU64,Ordering};
pub static COUNTERS:[AtomicU64;19]=[const{AtomicU64::new(0)};19];
pub fn hit(i:usize){COUNTERS[i].fetch_add(1,Ordering::Relaxed);}
pub fn reset(){for c in &COUNTERS{c.store(0,Ordering::Relaxed);}}
pub fn snapshot()->Vec<u64>{COUNTERS.iter().map(|c|c.load(Ordering::Relaxed)).collect()}
